<?php

add_action('init','of_options');

if (!function_exists('of_options'))
{
	function of_options()
	{
		//Access the WordPress Categories via an Array
		$of_categories = array();  
		$of_categories_obj = get_categories('hide_empty=0');
		foreach ($of_categories_obj as $of_cat) {
		    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
		$categories_tmp = array_unshift($of_categories, "Select a category:");    
	       
		//Access the WordPress Pages via an Array
		$functionof_pages = array();
		$of_pages_obj = get_pages('sort_column=post_parent,menu_order');
		if($of_pages_obj):
		foreach ($of_pages_obj as $of_page) {
		    $of_pages[$of_page->ID] = $of_page->post_name; }
		$of_pages_tmp = array_unshift($of_pages, "Select a page:");
		endif;
		
		//Testing 
		$of_options_select = array("one","two","three","four","five"); 
		$of_options_radio = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five");
		
		//Sample Homepage blocks for the layout manager (sorter)
		$of_options_homepage_blocks = array
		( 
			"disabled" => array (
				"placebo" 		=> "placebo", //REQUIRED!
				"block_one"		=> "Block One",
				"block_two"		=> "Block Two",
				"block_three"	=> "Block Three",
			), 
			"enabled" => array (
				"placebo" => "placebo", //REQUIRED!
				"block_four"	=> "Block Four",
			),
		);


		//Stylesheets Reader
		$alt_stylesheet_path = LAYOUT_PATH;
		$alt_stylesheets = array();
		
		if ( is_dir($alt_stylesheet_path) ) 
		{
		    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) 
		    { 
		        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) 
		        {
		            if(stristr($alt_stylesheet_file, ".css") !== false)
		            {
		                $alt_stylesheets[] = $alt_stylesheet_file;
		            }
		        }    
		    }
		}


		//Background Images Reader
		$bg_images_path = STYLESHEETPATH. '/images/bg/'; // change this to where you store your bg images
		$bg_images_url = get_bloginfo('template_url').'/images/bg/'; // change this to where you store your bg images
		$bg_images = array();
		
		if ( is_dir($bg_images_path) ) {
		    if ($bg_images_dir = opendir($bg_images_path) ) { 
		        while ( ($bg_images_file = readdir($bg_images_dir)) !== false ) {
		            if(stristr($bg_images_file, ".png") !== false || stristr($bg_images_file, ".jpg") !== false) {
		                $bg_images[] = $bg_images_url . $bg_images_file;
		            }
		        }    
		    }
		}
		

		/*-----------------------------------------------------------------------------------*/
		/* TO DO: Add options/functions that use these */
		/*-----------------------------------------------------------------------------------*/
		
		//More Options
		$uploads_arr = wp_upload_dir();
		$all_uploads_path = $uploads_arr['path'];
		$all_uploads = get_option('of_uploads');
		$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
		$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
		$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");
		
		// Image Alignment radio box
		$of_options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 
		
		// Image Links to Options
		$of_options_image_link_to = array("image" => "The Image","post" => "The Post"); 

		$font_sizes = array(
			'10' => '10',
			'11' => '11',
			'12' => '12',
			'13' => '13',
			'14' => '14',
			'15' => '15',
			'16' => '16',
			'17' => '17',
			'18' => '18',
			'19' => '19',
			'20' => '20',
			'21' => '21',
			'22' => '22',
			'23' => '23',
			'24' => '24',
			'25' => '25',
			'26' => '26',
			'27' => '27',
			'28' => '28',
			'29' => '29',
			'30' => '30',
			'31' => '31',
			'32' => '32',
			'33' => '33',
			'34' => '34',
			'35' => '35',
			'36' => '36',
			'37' => '37',
			'38' => '38',
			'39' => '39',
			'40' => '40',
			'41' => '41',
			'42' => '42',
		);

	$google_fonts = array(
							"0" => "Select Font",
							"Arvo" => "Arvo",
							"Droid Sans" => "Droid Sans",	
							"Droid Serif" => "Droid Serif",
							"Lato" => "Lato",
							"Open Sans" => "Open Sans",
							"Open Sans Condensed" => "Open Sans Condensed",
							"PT Sans" => "PT Sans",
							"PT Sans Narrow" => "PT Sans Narrow",
						);

/*-----------------------------------------------------------------------------------*/
/* The Options Array */
/*-----------------------------------------------------------------------------------*/

// Set the Options Array
global $of_options;
$of_options = array();

$of_options[] = array( "name" => "General Options",
					"type" => "heading");

$of_options[] = array( "name" => "Layout",
					"desc" => "Boxed or wide layout?",
					"id" => "layout",
					"std" => "Wide",
					"type" => "select",
					"options" => array(
						'boxed' => 'Boxed',
						'wide' => 'Wide',
					));
					
$of_options[] = array( "name" => "Custom Favicon",
					"desc" => "You can put url of an ico image that will represent your website's favicon (16px x 16px)",
					"id" => "favicon",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Apple iPhone Icon Upload",
					"desc" => "Icon for Apple iPhone (57px x 57px)",
					"id" => "iphone_icon",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Apple iPhone Retina Icon Upload",
					"desc" => "Icon for Apple iPhone Retina Version (114px x 114px)",
					"id" => "iphone_icon_retina",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Apple iPad Icon Upload",
					"desc" => "Icon for Apple iPhone (72px x 72px)",
					"id" => "ipad_icon",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Apple iPad Retina Icon Upload",
					"desc" => "Icon for Apple iPad Retina Version (144px x 144px)",
					"id" => "ipad_icon_retina",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Default Sidebar Position",
					"desc" => "Select the defeault position of the sidebar.",
					"id" => "default_sidebar_pos",
					"std" => "right",
					"options" => array('right' => 'Right', 'left' => 'Left'),
					"type" => "select");

$of_options[] = array( "name" => "Responsive Design",
					"desc" => "Use the responsive design features.",
					"id" => "responsive",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Use Fixed Layout for iPad Portrait",
					"desc" => "Check this box to use the fixed layout for the iPad in portrait view.",
					"id" => "ipad_potrait",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Header Options",
					"type" => "heading");

$of_options[] = array( "name" => "Select a Header Layout",
					"desc" => "",
					"id" => "header_layout",
					"std" => "v1",
					"type" => "images",
					"options" => array(
						"v1" => get_bloginfo('template_directory')."/images/patterns/header1.jpg",
						"v2" => get_bloginfo('template_directory')."/images/patterns/header2.jpg",
						"v3" => get_bloginfo('template_directory')."/images/patterns/header3.jpg",
						"v4" => get_bloginfo('template_directory')."/images/patterns/header4.jpg",
						"v5" => get_bloginfo('template_directory')."/images/patterns/header5.jpg"
					));

$of_options[] = array( "name" => "Header Top Margin",
					"desc" => "(in pixels)",
					"id" => "margin_header_top",
					"std" => "0px",
					"type" => "text");

$of_options[] = array( "name" => "Header Bottom Margin",
					"desc" => "(in pixels)",
					"id" => "margin_header_bottom",
					"std" => "0px",
					"type" => "text");

$of_options[] = array( "name" => "Logo Left Margin",
					"desc" => "(in pixels)",
					"id" => "margin_logo_left",
					"std" => "0px",
					"type" => "text");

$of_options[] = array( "name" => "Logo Bottom Margin",
					"desc" => "(in pixels)",
					"id" => "margin_logo_bottom",
					"std" => "0px",
					"type" => "text");

$of_options[] = array( "name" => "Main Nav Height",
					"desc" => "(Only use number without 'px', default is 83)",
					"id" => "nav_height",
					"std" => "83",
					"type" => "text");

$of_options[] = array( "name" => "Logo",
					"desc" => "Please choose an image file for your logo.",
					"id" => "logo",
					"std" => get_bloginfo('template_directory')."/images/logo.gif",
					"mod" => "min",
					"type" => "media");

$of_options[] = array( "name" => "Logo (Retina Version @2x)",
					"desc" => "Please choose an image file for the retina version of the logo. It should be 2x the size of main logo.",
					"id" => "logo_retina",
					"std" => "",
					"mod" => "min",
					"type" => "media");

$of_options[] = array( "name" => "Standard Logo Width for Retina Logo",
					"desc" => "If retina logo is uploaded, please enter the standard logo (1x) version width, do not enter the retina logo width.",
					"id" => "retina_logo_width",
					"std" => "120",
					"type" => "text");

$of_options[] = array( "name" => "Standard Logo Height for Retina Logo",
					"desc" => "If retina logo is uploaded, please enter the standard logo (1x) version height, do not enter the retina logo height.",
					"id" => "retina_logo_height",
					"std" => "50",
					"type" => "text");

$of_options[] = array( "name" => "Header Phone Number",
					"desc" => "",
					"id" => "header_number",
					"std" => "Call Us Today! 0200 111 1111",
					"type" => "text");

$of_options[] = array( "name" => "Header Email Address",
					"desc" => "",
					"id" => "header_email",
					"std" => "info@yourdomain.com",
					"type" => "text");

$of_options[] = array( "name" => "Header Tagline",
					"desc" => "",
					"id" => "header_tagline",
					"std" => "Insert Any Headline Or Link Here",
					"type" => "text");

$of_options[] = array( "name" => "Display social icons on header of the page:",
					"desc" => "Select the checkbox to show social media icons on the header of the page.",
					"id" => "icons_header",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Open social icons on header in a new window",
					"desc" => "",
					"id" => "icons_header_new",
					"std" => 0,
					"type" => "checkbox");

$of_options[] = array( "name" => "Breadcrumbs or Search Box?",
					"desc" => "Show breadcrumbs or search box on page title bar?",
					"id" => "page_title_bar_bs",
					"std" => "Breadcrumbs",
					"options" => array('breadcrumbs' => 'Breadcrumbs', 'search' => 'Search Box'),
					"type" => "select");


$of_options[] = array( "name" => "Breadcrumb Menu",
					"desc" => "Show breadcrumbs in general",
					"id" => "breadcrumb",
					"std" => 1,
					"type" => "checkbox");


$of_options[] = array( "name" => "Breadcrumb on Mobile Devices",
					"desc" => "Show breadcrumbs on mobile devices",
					"id" => "breadcrumb_mobile",
					"std" => 0,
					"type" => "checkbox");


$of_options[] = array( "name" => "Breadcrumb Menu Prefix",
					"desc" => "The text before the breadcrumb menu",
					"id" => "breacrumb_prefix",
					"std" => "",
					"type" => "text");

$of_options[] = array( "name" => "Page Title Bar",
					"desc" => "Show page title bar",
					"id" => "page_title_bar",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Footer Options",
					"type" => "heading");

$of_options[] = array( "name" => "Copyright Bar",
					"desc" => "Show copyright bar",
					"id" => "footer_copyright",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Copyright Text",
                    "desc" => "",
                    "id" => "footer_text",
                    "std" => '© Copyright 2013 Reynolds Digital Ltd - All Rights Reserved - <a href="http://www.reynoldsdigital.com">Web Design London</a> | XML Sitemap | RSS Feed',
                    "type" => "textarea");

$of_options[] = array( "name" => "Footer Widgets",
					"desc" => "Show footer widgets",
					"id" => "footer_widgets",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Number of Footer Columns",
					"desc" => "",
					"id" => "footer_widgets_columns",
					"std" => "4",
					"options" => array('1' => '1', '2' => '2', '3' => '3', '4' => '4'),
					"type" => "select");

$of_options[] = array( "name" => "Display social icons on footer of the page:",
					"desc" => "Select the checkbox to show social media icons on the footer of the page.",
					"id" => "icons_footer",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Open social icons on footer in a new window",
					"desc" => "",
					"id" => "icons_footer_new",
					"std" => 0,
					"type" => "checkbox");


$of_options[] = array( "name" => "Typography Options",
					"type" => "heading");

$of_options[] = array( "name" => "Custom Nav / Headings Font",
					"desc" => "",
					"id" => "custom_heading_font",
					"std" => "<h3 style='margin: 0;''>Only for navigation menus and headings.</h3><p style='margin-bottom:0;'>This will overwrite the google / standard font options if custom font files are uploaded.</p>",
					"icon" => true,
					"type" => "info");

$of_options[] = array( "name" => "Custom Font .woff",
					"desc" => "",
					"id" => "custom_font_woff",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Custom Font .ttf",
					"desc" => "",
					"id" => "custom_font_ttf",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Custom Font .svg",
					"desc" => "",
					"id" => "custom_font_svg",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Custom Font .eot",
					"desc" => "",
					"id" => "custom_font_eot",
					"std" => "",
					"type" => "upload");

$of_options[] = array( "name" => "Google Fonts",
					"desc" => "",
					"id" => "google_fonts_intro",
					"std" => "<h3 style='margin: 0;''>Google Fonts</h3>",
					"icon" => true,
					"type" => "info");

$of_options[] = array( "name" => "Select Body Font Family",
					"desc" => "Select a font family for body text",
					"id" => "google_body",
					"std" => "PT Sans",
					"type" => "select",
					"options" => $google_fonts);

$of_options[] = array( "name" => "Select Menu Font",
					"desc" => "Select a font family for navigation",
					"id" => "google_nav",
					"std" => "Antic Slab",
					"type" => "select",
					"options" => $google_fonts);

$of_options[] = array( "name" => "Select Headings Font",
					"desc" => "Select a font family for headings",
					"id" => "google_headings",
					"std" => "Antic Slab",
					"type" => "select",
					"options" => $google_fonts);

$of_options[] = array( "name" => "Select Footer Headings Font",
					"desc" => "Select a font family for footer headings",
					"id" => "google_footer_headings",
					"std" => "Antic Slab",
					"type" => "select",
					"options" => $google_fonts);

$of_options[] = array( "name" => "Standard Fonts",
					"desc" => "",
					"id" => "standard_fonts_intro",
					"std" => "<h3 style='margin: 0; margin-bottom:10px;''>Standards</h3>If you have a Google Font selected above, it will override the standard font.",
					"icon" => true,
					"type" => "info");

$standard_fonts = array(
						'0' => 'Select Font',
						'Arial, Helvetica, sans-serif' => 'Arial, Helvetica, sans-serif',
						"'Arial Black', Gadget, sans-serif" => "'Arial Black', Gadget, sans-serif",
						"'Bookman Old Style', serif" => "'Bookman Old Style', serif",
						"'Comic Sans MS', cursive" => "'Comic Sans MS', cursive",
						"Courier, monospace" => "Courier, monospace",
						"Garamond, serif" => "Garamond, serif",
						"Georgia, serif" => "Georgia, serif",
						"Impact, Charcoal, sans-serif" => "Impact, Charcoal, sans-serif",
						"'Lucida Console', Monaco, monospace" => "'Lucida Console', Monaco, monospace",
						"'Lucida Sans Unicode', 'Lucida Grande', sans-serif" => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
						"'MS Sans Serif', Geneva, sans-serif" => "'MS Sans Serif', Geneva, sans-serif",
						"'MS Serif', 'New York', sans-serif" => "'MS Serif', 'New York', sans-serif",
						"'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
						"Tahoma, Geneva, sans-serif" => "Tahoma, Geneva, sans-serif",
						"'Times New Roman', Times, serif" => "'Times New Roman', Times, serif",
						"'Trebuchet MS', Helvetica, sans-serif" => "'Trebuchet MS', Helvetica, sans-serif",
						"Verdana, Geneva, sans-serif" => "Verdana, Geneva, sans-serif"
					);

$of_options[] = array( "name" => "Select Body Font Family",
					"desc" => "Select a font family for body text",
					"id" => "standard_body",
					"std" => "",
					"type" => "select",
					"options" => $standard_fonts);

$of_options[] = array( "name" => "Select Menu Font Family",
					"desc" => "Select a font family for menu / navigation",
					"id" => "standard_nav",
					"std" => "",
					"type" => "select",
					"options" => $standard_fonts);

$of_options[] = array( "name" => "Select Headings Font Family",
					"desc" => "Select a font family for headings",
					"id" => "standard_headings",
					"std" => "",
					"type" => "select",
					"options" => $standard_fonts);

$of_options[] = array( "name" => "Select Footer Headings Font Family",
					"desc" => "Select a font family for footer headings",
					"id" => "standard_footer_headings",
					"std" => "",
					"type" => "select",
					"options" => $standard_fonts);

$of_options[] = array( "name" => "Standard Fonts",
					"desc" => "",
					"id" => "font_size_intro",
					"std" => "<h3 style='margin: 0;'>Font Sizes</h3>",
					"icon" => true,
					"type" => "info");

$of_options[] = array( "name" => "Body Font Size (px)",
					"desc" => "Default is 13",
					"id" => "body_font_size",
					"std" => "13",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Top Nav Font Size (px)",
					"desc" => "Default is 14",
					"id" => "nav_font_size",
					"std" => "14",
					"type" => "select",
					"options" => $font_sizes);


$of_options[] = array( "name" => "Secondary Nav & Top Contact Info Font Size (px)",
					"desc" => "Default is 12",
					"id" => "snav_font_size",
					"std" => "12",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Side Nav Font Size (px)",
					"desc" => "Default is 14",
					"id" => "side_nav_font_size",
					"std" => "14",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Breadcrumbs Font Size (px)",
					"desc" => "Default is 10",
					"id" => "breadcrumbs_font_size",
					"std" => "10",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Sidebar Widget Title Font Size (px)",
					"desc" => "Default is 13",
					"id" => "sidew_font_size",
					"std" => "13",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Footer Widget Title Font Size (px)",
					"desc" => "Default is 13",
					"id" => "footw_font_size",
					"std" => "13",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Copyright Font Size (px)",
					"desc" => "Default is 12",
					"id" => "copyright_font_size",
					"std" => "12",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Heading Font Size H1 (px)",
					"desc" => "Default is 32",
					"id" => "h1_font_size",
					"std" => "32",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Heading Font Size H2 (px)",
					"desc" => "Default is 18",
					"id" => "h2_font_size",
					"std" => "18",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Heading Font Size H3 (px)",
					"desc" => "Default is 16",
					"id" => "h3_font_size",
					"std" => "16",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Heading Font Size H4 (px)",
					"desc" => "Default is 13",
					"id" => "h4_font_size",
					"std" => "13",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Heading Font Size H5 (px)",
					"desc" => "Default is 12",
					"id" => "h5_font_size",
					"std" => "12",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Heading Font Size H6 (px)",
					"desc" => "Default is 11",
					"id" => "h6_font_size",
					"std" => "11",
					"type" => "select",
					"options" => $font_sizes);

$of_options[] = array( "name" => "Blog Options",
					"type" => "heading");

$of_options[] = array( "name" => "Blog Layout",
					"desc" => "",
					"id" => "blog_layout",
					"std" => "Large",
					"type" => "select",
					"options" => array(
						'large' => 'Large',
						'medium' => 'Medium',
					));

$of_options[] = array( "name" => "Blog Page Title Bar Title",
					"desc" => "",
					"id" => "blog_title",
					"std" => "Blog",
					"type" => "text");

$of_options[] = array( "name" => "Full Width",
					"desc" => "Turn the blog into full width.",
					"id" => "blog_full_width",
					"std" => 0,
					"type" => "checkbox");

$of_options[] = array( "name" => "Sidebar Position",
					"desc" => "Blog listings page sidebar position",
					"id" => "blog_sidebar_position",
					"std" => "right",
					"type" => "select",
					"options" => array(
						'right' => 'Right',
						'left' => 'Left',
					));

$of_options[] = array( "name" => "Featured Image On Blog Archive Page",
					"desc" => "Show featured images on blog archive page",
					"id" => "featured_images",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Featured Image on Single Post Page",
					"desc" => "Show featured images on single post pages.",
					"id" => "featured_images_single",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Post Title",
					"desc" => "Show the post title that goes below the featured images.",
					"id" => "blog_post_title",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Author Info Box",
					"desc" => "Show the author info box below posts.",
					"id" => "author_info",
					"std" => 1,
					"type" => "checkbox");
// Theme Specific Options
$of_options[] = array( "name" => "Extra Options",
					"type" => "heading");

$of_options[] = array( "name" => "Testimonials Speed",
					"desc" => "Select the slideshow speed, 1000 = 1 second",
					"id" => "testimonials_speed",
					"std" => "4000",
					"type" => "text");

$of_options[] = array( "name" => "Image Rollover",
					"desc" => "Show rollover box on images",
					"id" => "image_rollover",
					"std" => 1,
					"type" => "checkbox");

$of_options[] = array( "name" => "Enable posts type order plugin",
					"desc" => "Disabled by default. Note: It can break the order of next post/previous post links.",
					"id" => "post_type_order",
					"std" => 0,
					"type" => "checkbox");

$of_options[] = array( "name" => "UberMenu Plugin Support",
					"desc" => "If you are using UberMenu, check this option to add ubermenu support without editing any code.",
					"id" => "ubermenu",
					"std" => 0,
					"type" => "checkbox");

					
	}
}
?>