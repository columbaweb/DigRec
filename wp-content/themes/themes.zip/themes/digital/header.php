<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7 ie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8 ie7" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9 ie8" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?>> <!--<![endif]-->

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if ( function_exists( 'colabs_title') ){ colabs_title(); }else{ echo get_bloginfo('name'); ?>&nbsp;<?php wp_title(); } ?></title>
<?php
	if ( function_exists( 'colabs_meta') ) colabs_meta();
	if ( function_exists( 'colabs_meta_head') )colabs_meta_head(); 
    global $colabs_options;
?>
    <link href="<?php echo get_template_directory_uri(); ?>/includes/css/colabs-css.css" rel="stylesheet" type="text/css" />
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />

    
<?php 
    if ( function_exists( 'colabs_head') ) colabs_head();
    wp_head(); 

?>
<!--[if lte IE 9]><style type="text/css">a img {border:none}</style><![endif]-->
<?php if(get_option('colabs_disable_mobile')=='false'){?>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<?php }?>
</head>
<body <?php body_class(); ?>>
<div class="header container">
	<div class="row">
        <?php if( has_nav_menu('primary') ){ ?>
		<div class="header-nav column col5">
			<div>
                
            <?php wp_nav_menu( array( 'container' => 'false', 'menu_class' => '', 'theme_location' => 'primary', 'fallback_cb' => 'default_top_nav', 'depth' => 1 ) ); ?>

            <div class="menu-select-primary">
                <?php colabs_nav_menu('show_option_none=Navigate to&theme_location=primary&fallback_cb='); ?>
            </div><!-- .menu-select -->

			</div>
		</div><!-- .header-nav -->
        <?php } ?>
        
        <?php colabs_prof_menu(); ?>
        
		<div class="navigation column col12">
            
            <div class="menu-select-secondary">
                <?php wp_nav_menu( array( 'container' => 'false', 'menu_class' => 'nav-left column col5', 'theme_location' => 'secondary', 'depth' => 1, 'fallback_cb' => 'default_primary_nav' ) ); ?>
            </div><!-- .menu-select -->
            
            <?php if( get_option('colabs_logo')!='' ){ ?>
			<div class="logo">
				<a href="<?php echo home_url(); ?>"><img src="<?php echo get_option('colabs_logo'); ?>"/></a>
			</div><!-- .logo -->
            <?php } ?>

			<ul class="nav-right column col5 fr">
                <?php colabs_menu(); ?>
			</ul><!-- .nav-right -->			
		</div><!-- .navigation -->
    
        <div class="mobile-menu">    
            <a class="btn-navbar collapsed">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </a>      
        </div>

	</div><!-- .row -->
</div><!-- .header -->

<div class="main container <?php global $header_search; if (!$header_search) echo 'nosearch'; ?>">
		
