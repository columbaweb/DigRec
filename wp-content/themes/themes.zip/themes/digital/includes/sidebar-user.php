<?php global $userdata; ?>

<div class="widget widget_user_options">

	<h3 class="widget-title"><?php _e('Account Options','colabsthemes'); ?></h3>
    
		<ul>
			<?php if (is_user_logged_in()) : ?><li><a href="<?php echo get_permalink(get_option('colabs_dashboard_page_id')) ?>"><?php _e('My Dashboard','colabsthemes')?></a></li><?php endif; ?>
			<li><a href="<?php
				$author = get_user_by('id', get_current_user_id());
				if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) echo $link;
			?>"><?php _e('View Profile','colabsthemes')?></a></li>
			<li><a href="<?php echo get_permalink(get_option('colabs_user_profile_page_id')) ?>"><?php _e('Edit Profile','colabsthemes')?></a></li>
			<?php if (current_user_can('edit_others_posts')) { ?><li><a href="<?php echo get_option('siteurl'); ?>/wp-admin/"><?php _e('WordPress Admin','colabsthemes')?></a></li><?php } ?>
			<li><a href="<?php echo wp_logout_url(); ?>"><?php _e('Log Out','colabsthemes')?></a></li>
		</ul>

</div>


<!--div class="widget widget_user_info">

	<h3 class="widget-title"><?php _e('Account Info','colabsthemes'); ?></h3>

		<ul>
			<li><strong><?php _e('Username:','colabsthemes')?></strong> <?php echo $userdata->user_login; ?></li>
			<li><strong><?php _e('Account type:','colabsthemes')?></strong> <?php
				$user = new WP_User( $userdata->ID );
				if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
					foreach ( $user->roles as $role )
						if ($role=='job_seeker') echo __('Job Seeker', 'colabsthemes');
						else echo __('Job Lister', 'colabsthemes');
				}
			?></li>
			<li><strong><?php _e('Member Since:','colabsthemes')?></strong> <?php colabsthemes_get_reg_date($userdata->user_registered); ?></li>
			<li><strong><?php _e('Last Login:','colabsthemes'); ?></strong> <?php colabsthemes_get_last_login($userdata->ID); ?></li>
		</ul>

</div-->