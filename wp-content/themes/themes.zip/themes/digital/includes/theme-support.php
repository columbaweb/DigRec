<?php
/**
 * JobJockey Theme Support
 * This file defines 'theme support' so wordpress knows what new features it can handle.
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

/*-----------------------------------------------------------------------------------*/
/*  automatic-feed-links Features  */
/*-----------------------------------------------------------------------------------*/
if ( function_exists( 'add_theme_support' ) && get_option('colabs_feedlinkurl') == '' ) {
add_theme_support( 'automatic-feed-links' );
}

/*-----------------------------------------------------------------------------------*/
/*  WP 3.0 post thumbnails compatibility */
/*-----------------------------------------------------------------------------------*/
if(function_exists( 'add_theme_support')){
    add_theme_support( 'menus' );
    if( get_option('colabs_post_image_support') ){
        add_theme_support( 'post-thumbnails', array( 'post', 'job_listing', 'resume' ) );
		// set height, width and crop if dynamic resize functionality isn't enabled
		if ( get_option( 'colabs_pis_resize') <> "true" ) {
			$hard_crop = get_option( 'colabs_pis_hard_crop' );
			if($hard_crop == 'true') {$hard_crop = true; } else { $hard_crop = false;} 
            add_image_size( 'headline-thumb', 978, 99999, $hard_crop);
            add_image_size('blog-thumbnail', 150, 150, true); // blog post thumbnail size, box resize mode
            add_image_size('sidebar-thumbnail', 50, 50, true); // sidebar blog thumbnail size, box resize mode
            add_image_size('listing-thumbnail', 28, 28, true);			
		}
	}
}

function default_primary_nav() {
	global $wp_query;
	echo '<ul id="menu-secondary" class="nav-left column col5">';
	echo '<li class="page_item ';
	if (is_front_page() && !isset($_GET['submit']) && !isset($_GET['myjobs'])) echo 'current_page_item';
	echo '"><a href="'.get_bloginfo('url').'">'.__('Latest Jobs', 'colabsthemes').'</a></li>';
	
	$args = array(
	    'hierarchical'       => false,
	    'parent'               => 0
	);
	$terms = get_terms( 'job_type', $args );
	if ($terms) foreach($terms as $term) :
		echo '<li class="page_item ';
		if ( isset($wp_query->queried_object->slug) && $wp_query->queried_object->slug==$term->slug ) echo 'current_page_item';
		echo '"><a href="'.get_term_link( $term->slug, 'job_type' ).'">'.$term->name.'</a></li>';
	endforeach;
	
	echo '</ul>';
}

function default_top_nav() {
	echo '<ul id="menu-top" class="menu">';
	
	$exclude_pages = array();
	
	$exclude_pages[] = get_option('page_on_front');
	$exclude_pages[] = get_option('colabs_dashboard_page_id');
	$exclude_pages[] = get_option('colabs_add_new_confirm_page_id');
	$exclude_pages[] = get_option('colabs_submit_page_id');
	$exclude_pages[] = get_option('colabs_user_profile_page_id');
	$exclude_pages[] = get_option('colabs_edit_job_page_id');
	$exclude_pages[] = get_option('colabs_date_archive_page_id');
	$exclude_pages[] = get_option('colabs_job_seeker_register_page_id');
	
	if (get_option('colabs_disable_blog')=='true') $exclude_pages[] = get_option('colabs_blog_page_id');
	
	$exclude_pages = implode(',', $exclude_pages);
	echo wp_list_pages('sort_column=menu_order&title_li=&echo=0&link_before=&link_after=&depth=1&exclude='.$exclude_pages);
	echo colabs_top_nav_links();
	echo '</ul>';
}

/* Add items to top nav */

//add_filter('wp_nav_menu_items', 'colabs_top_nav_links');
add_action('colabs_menu','colabs_top_nav_links');

function colabs_top_nav_links( $items = '' ) {
if (is_user_logged_in()) {
	if (get_option('colabs_submit_page_id') && (!is_user_logged_in() || (is_user_logged_in() && current_user_can('can_submit_job')))) :
	
		$items .= '<li class="right ';
		if (is_page(get_option('colabs_submit_page_id'))) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_permalink(get_option('colabs_submit_page_id')).'">'.__('Submit a Job', 'colabsthemes').'</a></li>';
		
		$author = get_user_by('id', get_current_user_id());
		$items .= '<li class="right ';
		if (is_page(get_option('colabs_submit_page_id'))) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_author_posts_url( $author->ID, $author->user_nicename ).'">'.__('View Profile', 'colabsthemes').'</a></li>';
		
	endif;
	
	if (get_option('colabs_job_seeker_resume_page_id') && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('can_submit_job')))) :
	
		$items .= '<li class="right ';
		if (is_page(get_option('colabs_job_seeker_resume_page_id'))) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_permalink(get_option('colabs_job_seeker_resume_page_id')).'">'.__('Add A Resume', 'colabsthemes').'</a></li>';
		
	endif;
	
	if (
		get_option('colabs_allow_job_seekers')=='true' && (
			get_option('colabs_resume_listing_visibility')=='public'
			|| (get_option('colabs_resume_listing_visibility')=='members' && is_user_logged_in()) 
			|| (get_option('colabs_resume_listing_visibility')=='listers' && current_user_can('can_submit_job'))
		) //&& !current_user_can('can_submit_job')
		) :
		$items .= '<li class="right ';
		if (is_post_type_archive('resume')) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_post_type_archive_link('resume').'">'.__('Browse Resumes', 'colabsthemes').'</a></li>';
	endif;
} else {
		
		$items .= '<li class="right ';
		if (is_page(get_option('colabs_submit_page_id'))) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_permalink(get_option('colabs_submit_page_id')).'">'.__('Submit a Job', 'colabsthemes').'</a></li>';
		
		$items .= '<li class="right ';
		if (is_page(get_option('colabs_job_seeker_resume_page_id'))) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_permalink(get_option('colabs_job_seeker_resume_page_id')).'">'.__('Add A Resume', 'colabsthemes').'</a></li>';
		
		global $pagenow;
		if(isset($_GET['action'])) $theaction = $_GET['action']; else $theaction ='';
		$items .= '<li class="right ';
		if ($pagenow == 'wp-login.php' && $theaction !=='lostpassword' && !isset($_GET['key'])) $items .= 'current_page_item';
		$items .= '"><a href="'.site_url('wp-login.php').'">'.__('Login/Register', 'colabsthemes').'</a></li>';					
}
	
	$items .= '</ul>';	
	
	echo $items;
	
}

add_action('colabs_prof_menu','colabs_prof_nav_links');

function colabs_prof_nav_links( $items = '' ) {

if ( is_user_logged_in() ){
    global $wp_query,$user_ID;
    
    $items .= '<div class="user-info column col5 fr">';
    
    $items .= '<div class="user-meta">';
    
    //User Name	
	$user_info = get_userdata($user_ID);
	$user_name = $user_info->display_name;
        
    if ($url = $user_info->user_url) : 
        $items .= '<a class="user-name" href="'.$url.'">'.$user_name.'</a>';
    else :
        $items .= '<span class="user-name">'.$user_name.'</span>';
    endif;
    
    //My Dashboard
    $items .= '<p>';
    if (get_option('colabs_dashboard_page_id')){
        
    	$items .= '<a href="';
    	
        if (is_page(get_option('colabs_dashboard_page_id'))) : 
            //current_page_item
            $items .= '#';
        else : 
            $items .= get_permalink(get_option('colabs_dashboard_page_id'));
        endif;
        
    	$items .= '">'.__('My Dashboard', 'colabsthemes').'</a>';
        
        $items .= ' | ';
    }
    
    //Logout
    $items .= '<a href="'.wp_logout_url( get_bloginfo('url') ).'">'.__('Logout', 'colabsthemes').'</a>';
    
    $items .= '</p>';
    
    $items .= '</div><!-- .user-meta -->';
		
		$items .= get_avatar( $user_ID, '45' );
    
    $items .= '</div><!-- .user-info -->';
    
}

echo $items;

}
?>
