<?php
class colabs_pack {

	var $id;	 	 	 	 	 	 	
	var $pack_name;		 	 	 	 	 	 	
	var $pack_description;	 	 	 	 	 	 	 
	var $job_count;			 	 	 	 	 	 	 
	var $pack_duration;	 	 	 	 	 	 	
	var $job_duration; 	 	 	 	 	 	
	var $pack_cost;	 	 	 	 	 	 	 	 	
	var $pack_created;
	var $access;	
	
	function colabs_pack( $id='', $pack_options = array() ) {
		if ($id>0) :
			$this->id = (int) $id;
			$this->get_pack();
		elseif (!empty($pack_options['name'])):
			$this->pack_name 		= $pack_options['name'];
			$this->pack_description	= $pack_options['description'];
			$this->job_count		= $pack_options['job_count'];
			$this->pack_duration	= $pack_options['pack_duration'];
			$this->job_duration		= $pack_options['job_duration'];
			$this->pack_cost 		= $pack_options['cost'];
			$this->access 			= $pack_options['access'];
		endif;
	}
	
	function get_pack() {
		global $wpdb;
		$result = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."colabs_job_packs WHERE id = ".$this->id.';');
		if ($result) : 	 	 	 	 	
			$this->pack_name = $result->pack_name; 	 	 	 	 	 	
			$this->pack_description = $result->pack_description;	 	 	 	 
			$this->job_count = $result->job_count; 	 	 	 
			$this->pack_duration = $result->pack_duration; 	
			$this->job_duration = $result->job_duration;	
			$this->pack_cost = $result->pack_cost;	
			$this->access = !empty($result->access) ? explode(',', $result->access) : ''; 
			$this->pack_created = $result->pack_created;
		endif;
	}
	
	function insert_pack() {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'colabs_job_packs', array( 
			'pack_name' 		=> $this->pack_name,
			'pack_description' 	=> $this->pack_description,
			'job_count' 		=> $this->job_count,
			'pack_duration' 	=> $this->pack_duration,
			'job_duration' 		=> $this->job_duration,
			'pack_cost'			=> $this->pack_cost,
			'access' 				=> is_array($this->access) ? implode(',', $this->access) : '',
			'pack_order' 			=> ($this->pack_order>0?$this->pack_order:1),
		), array( '%s','%s','%s','%s','%s','%s','%s','%d' ) );
		
		$this->id = $wpdb->insert_id;
	}
	
	function give_to_user( $user ) {
		global $wpdb;
		if ($this->id > 0) :
				
			if ($this->pack_duration > 0) :
				$expires = date("Y-m-d H:i:s", strtotime("+".$this->pack_duration." day"));
			else :
				$expires = '';
			endif;
			
			$wpdb->insert( $wpdb->prefix."colabs_customer_packs", array( 
				'pack_name' 	=> $this->pack_name, 
				'user_id' 		=> $user,
				'job_duration' 	=> $this->job_duration,
				'pack_expires' 	=> $expires,
				'jobs_count' 	=> 1,
				'access' 					=> is_array($this->access) ? implode(',', $this->access) : '',
				'jobs_limit' 	=> $this->job_count,
				'pack_order' 				=> $this->pack_order
			), array( '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%d' ) );
			
		endif;
	}
}	

class colabs_user_pack {

	var $id;
	var $user_id;		 	 	 	 	 	
	var $pack_name;		
	var $job_duration;
	var $pack_expires;	 	 	 	 	 	 	 	 	 	 
	var $job_count;		
	var $job_limit;		 	 	 	 	 	 	 
	var $pack_purchased;	 	 	 	 	 	 	 	 	 	
	
	function colabs_user_pack( $id='' ) {
		$this->id = (int) $id;
	}
	
	function get_valid_pack() {
		global $wpdb;
		$result = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."colabs_customer_packs WHERE id = ".$this->id." AND ".get_current_user_id()." AND jobs_count < jobs_limit AND (pack_expires > NOW() OR pack_expires = NULL OR pack_expires = '0000-00-00 00:00:00')");
		if ($result) : 	 	 	 	 	
			$this->user_id 		= $result->user_id; 	 	 	 	 	 	
			$this->pack_name 	= $result->pack_name;	 	 	 	 
			$this->job_duration = $result->job_duration; 	 	 	 
			$this->pack_expires = $result->pack_expires; 	
			$this->job_count 	= $result->jobs_count;	
			$this->job_limit 	= $result->jobs_limit;
			$this->pack_purchased = $result->pack_purchased;
			return true;	
		else :
			return false;
		endif;
	}
	
	function inc_job_count() {
		global $wpdb;
		$wpdb->update( $wpdb->prefix . "colabs_customer_packs", array( 'jobs_count' => ($this->job_count+1) ), array( 'id' => $this->id ), array( '%d' ), array( '%d' ) );
	}
}