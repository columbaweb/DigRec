<?php

// Register widgetized areas

if (!function_exists('the_widgets_init')) {
	function the_widgets_init() {
	    if ( !function_exists('register_sidebars') )
	        return;
    //Sidebar
	  register_sidebar(array(
		'name'          => sprintf(__('Main Sidebar','colabsthemes') ),
		'id'            => 'sidebar_main',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	  ));
	  
    register_sidebar(array(
        'name'          => __('Blog Sidebar','colabsthemes'),
        'id'            => 'sidebar_blog',
        'description'   => __('Appear on Blog Page','colabsthemes'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Page Sidebar','colabsthemes'),
        'id'            => 'sidebar_page',
        'description'   => __('Appear on Pages','colabsthemes'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Job Sidebar','colabsthemes'),
        'id'            => 'sidebar_job',
        'description'   => __('Appear on Jobs Page','colabsthemes'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
	register_sidebar(array(
        'name'          => __('User Sidebar','colabsthemes'),
        'id'            => 'sidebar_user',
        'description'   => __('Appear on User Dashboard','colabsthemes'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => __('Submit Job Sidebar','colabsthemes'),
        'id'            => 'sidebar_submit',
        'description'   => __('Appear on Submit Job Page','colabsthemes'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Resume Sidebar','colabsthemes'),
        'id'            => 'sidebar_resume',
        'description'   => __('Appear on Resume Page','colabsthemes'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
	

    }
}

add_action( 'init', 'the_widgets_init' );

// include the submit a job sidebar button via a hook
function colabs_sidebar_sjob() {
	if ('resume' == get_post_type() || is_post_type_archive('resume') || is_tax( 'resume_speciadivties' ) || is_tax( 'resume_groups' ) || is_tax( 'resume_languages' ) || is_tax( 'resume_speciadivties' ) || is_tax( 'resume_category' ) || is_tax( 'resume_job_type' ) ) :
		get_template_part( 'includes/sidebar-sresume' );
	else :
		get_template_part( 'includes/sidebar-sjob' );
	endif;
}
// hook into the correct action
add_action('colabsthemes_before_sidebar_widgets', 'colabs_sidebar_sjob');



    
?>