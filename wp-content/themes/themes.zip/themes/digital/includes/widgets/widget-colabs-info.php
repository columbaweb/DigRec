<?php
/*---------------------------------------------------------------------------------*/
/* Info widget */
/*---------------------------------------------------------------------------------*/
class CoLabs_Info extends WP_Widget {

   function CoLabs_Info() {
	   $widget_ops = array('description' => 'Widget with a simple address information.' );
       parent::WP_Widget(false, __('ColorLabs - Address Info', 'colabsthemes'),$widget_ops);      
   }

   function widget($args, $instance) {  
    extract( $args );
   	$title = apply_filters('widget_title', $instance['title'] );
	?>
		<?php echo $before_widget; ?>
        <?php if ($title) { echo $before_title . $title . $after_title; } 
		$text = '<p>' . $instance['desc'] . '</p>';
		$text .= '
		<p>
				<a class="geotag" href="#">Offline Store</a><br>
				' . $instance['address'] . ',<br>
				' . $instance['city'] . ', ' . $instance['state'] . ' ' . $instance['zip-code'] . '<br>
				Phone +1 123.456.789
		</p>
		'; 
		
		echo $text . $after_widget;
		?>   
   <?php
   }

   function update($new_instance, $old_instance) {                
       $instance = $old_instance;

		$instance['title'] = strip_tags( $new_instance['title'] );

		$instance['desc'] = strip_tags( $new_instance['desc'] );

		$instance['address'] = $new_instance['address'];

		$instance['zip-code'] = $new_instance['zip-code'];

		$instance['state'] = $new_instance['state'];

		$instance['city'] = $new_instance['city'];
		
		$instance['phone'] = $new_instance['phone'];

		return $instance;
   }

   function form($instance) {        
   
       $defaults = array( 
            'title' => __( 'Our Store', 'colabsthemes' ),
            'desc' => 'ColorLabs',
            'address' => 'Cemara 42 Street',
            'zip-code' => '1234',
            'state' => 'Jawa Barat',
            'city' => 'Bandung',
			'phone' => '+1 123.456.789'
        );
        
		$instance = wp_parse_args( (array) $instance, $defaults );

       ?>
       <p>
	   	   <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','colabsthemes'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
       </p>
	   <p>
			<label><?php _e( 'Description', 'colabsthemes' ) ?>:
				<textarea id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name( 'desc' ); ?>" ><?php echo $instance['desc']; ?></textarea>
			</label>
        </p>             
		
		<p>
			<label><?php _e( 'Address', 'colabsthemes' ) ?>:
				<input type="text" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" value="<?php echo $instance['address']; ?>" />
			</label>
        </p>             
		
		<p>
			<label><?php _e( 'Zip Code', 'colabsthemes' ) ?>:
				<input type="text" id="<?php echo $this->get_field_id( 'zip-code' ); ?>" name="<?php echo $this->get_field_name( 'zip-code' ); ?>" value="<?php echo $instance['zip-code']; ?>" />
			</label>
        </p>             
		
		<p>
			<label><?php _e( 'State', 'colabsthemes' ) ?>:
				<input type="text" id="<?php echo $this->get_field_id( 'state' ); ?>" name="<?php echo $this->get_field_name( 'state' ); ?>" value="<?php echo $instance['state']; ?>" />
			</label>
        </p>             
		
		<p>
			<label><?php _e( 'City', 'colabsthemes' ) ?>:
				<input type="text" id="<?php echo $this->get_field_id( 'city' ); ?>" name="<?php echo $this->get_field_name( 'city' ); ?>" value="<?php echo $instance['city']; ?>" />
			</label>
        </p> 
		<p>
			<label><?php _e( 'Phone', 'colabsthemes' ) ?>:
				<input type="text" id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" value="<?php echo $instance['phone']; ?>" />
			</label>
        </p> 
      <?php
   }
} 

register_widget('CoLabs_Info');
?>