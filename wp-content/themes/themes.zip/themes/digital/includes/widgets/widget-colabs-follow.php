<?php
/*---------------------------------------------------------------------------------*/
/* Follow widget */
/*---------------------------------------------------------------------------------*/
class CoLabs_Follow extends WP_Widget {

   function CoLabs_Follow() {
	   $widget_ops = array('description' => 'Follow widget.' );
       parent::WP_Widget(false, __('ColorLabs - Follow', 'colabsthemes'),$widget_ops);      
   }

   function widget($args, $instance) {  
    extract( $args );
   	$title = apply_filters('widget_title', $instance['title'] );
	$twitter = $instance['twitter'];
	$facebook = $instance['facebook'];
	$linkedin = $instance['linkedin'];
	$skype = $instance['skype'];
	$flickr = $instance['flickr'];
    $email = $instance['email'];
	?>
		<?php echo $before_widget; ?>
        <?php if ($title) { echo $before_title . $title . $after_title; }else {echo $before_title .__('Follow Us','colabsthemes'). $after_title;} ?>
        <ul class="social-icon">
    	   <?php if ($twitter!=''){?><li><a class="twitter" href="<?php echo $twitter;?>">Twitter</a></li><?php } ?>
    	    <?php if ($facebook!=''){?><li><a class="facebook" href="<?php echo $facebook;?>">Facebook</a></li><?php } ?>
    	    <?php if ($linkedin!=''){?><li><a class="linkedin" href="<?php echo $linkedin;?>">Linkedin</a></li><?php } ?>
			<?php if ($skype!=''){?><li><a class="skype" href="<?php echo $skype;?>">Skype</a></li><?php } ?>
			<?php if ($email!=''){?><li><a href="<?php echo $email;?>" class="mail">Mail</a></li><?php }?>
    	    <li><a class="rss" href="<?php if(get_option("colabs_feedlinkurl") != ''){ echo get_option("colabs_feedlinkurl"); }else{ bloginfo("rss2_url"); }?>">RSS</a></li>
    		
		</ul>
		<?php echo $after_widget; ?>
   <?php
   }

   function update($new_instance, $old_instance) {
       return $new_instance;
   }

   function form($instance) {
   
        $title = esc_attr($instance['title']);
		$twitter = esc_attr($instance['twitter']);
		$facebook = esc_attr($instance['facebook']);
		$linkedin = esc_attr($instance['linkedin']);
		$skype = esc_attr($instance['skype']);
        $email = esc_attr($instance['email']);
       ?>
        <p><?php _e( 'You can set your social id\'s in theme panel.','colabsthemes' );?></p>
		<p>
	   	   <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','colabsthemes'); ?></label>
           <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
       </p>
	   <p>
	   	   <label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter:','colabsthemes'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('twitter'); ?>"  value="<?php echo $twitter; ?>" class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" />
       </p>
	   <p>
	   	   <label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook:','colabsthemes'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('facebook'); ?>"  value="<?php echo $facebook; ?>" class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" />
       </p>
	   <p>
	   	   <label for="<?php echo $this->get_field_id('linkedin'); ?>"><?php _e('Linkedin:','colabsthemes'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('linkedin'); ?>"  value="<?php echo $linkedin; ?>" class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" />
       </p>
	   <p>
	   	   <label for="<?php echo $this->get_field_id('skype'); ?>"><?php _e('Skype:','colabsthemes'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('skype'); ?>"  value="<?php echo $skype; ?>" class="widefat" id="<?php echo $this->get_field_id('skype'); ?>" />
       </p>
	   <p>
	   	   <label for="<?php echo $this->get_field_id('email'); ?>"><?php _e('Email:','colabsthemes'); ?></label>
	       <input type="text" name="<?php echo $this->get_field_name('email'); ?>"  value="<?php echo $email; ?>" class="widefat" id="<?php echo $this->get_field_id('email'); ?>" />
       </p>
      <?php
   }
} 

register_widget('CoLabs_Follow');
?>