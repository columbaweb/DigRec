<?php

add_action('colabs_dashboard_bottom', 'colabs_system_info');

// system information page
function colabs_system_info() {
    global $system_info, $wpdb;
?>
    <style>
    div.jobjockey #tabs-wrap div{margin-bottom: 15px;}
    </style>
        
    <div class="clear"></div>
    
    <div class="wrap jobjockey">
        <?php
        // delete all the db tables if the button has been pressed.
        if (isset($_POST['deletetables']))
            colabsthemes_delete_db_tables();

        // delete all the config options from the wp_options table if the button has been pressed.
        if (isset($_POST['deleteoptions']))
            colabsthemes_delete_all_options();
        ?>

        <div id="tabs-wrap">

			<div id="tab1">
                <table class="widefat fixed" style="width:850px;">

                    <thead>
                        <tr>
                            <th scope="col" width="200px"><?php _e('Debug Info','colabsthemes')?></th>
                            <th scope="col">&nbsp;</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td class="titledesc"><?php _e('JobJockey Version','colabsthemes')?></td>
                            <td class="forminp"><?php echo get_option('colabs_version'); ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('WordPress Version','colabsthemes')?></td>
                            <td class="forminp"><?php if (colabsthemes_is_wpmu()) echo 'WPMU'; else echo 'WP'; ?> <?php if(function_exists('bloginfo')) echo bloginfo('version'); ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('PHP Version','colabsthemes')?></td>
                            <td class="forminp"><?php if(function_exists('phpversion')) echo phpversion(); ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('Server Software','colabsthemes')?></td>
                            <td class="forminp"><?php echo $_SERVER['SERVER_SOFTWARE']; ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('UPLOAD_MAX_FILESIZE','colabsthemes')?></td>
                            <td class="forminp"><?php 
                            	if(function_exists('phpversion') && function_exists('let_to_num')){ echo (let_to_num(ini_get('upload_max_filesize'))/(1024*1024))."MB"; }else 
                                if(function_exists('phpversion') && function_exists('ini_get')){ echo ini_get('upload_max_filesize'); }
                            ?></td>
                        </tr>
                        
                        <tr>
                            <td class="titledesc"><?php _e('POST_MAX_SIZE','colabsthemes')?></td>
                            <td class="forminp"><?php 
                            	if(function_exists('phpversion') && function_exists('let_to_num')){ echo (let_to_num(ini_get('post_max_size'))/(1024*1024))."MB"; }else
                                if(function_exists('phpversion') && function_exists('ini_get')){ echo ini_get('upload_max_filesize'); }
                            ?></td>
                        </tr>
                        
                         <tr>
                            <td class="titledesc"><?php _e('WordPress Memory Limit','colabsthemes')?></td>
                            <td class="forminp"><?php 
                                if(function_exists('phpversion') && function_exists('let_to_num')){ echo (let_to_num(WP_MEMORY_LIMIT)/(1024*1024))."MB"; }else
                                if(function_exists('phpversion') && function_exists('ini_get')){ echo WP_MEMORY_LIMIT; }
                            ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('DISPLAY_ERRORS','colabsthemes')?></td>
                            <td class="forminp"><?php if(function_exists('phpversion')) echo ini_get('display_errors'); ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('FSOCKOPEN Check','colabsthemes')?></td>
                            <td class="forminp"><?php if(function_exists('fsockopen')) echo '<span style="color:green">' . __('Your server has fsockopen enabled which is needed for PayPal IPN to work.', 'colabsthemes'). '</span>'; else echo '<span style="color:red">' . __('Your server does not have fsockopen enabled so PayPal IPN will not work. Contact your host provider to have it enabled.', 'colabsthemes'). '</span>'; ?></td>
                        </tr>

						<tr>
                            <td class="titledesc"><?php _e('OPENSSL Check','colabsthemes')?></td>
                            <td class="forminp"><?php if(function_exists('openssl_open')) echo '<span style="color:green">' . __('Your server has Open SSL enabled which is needed for PayPal IPN to work. Also make sure port 443 is open on the firewall.', 'colabsthemes'). '</span>'; else echo '<span style="color:red">' . __('Your server does not have Open SSL enabled so PayPal IPN will not work. Contact your host provider to have it enabled.', 'colabsthemes'). '</span>'; ?></td>
                        </tr>
                        
                        <tr>
                            <td class="titledesc"><?php _e('WP Remote Post Check','colabsthemes')?></td>
                            <td class="forminp"><?php
								$paypal_adr = 'https://www.paypal.com/cgi-bin/webscr';
								$params = array( 
									'timeout' 	=> 30
								);	
								$response = wp_remote_post( $paypal_adr, $params );
								
								// Retry
								if ( is_wp_error($response) ) {
									$params['sslverify'] = false;
									$response = wp_remote_post( $paypal_adr, $params );
								}
                            	 
                            	if ( !is_wp_error($response) && $response['response']['code'] >= 200 && $response['response']['code'] < 300 ) echo '<span style="color:green">' . __('wp_remote_post() was successful so PayPal IPN should work fine for you!', 'colabsthemes'). '</span>'; else echo '<span style="color:red">' . __('wp_remote_post() failed. Sorry, PayPal IPN won\'t work with your server.', 'colabsthemes'). '</span>';
                            ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('Log File Check','colabsthemes')?></td>
                            <td class="forminp">
                            	<?php
                            		$logging_enabled = get_option('colabs_enable_log');
		
									if ($logging_enabled=='true') :
										$fp = fopen(TEMPLATEPATH . '/log/jobjockey_log.txt', 'a');
										if ($fp) :
											 echo '<span style="color:green">' . __('Log file is writable.', 'colabsthemes'). '</span>';
										else :
											echo '<span style="color:red">' . __('Log file is not writable. Edit file permissions (jobjockey/log/jobjockey_log.txt)', 'colabsthemes'). '</span>';
										endif;
										fclose($fp); 
									else :
										echo 'Logging is disabled - <a href="admin.php?page=colabsthemes_options#colabs-option-jobjockeysettings">' . __('(change this)', 'colabsthemes') . '</a>';
									endif;
								?>
                            </td>
                        </tr>

                        

                        <tr>
                            <td class="titledesc"><?php _e('Theme Path','colabsthemes')?></td>
                            <td class="forminp"><?php if(function_exists('bloginfo')) { echo bloginfo('template_url'); } ?></td>
                        </tr>

                        <tr>
                            <td class="titledesc"><?php _e('Image Upload Path','colabsthemes')?></td>
                            <td class="forminp"><?php if(!esc_attr(get_option('upload_path'))) echo 'wp-content/uploads'; else echo esc_attr(get_option('upload_path')); ?><?php printf( ' - <a href="%s">' . __('(change this)', 'colabsthemes') . '</a>', 'options-media.php' ); ?></td>                        </tr>

                </tbody>

                </table>
            </div>
            
            <div id="tab2">
				<table class="widefat fixed" style="width:850px;">
					<thead>
						<tr>
							<th scope="col"><?php _e('Cron Jobs','colabsthemes')?></th>
							<th scope="col"><?php _e('Frequency','colabsthemes')?></th>
							<th scope="col"><?php _e('Hook Name','colabsthemes')?></th>
						</tr>
					</thead>
					<tbody>
						<?php
							$cron = _get_cron_array();
							$schedules = wp_get_schedules();
							$date_format = _x( 'M j, Y @ G:i', 'colabsthemes', 'colabsthemes');
							foreach ( $cron as $timestamp => $cronhooks ) {
								foreach ( (array) $cronhooks as $hook => $events ) {
									foreach ( (array) $events as $key => $event ) {
										$cron[ $timestamp ][ $hook ][ $key ][ 'date' ] = date_i18n( $date_format, $timestamp );
									}
								}
							}
						?>
						<?php foreach ( $cron as $timestamp => $cronhooks ) { ?>
							<?php foreach ( (array) $cronhooks as $hook => $events ) { ?>
								<?php foreach ( (array) $events as $event ) { ?>
									<tr>
										<th scope="row"><?php echo $event[ 'date' ]; ?></th>
										<td>
											<?php 
												if ( $event[ 'schedule' ] ) {
													echo $schedules [ $event[ 'schedule' ] ][ 'display' ]; 
												} else {
													?><em><?php _e('One-off event','colabsthemes')?></em><?php
												}
											?>
										</td>
										<td><?php echo $hook; ?></td>
									</tr>
								<?php } ?>
							<?php } ?>
						<?php } ?>
					</tbody>
				</table>
            </div>
            
            <div id="tab3">
                <table class="widefat fixed" style="width:850px;">

                     <thead>
                        <tr>
                            <th scope="col" width="200px"><?php _e('Uninstall JobJockey','colabsthemes')?></th>
                            <th scope="col">&nbsp;</th>
                        </tr>
                    </thead>

                <form method="post" id="mainform" action="">
                    <tr>
                        <td class="titledesc"><?php _e('Delete Database Tables','colabsthemes')?></td>
                        <td class="forminp">
                            <p class="submit"><input onclick="return confirmBeforeDeleteTbls();" name="save" type="submit" value="<?php _e('Delete JobJockey Database Tables','colabsthemes') ?>" /><br />
                        <?php _e('Do you wish to completely delete all JobJockey database tables? Once you do this you will lose any transaction data you have stored.','colabsthemes')?>
                            </p>
                            <input name="deletetables" type="hidden" value="yes" />
                        </td>
                    </tr>
                </form>

                <form method="post" id="mainform" action="">
                    <tr>
                        <td class="titledesc"><?php _e('Delete Config Options','colabsthemes')?></td>
                        <td class="forminp">
                            <p class="submit"><input onclick="return confirmBeforeDeleteOptions();" name="save" type="submit" value="<?php _e('Delete JobJockey Config Options','colabsthemes') ?>" /><br />
                        <?php _e('Do you wish to completely delete all JobJockey configuration options? This will delete all values saved on the settings, pricing, gateways, etc admin pages from the wp_options database table.','colabsthemes')?>
                            </p>
                            <input name="deleteoptions" type="hidden" value="yes" />
                        </td>
                    </tr>
                </form>

                </table>
            </div>
		
        </div><!--/#tabs-wrap-->

    </div><!--/.wrap-->

    <script type="text/javascript">
    /* <![CDATA[ */
        function confirmBeforeDeleteTbls() { return confirm("<?php _e('WARNING: You are about to completely delete all JobJockey database tables. Are you sure you want to proceed? (This cannot be undone)', 'colabsthemes'); ?>"); }
        function confirmBeforeDeleteOptions() { return confirm("<?php _e('WARNING: You are about to completely delete all JobJockey configuration options from the wp_options database table. Are you sure you want to proceed? (This cannot be undone)', 'colabsthemes'); ?>"); }
    /* ]]> */
    </script>

    <div class="clear"></div>
    
<?php
}
    
?>