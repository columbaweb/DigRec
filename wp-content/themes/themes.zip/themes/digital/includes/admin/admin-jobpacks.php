<?php
add_action( 'admin_menu', 'job_packs_create_menu', 20 );

function job_packs_create_menu() { 
	
	$pack_page = add_submenu_page('colabsthemes', __( 'Job Packs', 'colabsthemes' ), __( 'Job Packs', 'colabsthemes' ), 'manage_options', 'jobpacks', 'colabs_job_packs_admin' );
	
	add_action( 'admin_print_styles-' . $pack_page, 'pack_admin_style');
	add_action( 'admin_print_scripts-' . $pack_page, 'pack_admin_scripts' );
	
	
}

// job pack options admin page
function colabs_job_packs_admin() {
    ?>
    <div class="wrap jobjockey">
        <div class="icon32" id="icon-options-general"><br/></div>
        <h2><?php _e('Job Packs','colabsthemes') ?></h2>

        <?php 
        	global $wpdb;
        	
        	if ( isset($_GET['edit']) ) :
				colabs_edit_job_pack();
			else :
				if ( isset($_GET['delete']) ) :
					$deletepack = (int) $_GET['delete'];
					if ($deletepack > 0) :
						$wpdb->query("DELETE FROM ".$wpdb->prefix."colabs_job_packs WHERE id = ".$deletepack." LIMIT 1;");
						echo '<p class="success">'.__('Pack Deleted','colabsthemes').'</p>';
					endif;
				endif;
				colabs_job_packs();
			endif;
		?>	
    </div>
	<?php
}

function colabs_job_packs() {
	
	global $message, $errors, $posted;
	$errors = new WP_Error();
	$message = '';
	colabs_add_job_pack(); 

	$packs = colabs_get_job_packs();
	
	if (sizeof($packs)>0) :
		echo '<ul class="packs">';
		foreach ($packs as $pack) :
			
			if (!$pack->job_count) $pack->job_count = __('Unlimited', 'colabsthemes');
			
			if ($pack->pack_duration) $pack->pack_duration = __(' usable within ', 'colabsthemes').$pack->pack_duration.__(' days', 'colabsthemes');
			
			if ($pack->job_duration) $pack->job_duration = __(' lasting ', 'colabsthemes').$pack->job_duration.__(' days' ,'colabsthemes');
			
			if ($pack->pack_cost) :
				$pack->pack_cost = colabs_get_currency($pack->pack_cost).'';
			else :
				$pack->pack_cost = __('Free','colabsthemes');
			endif; 
			
			echo '<li>
        <h3>'.$pack->pack_name.'<small>'.$pack->pack_description.'</small><span class="cost">'.$pack->pack_cost.'</span></h3>
				<div class="pack-content"><p>'.$pack->job_count.' '.__('Jobs', 'colabsthemes').''.$pack->job_duration.$pack->pack_duration.'.</p></div>
        <div class="pack-action">
				  <a href="admin.php?page=jobpacks&amp;edit='.$pack->id.'">
            <img src="'.get_template_directory_uri().'/images/icon/icon-edit.png"> Edit
          </a>
				  <a href="admin.php?page=jobpacks&amp;delete='.$pack->id.'" class="deletepack">
            <img src="'.get_template_directory_uri().'/images/icon/icon-trash.png"> Delete
          </a>
        </div>
			</li>';
		endforeach;
		echo '</ul>';
	endif;
    ?>
    <script type="text/javascript">
    /* <![CDATA[ */
    	jQuery('a.deletepack').click(function(){
    		var answer = confirm ("<?php _e('Are you sure you want to delete this pack? This action cannot be undone...', 'colabsthemes'); ?>")
			if (answer)
				return true;
			return false;
    	});
    /* ]]> */
    </script>
	 
    <!-- Styles for Job Packs List -->
    <style type="text/css">
      .packs { *zoom: 1; padding-left: 0 }
      .packs:after { clear: both; }
      .packs:before, .packs:after {
        content: "";
        display: table;
      }
      .packs li {
        float: left;
        width: 300px;
        position: relative;
        margin-right: 15px;
        border-radius: 3px;
        background: #f5f5f5;
        border: 1px solid #888;
      }
      .packs h3 {
        margin: 0;
        position: relative;
        padding: 10px 10px 10px 60px;
        border-bottom: 1px solid #888;
        -webkit-border-radius: 3px 3px 0 0;
           -moz-border-radius: 3px 3px 0 0;
                border-radius: 3px 3px 0 0;
      }
      .packs h3, .pack-action {
        color: #555;
        text-shadow: 0 1px rgba(255,255,255,.5);
        -webkit-box-shadow: 0 1px rgba(255,255,255,.15) inset, 0 1px 1px 1px rgba(255,255,255,.19) inset;
           -moz-box-shadow: 0 1px rgba(255,255,255,.15) inset, 0 1px 1px 1px rgba(255,255,255,.19) inset;
                box-shadow: 0 1px rgba(255,255,255,.15) inset, 0 1px 1px 1px rgba(255,255,255,.19) inset;

        background: #e8e8e8;
        background: -o-linear-gradient(top, #e8e8e8 0%,#b9b9b9 100%);
        background: -ms-linear-gradient(top, #e8e8e8 0%,#b9b9b9 100%);
        background: -moz-linear-gradient(top, #e8e8e8 0%, #b9b9b9 100%);
        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#e8e8e8), color-stop(100%,#b9b9b9));
        background: -webkit-linear-gradient(top, #e8e8e8 0%,#b9b9b9 100%);
        background: linear-gradient(top, #e8e8e8 0%,#b9b9b9 100%);
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e8e8e8', endColorstr='#b9b9b9',GradientType=0 ); /* IE6-9 */
      }
      .packs h3 small {
        display: block;
      }
      .packs .cost {
        top: 0;
        bottom: 0;
        left: 10px;
        color: #fff;
        width: 40px;
        font-size: 14px;
        line-height: 38px;
        font-weight: bold;
        text-align: center;
        position: absolute;
        background: #0172B3;
        text-shadow: 0 1px rgba(0,0,0,.4);
      }
      .packs .cost:before {
        content: "";
        position: absolute;
        border: 20px solid;
        border-color: #0172B3 transparent transparent transparent;
        bottom: -28px;
        left: 0;
      }
      .pack-content {
        padding: 0 10px;
        overflow: hidden;
        margin-bottom: 10px;
      }
      .pack-action {
        padding: 3px 10px;
        border-top: 1px solid #888;
        border-radius: 0 0 3px 3px;
      }
      .pack-action a {
        color: #000;
        margin-right: 15px;
        text-decoration: none;
      }
      .pack-action img {
        top: -1px;
        height: 10px;
        position: relative;
        vertical-align: middle;
      }
    </style>

	<h3><?php _e('Create a New Job Pack','colabsthemes') ?></h3>
	<p><?php _e('Job Packs let you define packages that customers can purchase in order to post multiple/single jobs for varying durations. Once you add a pack the values on the "pricing" page will no longer be used.', 'colabsthemes'); ?></p>
	
	<?php
		colabs_show_errors( $errors );
		
		if (isset($message) && !empty($message)) {
			echo '<p class="success">'.$message.'</p>';
		}
	?>
    <form method="post" id="mainform" action="">
		
		<table class="widefat fixed" id="tblspacer" style="width:850px;">

                <thead>
                    <tr>
                        <th scope="col" width="200px"><?php _e('Job Pack Details','colabsthemes')?></th>
                        <th scope="col">&nbsp;</th>
                    </tr>
                </thead>

		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a name for this pack. This will be visible on the website','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Name','colabsthemes') ?>:</td>
                <td class="forminp"><input name="pack_name" id="pack_name" type="text" value="<?php if (isset($posted['pack_name'])) echo $posted['pack_name']; ?>" class="required" /></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a description for this pack. This will be visible on the website','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Description','colabsthemes') ?>:</td>
                <td class="forminp"><input name="pack_description" id="pack_description" type="text" value="<?php if (isset($posted['pack_description'])) echo $posted['pack_description']; ?>" class="required" /></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter the number of days','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Duration','colabsthemes') ?>:</td>
                <td class="forminp"><input name="pack_duration" id="pack_duration" type="text" value="<?php if (isset($posted['pack_duration'])) echo $posted['pack_duration']; ?>" /><br/><small><?php _e('Days this pack remains valid to use. Leave blank if it never expires.','colabsthemes') ?></small></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a numeric value, do not include currency values.','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Cost','colabsthemes') ?>:</td>
                <td class="forminp"><input name="pack_cost" id="pack_cost" type="text" value="<?php if (isset($posted['pack_cost'])) echo $posted['pack_cost']; ?>"  /><br/><small><?php _e('Pack cost. Leave blank if free.','colabsthemes') ?></small></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a numeric value or leave blank','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Job Count','colabsthemes') ?>:</td>
                <td class="forminp"><input name="job_count" id="job_count" type="text" value="<?php if (isset($posted['job_count'])) echo $posted['job_count']; ?>"  /><br/><small><?php _e('How many jobs can the user list with this pack? Leave blank for an <em>unlimited</em> amount.','colabsthemes') ?></small></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a numeric value or leave blank','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Job Duration','colabsthemes') ?>:</td>
                <td class="forminp"><input name="job_duration" id="job_duration" type="text" value="<?php if (isset($posted['job_duration'])) echo $posted['job_duration']; ?>" class="required" /><br/><small><?php _e('How long do jobs last? e.g. <code>30</code> for 30 days. Leave blank for endless jobs.','colabsthemes') ?></small></td>
		    </tr>
		
	    </table>

        <p class="submit bbot"><input name="save" type="submit" value="<?php _e('Create Job Pack','colabsthemes') ?>" />
        <input name="submitted" type="hidden" value="yes" /></p>
    </form>
    <?php
}

function colabs_edit_job_pack() {

	global $wpdb, $message, $errors;
	$errors = new WP_Error();
	$message = '';
	
	$edited_pack = (int) $_GET['edit'];
	
	if (!$edited_pack) :
		_e('Pack not found!', 'colabsthemes');
		exit;
	endif;
	
	// Get Job details
	$job_pack = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."colabs_job_packs WHERE id = ".$edited_pack."");
	
	if (!$job_pack) :
		_e('Pack not found!', 'colabsthemes');
		exit;
	endif;
	
	if ($_POST) :
		
		$posted = array();
		
		$fields = array(
			'pack_name',
			'pack_description',
			'pack_duration',
			'pack_cost',
			'job_count',
			'job_duration'
		);
		
		foreach ($fields as $field) :
			if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field]));
			else $posted[$field] = '';
		endforeach;
		
		$required = array(
			'pack_name' => __('Pack name', 'colabsthemes'),
			'pack_description' => __('Pack Description', 'colabsthemes'),
		);
		
		foreach ($required as $field=>$name) {
			if (empty($posted[$field])) {
				$errors->add('submit_error', __('<strong>ERROR</strong>: &ldquo;', 'colabsthemes').$name.__('&rdquo; is a required field.', 'colabsthemes'));
			}
		}
		
		if ($errors && sizeof($errors)>0 && $errors->get_error_code()) {} else {
			
			$wpdb->update( $wpdb->prefix . 'colabs_job_packs', array( 
				'pack_name' 		=> $posted['pack_name'],
				'pack_description' 	=> $posted['pack_description'],
				'pack_duration' 	=> $posted['pack_duration'],
				'pack_cost' 		=> $posted['pack_cost'],
				'job_count' 		=> $posted['job_count'],
				'job_duration'		=> $posted['job_duration'],
			), array( 'id' => $edited_pack ), array( '%s','%s','%s','%s','%s','%s' ) );
			
			$message = __('Pack updated successfully', 'colabsthemes');
			
			$job_pack = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."colabs_job_packs WHERE id = ".$edited_pack."");
		
		}
		
	endif;
    ?>
	
	<h3><?php _e('Edit Job Pack','colabsthemes') ?></h3>
	
	<?php
		colabs_show_errors( $errors );
		
		if (isset($message) && !empty($message)) {
			echo '<p class="success">'.$message.'</p>';
		}
	?>
	
    <form method="post" id="mainform" action="">
		
		<table class="widefat fixed" id="tblspacer" style="width:850px;">

                <thead>
                    <tr>
                        <th scope="col" width="200px"><?php _e('Job Pack Details','colabsthemes')?></th>
                        <th scope="col">&nbsp;</th>
                    </tr>
                </thead>

		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a name for this pack. This will be visible on the website','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Name','colabsthemes') ?>:</td>
                <td class="forminp"><input style="width:300px;" name="pack_name" id="pack_name" type="text" value="<?php echo $job_pack->pack_name; ?>" class="required" /></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a description for this pack. This will be visible on the website','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Description','colabsthemes') ?>:</td>
                <td class="forminp"><input style="width:500px;" name="pack_description" id="pack_description" type="text" value="<?php echo $job_pack->pack_description; ?>" class="required" /></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter the number of days','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Duration','colabsthemes') ?>:</td>
                <td class="forminp"><input name="pack_duration" id="pack_duration" type="text" value="<?php echo $job_pack->pack_duration; ?>" /><br/><small><?php _e('Days this pack remains valid to use. Leave blank if it never expires.','colabsthemes') ?></small></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a numeric value, do not include currency values.','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Pack Cost','colabsthemes') ?>:</td>
                <td class="forminp"><input name="pack_cost" id="pack_cost" type="text" value="<?php echo $job_pack->pack_cost; ?>" /><br/><small><?php _e('Pack cost. Leave blank if free.','colabsthemes') ?></small></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a numeric value or leave blank','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Job Count','colabsthemes') ?>:</td>
                <td class="forminp"><input name="job_count" id="job_count" type="text" value="<?php echo $job_pack->job_count; ?>" /><br/><small><?php _e('How many jobs can the user list with this pack? Leave blank for an <em>unlimited</em> amount.','colabsthemes') ?></small></td>
		    </tr>
		    <tr>
                <td class="titledesc"><a href="#" tip="<?php _e('Enter a numeric value or leave blank','colabsthemes') ?>" tabindex="99"><div class="helpico"></div></a> <?php _e('Job Duration','colabsthemes') ?>:</td>
                <td class="forminp"><input name="job_duration" id="job_duration" type="text" value="<?php echo $job_pack->job_duration; ?>" class="required" /><br/><small><?php _e('How long do jobs last? e.g. <code>30</code> for 30 days.','colabsthemes') ?></small></td>
		    </tr>
		
	    </table>

        <p class="submit bbot"><input name="save" type="submit" value="<?php _e('Save Pack','colabsthemes') ?>" />
        <input name="submitted" type="hidden" value="yes" /></p>
    </form>

	<?php
}

function colabs_add_job_pack() {
	
	global $wpdb, $errors, $message, $posted;
	
	if ($_POST) :
		
		$posted = array();
		
		$fields = array(
			'pack_name',
			'pack_description',
			'pack_duration',
			'pack_cost',
			'job_count',
			'job_duration'
		);
		
		foreach ($fields as $field) :
			if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field]));
			else $posted[$field] = '';
		endforeach;
		
		$required = array(
			'pack_name' => __('Pack name', 'colabsthemes'),
			'pack_description' => __('Pack Description', 'colabsthemes'),
		);
		
		foreach ($required as $field=>$name) {
			if (empty($posted[$field])) {
				$errors->add('submit_error', __('<strong>ERROR</strong>: &ldquo;', 'colabsthemes').$name.__('&rdquo; is a required field.', 'colabsthemes'));
			}
		}
		
		if ($errors && sizeof($errors)>0 && $errors->get_error_code()) {} else {
			
			$wpdb->insert( $wpdb->prefix . 'colabs_job_packs', array( 
				'pack_name' 		=> $posted['pack_name'],
				'pack_description' 	=> $posted['pack_description'],
				'pack_duration' 	=> $posted['pack_duration'],
				'pack_cost' 		=> $posted['pack_cost'],
				'job_count' 		=> $posted['job_count'],
				'job_duration'		=> $posted['job_duration'],
			), array( '%s','%s','%s','%s','%s','%s' ) );
			
			$message = __('Pack added successfully', 'colabsthemes');
		
		}
		
	endif;
}
?>