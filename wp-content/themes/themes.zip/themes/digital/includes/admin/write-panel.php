<?php

//colabs_geolocation_scripts();

global $meta_boxes, $key;

$key = 'job_meta';
$meta_boxes = array(
	'Expire' => array(
		'name' => '_expires',
		'title' => __('Job Expiry date', 'colabsthemes'),
		'description' => __('The date/time the job expires.', 'colabsthemes'),
		'type' => 'datetime'
	),
	'Company' => array(
		'name' => '_Company',
		'title' => __('Your Name/Company Name', 'colabsthemes'),
		'description' => __('The name of the company advertising the job.', 'colabsthemes')
	),
	'CompanyURL' => array(
		'name' => '_CompanyURL',
		'title' => __('Website', 'colabsthemes'),
		'description' => __('Website URL of the company advertising the job.', 'colabsthemes')
	)
);

if (get_option('colabs_submit_how_to_apply_display')=='true') :
	$apply_meta_boxes = array('How to Apply' => array(
		'name' => '_how_to_apply',
		'title' => __('How to Apply', 'colabsthemes'),
		'description' => __('Details on how to apply to the job.', 'colabsthemes'),
		'type' => 'textarea'
	));
	$meta_boxes = array_merge($meta_boxes, $apply_meta_boxes);
endif;

function colabs_create_meta_box() {
	global $key;

	if( function_exists( 'add_meta_box' ) ) add_meta_box( 'new-meta-boxes', __('Job Meta', 'colabsthemes'), 'colabs_display_meta_box', 'job_listing', 'normal', 'high' );
	if( function_exists( 'add_meta_box' ) ) add_meta_box( 'location-meta-boxes', __('Job Location', 'colabsthemes'), 'colabs_display_location_meta_box', 'job_listing', 'side', 'high' );
}

function colabs_display_meta_box() {
	global $post, $meta_boxes, $key;
	?>
	
<div class="panel-wrap">	
	<div class="form-wrap">
	
		<p><?php _e('These fields control parts of job listings. Rememeber also that: <code>title</code> = Job title, <code>content</code> = Job description, and Post thumbnail/image is used for the company logo.', 'colabsthemes'); ?></p>
	
		<?php
		wp_nonce_field( plugin_basename( __FILE__ ), $key . '_wpnonce', false, true );
		
		foreach($meta_boxes as $meta_box) {
			$data = get_post_meta($post->ID, $meta_box[ 'name' ], true);
			?>
			
			<div class="form-field form-required" style="margin:0; padding: 0 8px">
				<label for="<?php echo $meta_box[ 'name' ]; ?>" style="color: #666; padding-bottom: 8px; overflow:hidden; zoom:1; "><?php echo $meta_box[ 'title' ]; ?></label>
				<?php
					if (!isset($meta_box[ 'type' ])) $meta_box[ 'type' ] = 'input';
					
					switch($meta_box[ 'type' ]) :
						case "datetime" :
							if ($post->post_status<>'publish') :
								echo '<p>'.__('Post is not yet published','colabsthemes').'</p>';
							else :
								if ($data) $date = $data;
								//if (!$data) {
									// Date is 30 days after publish date (this is for backwards compatibility)
									//$date = strtotime('+30 day', strtotime($post->post_date));
								//}
								?>							
								<div style="float:left; margin-right: 10px; min-width: 320px;"><select name="<?php echo $meta_box[ 'name' ]; ?>_month">
									<option value=""></option>
									<?php
									for ($i = 1; $i <= 12; $i++) :
										echo '<option value="'.str_pad($i, 2, '0',STR_PAD_LEFT).'" ';
										if (isset($date) && date_i18n( 'F', $date)==date_i18n( 'F', strtotime('+'.$i.' month', mktime(0,0,0,12,1,2010)) )) echo 'selected="selected"';
										echo '>'. date_i18n( 'F', strtotime('+'.$i.' month', mktime(0,0,0,12,1,2010)) ) .'</option>';
									endfor;
									?>
								</select>
								<select name="<?php echo $meta_box[ 'name' ]; ?>_day">
									<option value=""></option>
									<?php
									for ($i = 1; $i <= 31; $i++) :
										echo '<option value="'.str_pad($i, 2, '0',STR_PAD_LEFT).'" ';
										if (isset($date) && date_i18n( 'd', $date)==str_pad($i, 2, '0',STR_PAD_LEFT)) echo 'selected="selected"';
										echo '>'. str_pad($i, 2, '0',STR_PAD_LEFT) .'</option>';
									endfor;
									?>
								</select>
								<select name="<?php echo $meta_box[ 'name' ]; ?>_year">
									<option value=""></option>
									<?php
									for ($i = 2010; $i <= 2020; $i++) :
										echo '<option value="'.$i.'" ';
										if (isset($date) && date_i18n( 'Y', $date)==$i) echo 'selected="selected"';
										echo '>'. $i .'</option>';
									endfor;
									?>
								</select> @ <input type="text" name="<?php echo $meta_box[ 'name' ]; ?>_hour" size="2" maxlength="2" style="width:2.5em" value="<?php if (isset($date)) echo date_i18n( 'H', $date) ?>" />:<input type="text" name="<?php echo $meta_box[ 'name' ]; ?>_min" size="2" maxlength="2" style="width:2.5em" value="<?php if(isset($date)) echo date_i18n( 'i', $date) ?>" /></div><?php if ($meta_box[ 'description' ]) echo wpautop(wptexturize($meta_box[ 'description' ])); ?>
								<?php
							endif;
						break;
                        
						case "textarea" :
							?>
							<textarea rows="4" cols="40" name="<?php echo $meta_box[ 'name' ]; ?>" style="width:98%; height:75px; margin-right: 10px; none"><?php echo htmlspecialchars( $data ); ?></textarea><?php if ($meta_box[ 'description' ]) echo wpautop(wptexturize($meta_box[ 'description' ])); ?>
							<?php
						break;
                        
						default :
							?>
							<input type="text" style="width:320px; margin-right: 10px; float:left" name="<?php echo $meta_box[ 'name' ]; ?>" value="<?php echo htmlspecialchars( $data ); ?>" /><?php if ($meta_box[ 'description' ]) echo wpautop(wptexturize($meta_box[ 'description' ])); ?>
							<?php
						break;
                        
					endswitch;
				?>				
				<div class="clear"></div>
			</div>
		
		<?php } ?>
	
	</div>
</div>	
	<?php
}

function colabs_save_meta_box( $post_id ) {
	global $post, $meta_boxes, $key;
	
	if ( !isset($_POST[ $key . '_wpnonce' ] ) ) return $post_id;
	if ( !wp_verify_nonce( $_POST[ $key . '_wpnonce' ], plugin_basename(__FILE__) ) ) return $post_id;
	
	if ( !current_user_can( 'edit_post', $post_id )) return $post_id;

	foreach( $meta_boxes as $meta_box ) {
		if ($meta_box[ 'name' ]=='_colabs_geo_latitude' || $meta_box[ 'name' ]=='_colabs_geo_longitude') {
			update_post_meta( $post_id, $meta_box[ 'name' ], colabs_clean_coordinate($_POST[ $meta_box[ 'name' ] ]) );
		
		} elseif ($meta_box['type']=='datetime') {
		
			$year = $_POST[ $meta_box[ 'name' ] . '_year' ];
			$month = $_POST[ $meta_box[ 'name' ] . '_month' ];
			$day = $_POST[ $meta_box[ 'name' ] . '_day' ];
			$hour = $_POST[ $meta_box[ 'name' ] . '_hour' ];
			$min = $_POST[ $meta_box[ 'name' ] . '_min' ];
			
			if (!$hour) $hour = '00';
			if (!$min) $min = '00';
			
			if ( checkdate($month, $day, $year) ) :
			
				$date = $year.$month.$day.' '.$hour.':'.$min;
				update_post_meta( $post_id, $meta_box[ 'name' ], strtotime( $date ) );
			
			// Only if fields were posted; dont delete if they are not shown
			elseif (isset($_POST[ $meta_box[ 'name' ] . '_year' ])) :
			
				delete_post_meta( $post_id, $meta_box[ 'name' ] );
			
			endif;
			
		} else {
			update_post_meta( $post_id, $meta_box[ 'name' ], $_POST[ $meta_box[ 'name' ] ] );
		}
	}
	
	// Update location
	
	if (!empty($_POST['colabs_address'])) :
		
		$latitude = colabs_clean_coordinate($_POST['colabs_geo_latitude']);
		$longitude = colabs_clean_coordinate($_POST['colabs_geo_longitude']);
		
		update_post_meta($post_id, '_colabs_geo_latitude', $latitude);
		update_post_meta($post_id, '_colabs_geo_longitude', $longitude);
		
		if ($latitude && $longitude) :
			$address = colabs_reverse_geocode($latitude, $longitude);
			
			update_post_meta($post_id, 'geo_address', $address['address']);
			update_post_meta($post_id, 'geo_country', $address['country']);
			update_post_meta($post_id, 'geo_short_address', $address['short_address']);
			update_post_meta($post_id, 'geo_short_address_country', $address['short_address_country']);

		endif;
	
	else :
	
		// They left the field blank so we assume the job is for 'anywhere'
		delete_post_meta($post_id, '_colabs_geo_latitude');
		delete_post_meta($post_id, '_colabs_geo_longitude');
		delete_post_meta($post_id, 'geo_address');
		delete_post_meta($post_id, 'geo_country');
		delete_post_meta($post_id, 'geo_short_address');
		delete_post_meta($post_id, 'geo_short_address_country');
	
	endif;

}

function colabs_display_location_meta_box() {
	global $post, $meta_boxes, $key;
	
	?>
<div class="">	
	<?php wp_nonce_field( plugin_basename( __FILE__ ), $key . '_wpnonce', false, true ); ?>
						
	<p><?php  _e('Leave blank if the location of the applicant does not matter e.g. the job involves working from home.', 'colabsthemes'); ?></p>
	
	<div id="geolocation_box">
	
		<?php 
			
			$geo_address = get_post_meta($post->ID, 'geo_address', true);
			$colabs_geo_latitude = get_post_meta($post->ID, '_colabs_geo_latitude', true);
			$colabs_geo_longitude = get_post_meta($post->ID, '_colabs_geo_longitude', true);
			
			if(isset($geo_address) && $geo_address!='') {}else $geo_address = '';
			
			if ($colabs_geo_latitude && $colabs_geo_longitude) :
				$colabs_address = colabs_reverse_geocode($colabs_geo_latitude, $colabs_geo_longitude);
				$colabs_address = $colabs_address['address'];
			else :
				$colabs_address = 'Anywhere';
			endif;
			
			
		?>
	
		<div>
		<input type="text" class="text" name="colabs_address" id="geolocation-address" style="width: 180px;" autocomplete="off" value="<?php echo $geo_address; ?>" /><label><input id="geolocation-load" type="button" class="button geolocationadd" value="<?php _e('Find', 'colabsthemes'); ?>" /></label>
		<input type="hidden" class="text" name="colabs_geo_latitude" id="geolocation-latitude" value="<?php echo $colabs_geo_latitude; ?>" />
		<input type="hidden" class="text" name="colabs_geo_longitude" id="geolocation-longitude" value="<?php echo $colabs_geo_longitude; ?>" />
		</div>

		<div id="map_wrap" style="margin-top:5px; border:solid 2px #ddd;"><div id="geolocation-map" style="width:100%;height:200px;"></div></div>
	
	</div>
	
	<p><strong><?php _e('Current location:', 'colabsthemes'); ?></strong><br/><?php echo $colabs_address; ?><?php
		if ($colabs_geo_latitude && $colabs_geo_longitude) :
			echo '<br/><em>Latitude:</em> '.$colabs_geo_latitude;
			echo '<br/><em>Longitude:</em> '.$colabs_geo_longitude;
		endif;
	?></p>
</div>	
	<?php
	colabs_geolocation_scripts();
}

add_action( 'admin_menu', 'colabs_create_meta_box' );
add_action( 'save_post', 'colabs_save_meta_box' );
?>
