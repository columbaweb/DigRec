<?php
/**
 * JobJockey Preview Job form
 * Function outputs the job preview form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_preview_job_form() {
	
	global $post, $posted;
	
	?>
	<form action="<?php echo get_permalink( $post->ID ); ?>" method="post" enctype="multipart/form-data" id="submit_form" class="submit_form main_form">			
		<p><?php _e('Below is a preview of what your job listing will look like when published:', 'colabsthemes'); ?></p>				
		
		<ol class="jobs">
			<li class="job <?php if ($alt==1) echo 'job-alt'; ?>" style="padding-left:0; padding-right:0;"><dl>
				<dt><?php _e('Type','colabsthemes'); ?></dt>
				<dd class="type"><?php
					$job_type = get_term_by( 'slug', sanitize_title($posted['job_term_type']), 'job_type');		
					echo '<span class="'.$job_type->slug.'">'.wptexturize($job_type->name).'</span>';			
				?>&nbsp;</dd>
				<dt><?php _e('Job', 'colabsthemes'); ?></dt>
				<dd class="title"><strong><?php echo $posted['job_title']; ?> </strong><?php
					
					$author = get_user_by('id', get_current_user_id());
					
					if ($posted['your_name']) :
						echo $posted['your_name'];
						if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) :
							echo sprintf( __(' &ndash; Posted by <a href="%s">%s</a>', 'colabsthemes'), $link, $author->display_name );
						endif;
					else :
						if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) :
							echo sprintf( __('<a href="%s">%s</a>', 'colabsthemes'), $link, $author->display_name );
						endif;
					endif;
					
					?>
				</dd>
				<dt><?php _e('_Location', 'colabsthemes'); ?></dt>
				<dd class="location"><?php
				
					$latitude = colabs_clean_coordinate($posted['colabs_geo_latitude']);
					$longitude = colabs_clean_coordinate($posted['colabs_geo_longitude']);
					
					if ($latitude && $longitude) :
						$address = colabs_reverse_geocode($latitude, $longitude);
						echo '<strong>'.wptexturize($address['short_address']).'</strong> '.wptexturize($address['short_address_country']).'';
					else :
						echo '<strong>Anywhere</strong>';
					endif;
				?></dd>
				<dt><?php _e('Date Posted', 'colabsthemes'); ?></dt>
				<dd class="date"><strong><?php echo date_i18n(__('j M','colabsthemes')); ?></strong> <span class="year"><?php echo date_i18n(__('Y','colabsthemes')); ?></span></dd>
			</dl></li>
		</ol>
		
		<p><?php _e('The job listing&rsquo;s page will contain the following information:', 'colabsthemes'); ?></p>
		
		<blockquote>
			<h2><?php _e('Job description','colabsthemes'); ?></h2>
			<?php echo wpautop(wptexturize($posted['details'])); ?>
			<?php if (get_option('colabs_submit_how_to_apply_display')=='true') : ?>
				<h2><?php _e('How to apply','colabsthemes'); ?></h2>
				<?php echo wpautop(wptexturize($posted['apply'])); ?>
			<?php endif; ?>
		</blockquote>
		
		<?php
			$packs = colabs_get_job_packs();
			$user_packs = colabs_get_user_job_packs();
			if (sizeof($packs) > 0 || sizeof($user_packs)>0) :
			
				echo '<h2>'.__('Select a Job Pack:', 'colabsthemes').'</h2>';
				
				echo '<ul class="packs">';
				
				$checked = 'checked="checked"';
				
				if (sizeof($user_packs)>0) foreach ($user_packs as $pack) :
				
					$choose_or_use = __('Choose this pack', 'colabsthemes');
					
					if (!$pack->jobs_limit) :
						$pack->jobs_count = __('Unlimited', 'colabsthemes').' '.__('Jobs remaining', 'colabsthemes');
					else :
						$pack->jobs_count = $pack->jobs_limit - $pack->jobs_count;
						if ($pack->jobs_count==1) $pack->jobs_count = $pack->jobs_count.' '.__('Job remaining', 'colabsthemes');
						else $pack->jobs_count = $pack->jobs_count.' '.__('Jobs remaining', 'colabsthemes');
					endif;
					
					if ($pack->pack_expires) $pack->pack_expires = __('Usable before ', 'colabsthemes').mysql2date(get_option('date_format'), $pack->pack_expires);
					
					if ($pack->job_duration) $pack->job_duration = __(' lasting ', 'colabsthemes').$pack->job_duration.__(' days' ,'colabsthemes');
					
					echo '<li><span class="cost">'.__('Purchased', 'colabsthemes').'</span><h3>'.$pack->pack_name.'</h3>
						<p>'.$pack->jobs_count.''.$pack->job_duration.'. '.$pack->pack_expires.'.</p>
						<div><label>'.$choose_or_use.': <input type="radio" name="job_pack" value="user_'.$pack->id.'" '.$checked.' /></label></div>
					</li>';
					
					$checked = '';
				endforeach;
				
				if (sizeof($packs)>0) foreach ($packs as $pack) :
				
					$choose_or_use = '';
					
					if (!$pack->job_count) $pack->job_count = __('Unlimited', 'colabsthemes');
					
					if ($pack->pack_duration) $pack->pack_duration = __(' usable within ', 'colabsthemes').$pack->pack_duration.__(' days', 'colabsthemes');
					
					if ($pack->job_duration) $pack->job_duration = __(' lasting ', 'colabsthemes').$pack->job_duration.__(' days' ,'colabsthemes');
					
					if ($pack->pack_cost) :
						$pack->pack_cost = colabs_get_currency($pack->pack_cost).'';
						$choose_or_use = __('Buy this pack', 'colabsthemes');
					else :
						$pack->pack_cost = __('Free','colabsthemes');
						$choose_or_use = __('Choose this pack', 'colabsthemes');
					endif; 
					
					echo '<li><span class="cost">'.$pack->pack_cost.'</span><h3>'.$pack->pack_name.' &ndash; <small>'.$pack->pack_description.'</small></h3>
						<p>'.$pack->job_count.' '.__('Jobs', 'colabsthemes').''.$pack->job_duration.$pack->pack_duration.'.</p>
						<div><label>'.$choose_or_use.': <input type="radio" name="job_pack" value="'.$pack->id.'" '.$checked.' /></label></div>
					</li>';
					
					$checked = '';
				endforeach;
				
				echo '</ul>';
				
			endif;
		?>

		<?php
			$featured_cost = get_option('colabs_cost_to_feature');
			if ($featured_cost && is_numeric($featured_cost) && $featured_cost > 0) :
				
				// Featuring is an option
				echo '<h2>'.__('Feature your listing for ', 'colabsthemes').colabs_get_currency($featured_cost).__('?', 'colabsthemes').'</h2>';
				
				echo '<p>'.__('Featured listings are displayed on the homepage and are also highlighted in all other listing pages.', 'colabsthemes').'</p>';
				
				echo '<p><input type="checkbox" name="featureit" id="featureit" /> <label for="featureit" style="float:none">'.__('Yes please, feature my listing.', 'colabsthemes').'</label></p>';
				
			endif;
		?>

		<p>
            <input type="submit" name="goback" class="goback" value="<?php _e('Go Back','colabsthemes') ?>"  /> 
            <input type="submit" class="submit" name="preview_submit" value="<?php _e('Next &rarr;', 'colabsthemes'); ?>" />
            <input type="hidden" value="<?php echo base64_encode(serialize($posted)); ?>" name="posted" />
        </p>
		
		<div class="clear"></div>
	</form>
	<?php

}