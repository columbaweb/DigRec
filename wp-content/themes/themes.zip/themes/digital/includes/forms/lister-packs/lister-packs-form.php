<?php
function colabs_lister_packs_form() {
		global $user_ID;

		$colabs_orders = new colabs_orders();

		if (sizeof($colabs_orders)>0){
			$colabs_orders->get_orders( $args = array('status'=>'pending_payment', 'type'=>'packs', 'user_id'=>$user_ID) );
			if (sizeof($colabs_orders->orders)>0):
?>
				<h4><?php _e('Pending Payment Packs','colabsthemes'); ?></h4>
				<table cellpadding="0" cellspacing="0" class="data_list">
					<thead>
						<tr>
							<th><?php _e('Job Pack','colabsthemes'); ?></th>
							<th class="pack-order-date"><?php _e('Order Date','colabsthemes'); ?></th>
						</tr>
					</thead>
					<tbody>
<?php
					foreach ($colabs_orders->orders as $colabs_order):
						$colabs_pack = new colabs_pack($colabs_order->pack_id);
?>
						<tr>
							<td><?php echo $colabs_pack->pack_name; ?></td>
							<td class="date"><strong><?php echo date_i18n(__('j M','colabsthemes'), strtotime($colabs_order->order_date)); ?></strong> <span class="year"><?php echo date_i18n(__('Y','colabsthemes'), strtotime($colabs_order->order_date)); ?></span></td>
						</tr>
<?php
					endforeach;
?>
					</tbody>
				</table>
<?php
			endif;
		}
?>
		<form action="" method="post" id="submit_form" class="submit_form main_form" >
		<?php 		
			// display the packs selection (display only 'Paid' Job Packs)
			$paid_job_packs = colabs_job_pack_select('dashboard-purchase', array('paid','free'));
		
			if ($paid_job_packs):	
		?>			
				<fieldset class="gateways_fieldset">				
					<legend><?php _e('Payment Gateway', 'colabsthemes'); ?></legend>	
					<select name="gateway" id="gateway" class="gateway">				
					
						<?php colabs_order_gateway_options(); ?>
            <?php if( get_option('colabs_bank_transfer') == 'true' ){ ?><option value="banktransfer"><?php echo _e('Bank Transfer', 'colabsthemes') ?></option><?php } ?>
						
					</select>	
				</fieldset>							
				<p>
					<input type="submit" class="submit buy_job_pack" name="buy_job_pack" value="<?php _e('Continue to Payment &rarr;', 'colabsthemes'); ?>" />
				</p>
				<div class="clear"></div>
		<?php 
			endif; 
		?>			
		</form>		
<?php
}