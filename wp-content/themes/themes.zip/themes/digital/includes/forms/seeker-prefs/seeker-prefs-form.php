<?php
/**
 * Job Seeker Preferences form
 * Function outputs the Job Seeker Preferences form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_job_seeker_prefs_form() {
	
	global $posted;

	$career_status 			= get_user_meta(get_current_user_id(), 'career_status', true);
	$willing_to_relocate 	= get_user_meta(get_current_user_id(), 'willing_to_relocate', true);
	$willing_to_travel 		= get_user_meta(get_current_user_id(), 'willing_to_travel', true);
	$keywords 				= get_user_meta(get_current_user_id(), 'keywords', true);
	$search_location 		= get_user_meta(get_current_user_id(), 'search_location', true);
	$job_types 				= get_user_meta(get_current_user_id(), 'job_types', true);
		
	$availability_month 	= get_user_meta(get_current_user_id(), 'availability_month', true);
	$availability_year 		= get_user_meta(get_current_user_id(), 'availability_year', true);
	?>
	<form action="" method="post" id="submit_form" class="submit_form main_form">

		<fieldset>
		
			<legend><?php _e('Publicly visible details', 'colabsthemes'); ?></legend>
			<p><?php _e('These options control what is shown publicly on your resumes.', 'colabsthemes'); ?></p>
			
			<p class="optional"><label for="availability_month"><?php _e('Your Availability <small>(Leave blank for immediate availability)</small>', 'colabsthemes'); ?></label> 
				<span class="date_field_wrap">
					<select name="availability_month" id="availability_month">
						<option value=""><?php _e('Month&hellip;', 'colabsthemes'); ?></option>
						<?php
							for($i=1; $i<=12; $i++) :
								$month = date('F', mktime(0, 0, 0, $i, 11, 1978));
								echo '<option value="'.$i.'"';
								if (isset($availability_month) && $availability_month==$i) echo ' selected="selected"';
								echo '>'.$month.'</option>';
							endfor;
						?>
					</select>
					<input type="text" class="text placeholder" name="availability_year" maxlength="4" size="4" placeholder="<?php _e('YYYY','colabsthemes'); ?>" rel="<?php _e('YYYY','colabsthemes'); ?>" value="<?php if (isset($availability_year)) echo $availability_year; ?>" id="availability_year" />
				</span>
			</p>
			
		</fieldset>
		
		<fieldset>
			<legend><?php _e('Your Career', 'colabsthemes'); ?></legend>
			<p><label for="career_status"><?php _e('Career status', 'colabsthemes'); ?></label> <select name="career_status" id="career_status">
				<option <?php if ($career_status=='looking') echo 'selected="selected"'; ?> value="looking"><?php _e('Actively looking', 'colabsthemes'); ?></option>
				<option <?php if ($career_status=='open') echo 'selected="selected"'; ?> value="open"><?php _e('Open to new opportunities', 'colabsthemes'); ?></option>
				<option <?php if ($career_status=='notlooking') echo 'selected="selected"'; ?> value="notlooking"><?php _e('Not actively looking', 'colabsthemes'); ?></option>
			</select></p>
			<p><label for="willing_to_relocate"><?php _e('Are you willing to relocate?', 'colabsthemes'); ?></label> <select name="willing_to_relocate" id="willing_to_relocate">
				<option <?php if ($willing_to_relocate=='yes') echo 'selected="selected"'; ?> value="yes"><?php _e('Yes', 'colabsthemes'); ?></option>
				<option <?php if ($willing_to_relocate=='no') echo 'selected="selected"'; ?> value="no"><?php _e('No', 'colabsthemes'); ?></option>
			</select></p>
			<p><label for="willing_to_travel"><?php _e('Are you willing to travel?', 'colabsthemes'); ?></label> <select name="willing_to_travel" id="willing_to_travel">
				<option <?php if ($willing_to_travel=='100') echo 'selected="selected"'; ?> value="100"><?php _e('100% willing to travel', 'colabsthemes'); ?></option>
				<option <?php if ($willing_to_travel=='75') echo 'selected="selected"'; ?> value="75"><?php _e('Fairly willing to travel', 'colabsthemes'); ?></option>
				<option <?php if ($willing_to_travel=='50') echo 'selected="selected"'; ?> value="50"><?php _e('Not very willing to travel', 'colabsthemes'); ?></option>
				<option <?php if ($willing_to_travel=='25') echo 'selected="selected"'; ?> value="25"><?php _e('Interested in local opportunities only', 'colabsthemes'); ?></option>
				<option <?php if ($willing_to_travel=='0') echo 'selected="selected"'; ?> value="0"><?php _e('Not willing to travel/working from home', 'colabsthemes'); ?></option>
			</select></p>
			
		</fieldset>
		
		<fieldset>
			<legend><?php _e('Other Information', 'colabsthemes'); ?></legend>
			<p><?php _e('These options control what job recommendations your receive on your dashboard.', 'colabsthemes'); ?></p>
			
			<p><label for="keywords"><?php _e('Key Words <small>(comma separated)</small>', 'colabsthemes'); ?></label> <input type="text" class="tags text placeholder" name="keywords" id="keywords" placeholder="<?php _e('e.g. Web Design, Designer', 'colabsthemes'); ?>" rel="<?php _e('e.g. Web Design, Designer', 'colabsthemes'); ?>" value="<?php echo $keywords; ?>" /></p>
			
			<p><label for="search_location"><?php _e('Search location', 'colabsthemes'); ?></label> 
			<input type="text" class="tags text placeholder" name="search_location" id="search_location" placeholder="<?php _e('e.g. London, United Kingdom', 'colabsthemes'); ?>" rel="<?php _e('e.g. London, United Kingdom', 'colabsthemes'); ?>" value="<?php echo $search_location; ?>" /></p>
			
			<div class="optional prefs_job_types"><label><?php _e('Types of Job', 'colabsthemes'); ?></label> 
				<ul>
				<?php
				$all_job_types = get_terms( 'job_type', array( 'hide_empty' => '0' ) );
				if ($all_job_types && sizeof($all_job_types) > 0) {
					foreach ($all_job_types as $type) {
						?>
						<li><label for="<?php echo $type->slug; ?>"><input type="checkbox" name="prefs_job_types[<?php echo $type->slug; ?>]" id="<?php echo $type->slug; ?>" <?php 
							if (is_array($job_types) && in_array($type->slug.'', $job_types)) echo 'checked="checked"'; 
							
						?> value="show" /> <?php echo $type->name; ?></label></li>
						<?php
					}
				}
				?>
				</ul>
			</div>

		</fieldset>

		<p><input type="submit" class="submit" name="save_prefs" value="<?php _e('Save &rarr;', 'colabsthemes'); ?>" /></p>
			
		<div class="clear"></div>
			
	</form>
	<?php
}