<?php
/**
 * JobJockey Application Process
 * Processes a job application sent via the form in a post.
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_process_application_form() {
	
	global $post, $colabs_form_results;
	
	$apply_form_class = "";
	$posted = array();
	$errors = new WP_Error();
	if (isset($_POST['apply_to_job'])) :
	
		$apply_form_class = 'open';
		
		// Get (and clean) data
		$fields = array(
			'your_name',
			'your_email',
			'your_message',
			'your_resume',
			'antispam_answer'
		);
		foreach ($fields as $field) {
			$posted[$field] = stripslashes(trim($_POST[$field]));
		}
		
		// Check required fields
		$required = array(
			'your_name' => __('Name', 'colabsthemes'),
			'your_message' => __('Message', 'colabsthemes')
		);
		
		foreach ($required as $field=>$name) {
			if (empty($posted[$field])) {
				$errors->add('submit_error', __('<strong>ERROR</strong>: &ldquo;', 'colabsthemes').$name.__('&rdquo; is a required field.', 'colabsthemes'));
			}
		}
		
		// Check AntiSpam Field
		$ans = strtolower(trim(get_option('colabs_antispam_answer')));
		if (strtolower(trim($posted['antispam_answer'])) !== $ans) {
			$errors->add('submit_error', __('<strong>ERROR</strong>: Incorrect anti-spam answer. The correct answer is ', 'colabsthemes').'"'.$ans.'".');
		}
		
		// Check the e-mail address
		if ($posted['your_email'] == '') {
			$errors->add('empty_email', __('<strong>ERROR</strong>: Please type your e-mail address.', 'colabsthemes'));
		} elseif ( !is_email( $posted['your_email'] ) ) {
			$errors->add('invalid_email', __('<strong>ERROR</strong>: The email address isn&#8217;t correct.', 'colabsthemes'));
			$posted['your_email'] = '';
		}
		
		// Check file extensions
		$allowed = array(
			'pdf',
			'doc',
			'docx',
			'zip',
			'txt',
			'rtf'
		);
		if (isset($_FILES['your_cv']) && !empty($_FILES['your_cv']['name'])) {
			
			//$extension = strtolower(pathinfo($_FILES['your_cv']['name'], PATHINFO_EXTENSION));
			$extension = strtolower(substr(strrchr($_FILES['your_cv']['name'], "."), 1));
			if (!in_array($extension, $allowed)) $errors->add('submit_error', __('<strong>ERROR</strong>: Only pdf, zip, doc, txt and rtf files are allowed.', 'colabsthemes'));
		}
		if (isset($_FILES['your_coverletter']) && !empty($_FILES['your_coverletter']['name'])) {
			//$extension = strtolower(pathinfo($_FILES['your_coverletter']['name'], PATHINFO_EXTENSION));
			$extension = strtolower(substr(strrchr($_FILES['your_coverletter']['name'], "."), 1));
			if (!in_array($extension, $allowed)) $errors->add('submit_error', __('<strong>ERROR</strong>: Only pdf, zip, doc, txt and rtf files are allowed.', 'colabsthemes'));
		}

		if ($errors && sizeof($errors)>0 && $errors->get_error_code()) {
			// There are errors!
		} else {
			$attachments = array();
			$attachment_urls = array();
			// Continue, upload files
			if ((isset($_FILES['your_cv']) && !empty($_FILES['your_cv']['name'])) || (isset($_FILES['your_coverletter']) && !empty($_FILES['your_coverletter']['name']))) {
				
				// Find max filesize in bytes - we say 10mb becasue the file will be attached to an email, also checks system variables in case they are lower
				$max_sizes = array('10485760');
				if ((ini_get('post_max_size'))) $max_sizes[] = let_to_num(ini_get('post_max_size'));
				if ((ini_get('upload_max_filesize'))) $max_sizes[] = let_to_num(ini_get('upload_max_filesize'));
				if ((WP_MEMORY_LIMIT)) $max_sizes[] = let_to_num(WP_MEMORY_LIMIT);
				
				$max_filesize = min( $max_sizes );
				
				if (($_FILES["your_cv"]["size"]+$_FILES["your_coverletter"]["size"]) > $max_filesize) :
					$errors->add('submit_error', __('<strong>ERROR</strong>: ', 'colabsthemes').'Attachments too large. Maximum file size for all attachments is '.($max_filesize/(1024*1024)).'MB');
				else :
				
					/** WordPress Administration File API */
					include_once(ABSPATH . 'wp-admin/includes/file.php');					
					/** WordPress Media Administration API */
					include_once(ABSPATH . 'wp-admin/includes/media.php');
		
					add_filter('upload_dir', 'cv_upload_dir');
					
					$time = current_time('mysql');
					$overrides = array('test_form'=>false);
	
					if (isset($_FILES['your_cv']) && !empty($_FILES['your_cv']['name'])) {
						$file = wp_handle_upload($_FILES['your_cv'], $overrides, $time);
						if ( !isset($file['error']) ) {					
							$attachments[] = $file['file'];
							$attachment_urls[] = $file['url'];
						} 
						else {
							$errors->add('submit_error', __('<strong>ERROR</strong>: ', 'colabsthemes').$file['error'].'');
						}
					}
					if (isset($_FILES['your_coverletter']) && !empty($_FILES['your_coverletter']['name'])) {
						$file = wp_handle_upload($_FILES['your_coverletter'], $overrides, $time);
						if ( !isset($file['error']) ) {					
							$attachments[] = $file['file'];
							$attachment_urls[] = $file['url'];
						} 
						else {
							$errors->add('submit_error', __('<strong>ERROR</strong>: ', 'colabsthemes').$file['error'].'');
						}
					}
				
				endif;
				
				remove_filter('upload_dir', 'company_logo_upload_dir');
			
			}
			
			if ($errors && sizeof($errors)>0 && $errors->get_error_code()) {} else {
				$post_author_id = $post->post_author;

				$headers = __('From: ', 'colabsthemes').$posted['your_name'].' <'.$posted['your_email'].'>' . "\r\n\\";
				$message = __("Applicant Name: ", 'colabsthemes').$posted['your_name']."\n".__("Applicant Email: ", 'colabsthemes').$posted['your_email']."\n\n".$posted['your_message']."\n\n".__("Applicant Resume: ", 'colabsthemes').$posted['your_resume'];
			
				wp_mail( get_the_author_meta( 'user_email', $post_author_id ), __('Application for job "', 'colabsthemes').$post->post_title.'"', $message, $headers, $attachments );
				
				// CC						
				wp_mail( $posted['your_email'], __('[copy] Application for job "', 'colabsthemes').$post->post_title.'"', $message, '', $attachments );
				
				// CC Admin
				if (get_option('colabs_bcc_apply_emails')=='true') :
					wp_mail( get_option('admin_email'), __('[copy] Application for job "', 'colabsthemes').$post->post_title.'"', $message, '', $attachments );
				endif;
				
				if (sizeof($attachments)>0) {
					foreach ($attachments as $attach) {
						@unlink($attach);
					}
				}
				
				?>
				<p class="success" id="apply_form_result"><?php _e('Your application has been sent successfully.', 'colabsthemes'); ?></p>
				<?php
				$apply_form_class = "";
				
				$posted = array();
				
			}
			
		}
		
		
	endif;
	
	$colabs_form_results = array(
		'class' => $apply_form_class,
		'errors' => $errors,
		'posted' => $posted
	);

}

function cv_upload_dir( $pathdata ) {
	$subdir = '/uploaded_cvs'.$pathdata['subdir'];
 	$pathdata['path'] = str_replace($pathdata['subdir'], $subdir, $pathdata['path']);
 	$pathdata['url'] = str_replace($pathdata['subdir'], $subdir, $pathdata['url']);
	$pathdata['subdir'] = str_replace($pathdata['subdir'], $subdir, $pathdata['subdir']);
	return $pathdata;
}