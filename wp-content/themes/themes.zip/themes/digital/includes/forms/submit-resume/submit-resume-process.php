<?php
/**
 * JobJockey Submit Resume Process
 * Processes a job submission.
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_process_submit_resume_form( $resume_id = 0 ) {
	
	global $post, $posted;
	
	$errors = new WP_Error();
	if (isset($_POST['save_resume']) && $_POST['save_resume']) :
	
		// Get (and clean) data
		$fields = array(
			'resume_name',
			'summary',
			'skills',
			'specialities',
			'groups',
			'languages',
			'desired_salary',
			'desired_position',
			'resume_cat',
			'mobile',
			'tel',
			'email_address',
			'education',
			'experience',
			'colabs_geo_latitude',
			'colabs_geo_longitude',
			'colabs_address',
			'post_status'
		);
		
		foreach ($fields as $field) {
			if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field]));
		}
		
		### Strip html
		
		if (get_option('colabs_html_allowed')=='false') :
			$posted['summary'] = strip_tags($posted['summary']);
			$posted['education'] = strip_tags($posted['education']);
			$posted['experience'] = strip_tags($posted['experience']);
		endif;
		
		### End strip

		// Check required fields
		$required = array(
			'resume_name' => __('Resume name', 'colabsthemes'),
			'summary' => __('Summary', 'colabsthemes'),
			'colabs_geo_latitude' => __('Location', 'colabsthemes'),
			'colabs_geo_longitude' => __('Location', 'colabsthemes')
		);
		
		foreach ($required as $field=>$name) {
			if (empty($posted[$field])) {
				$errors->add('submit_error', __('<strong>ERROR</strong>: &ldquo;', 'colabsthemes').$name.__('&rdquo; is a required field.', 'colabsthemes'));
			}
		}
		
		if ($errors && sizeof($errors)>0 && $errors->get_error_code()) {} else {
			
			//image
			if(isset($_FILES['your-photo']) && !empty($_FILES['your-photo']['name'])) {
				
				$posted['your-photo-name'] = $_FILES['your-photo']['name'];
				
				// Check valid extension
				$allowed = array(
					'png',
					'gif',
					'jpg',
					'jpeg'
				);
				
				$extension = strtolower(pathinfo($_FILES['your-photo']['name'], PATHINFO_EXTENSION));
				
				if (!in_array($extension, $allowed)) {
					$errors->add('submit_error', __('<strong>ERROR</strong>: Only jpg, gif, and png images are allowed.', 'colabsthemes'));
				} else {
						
					/** WordPress Administration File API */
					include_once(ABSPATH . 'wp-admin/includes/file.php');					
					/** WordPress Media Administration API */
					include_once(ABSPATH . 'wp-admin/includes/media.php');
		
					function resume_photo_upload_dir( $pathdata ) {
						$subdir = '/resume_photos'.$pathdata['subdir'];
					 	$pathdata['path'] = str_replace($pathdata['subdir'], $subdir, $pathdata['path']);
					 	$pathdata['url'] = str_replace($pathdata['subdir'], $subdir, $pathdata['url']);
						$pathdata['subdir'] = str_replace($pathdata['subdir'], $subdir, $pathdata['subdir']);
						return $pathdata;
					}
					
					add_filter('upload_dir', 'resume_photo_upload_dir');
					
					$time = current_time('mysql');
					$overrides = array('test_form'=>false);
					
					$file = wp_handle_upload($_FILES['your-photo'], $overrides, $time);
					
					remove_filter('upload_dir', 'resume_photo_upload_dir');
					
					if ( !isset($file['error']) ) {					
						$posted['your-photo'] = $file['url'];
						$posted['your-photo-type'] = $file['type'];
						$posted['your-photo-file'] = $file['file'];
					} 
					else {
						$errors->add('submit_error', __('<strong>ERROR</strong>: ', 'colabsthemes').$file['error'].'');
					}
						
				}		
			}	
			
			//audio
			if(isset($_FILES['your-audio']) && !empty($_FILES['your-audio']['name'])) {
				
				$posted['your-audio-name'] = $_FILES['your-audio']['name'];
				
				// Check valid extension
				$allowed = array(
					'mp3','m4a','ogg', 'wav'
				);
				
				$extension = strtolower(pathinfo($_FILES['your-audio']['name'], PATHINFO_EXTENSION));
				
				if (!in_array($extension, $allowed)) {
					$errors->add('submit_error', __('<strong>ERROR</strong>: Only mp3, m4a, ogg and wav Audio are allowed.', 'colabsthemes'));
				} else {
						
					/** WordPress Administration File API */
					include_once(ABSPATH . 'wp-admin/includes/file.php');					
					/** WordPress Media Administration API */
					include_once(ABSPATH . 'wp-admin/includes/media.php');
		
					function resume_audio_upload_dir( $pathdata ) {
						$subdir = '/resume_audios'.$pathdata['subdir'];
					 	$pathdata['path'] = str_replace($pathdata['subdir'], $subdir, $pathdata['path']);
					 	$pathdata['url'] = str_replace($pathdata['subdir'], $subdir, $pathdata['url']);
						$pathdata['subdir'] = str_replace($pathdata['subdir'], $subdir, $pathdata['subdir']);
						return $pathdata;
					}
					
					add_filter('upload_dir', 'resume_audio_upload_dir');
					
					$time = current_time('mysql');
					$overrides = array('test_form'=>false);
					
					$file = wp_handle_upload($_FILES['your-audio'], $overrides, $time);
					
					remove_filter('upload_dir', 'resume_audio_upload_dir');
					
					if ( !isset($file['error']) ) {					
						$posted['your-audio'] = $file['url'];
						$posted['your-audio-type'] = $file['type'];
						$posted['your-audio-file'] = $file['file'];
					} 
					else {
						$errors->add('submit_error', __('<strong>ERROR</strong>: ', 'colabsthemes').$file['error'].'');
					}
						
				}		
			}
			
			//video
			if(isset($_FILES['your-video']) && !empty($_FILES['your-video']['name'])) {
				
				$posted['your-video-name'] = $_FILES['your-video']['name'];
				
				// Check valid extension
				$allowed = array(
					'mp4','m4v','mov','wmv','avi','mpg','ogv','3gp','3g2'
				);
				
				$extension = strtolower(pathinfo($_FILES['your-video']['name'], PATHINFO_EXTENSION));
				
				if (!in_array($extension, $allowed)) {
					$errors->add('submit_error', __('<strong>ERROR</strong>: Only mp4, m4v, mov, wmv, avi, mpg, ogv, 3gp, 3g2 video are allowed.', 'colabsthemes'));
				} else {
						
					/** WordPress Administration File API */
					include_once(ABSPATH . 'wp-admin/includes/file.php');					
					/** WordPress Media Administration API */
					include_once(ABSPATH . 'wp-admin/includes/media.php');
		
					function resume_video_upload_dir( $pathdata ) {
						$subdir = '/resume_videos'.$pathdata['subdir'];
					 	$pathdata['path'] = str_replace($pathdata['subdir'], $subdir, $pathdata['path']);
					 	$pathdata['url'] = str_replace($pathdata['subdir'], $subdir, $pathdata['url']);
						$pathdata['subdir'] = str_replace($pathdata['subdir'], $subdir, $pathdata['subdir']);
						return $pathdata;
					}
					
					add_filter('upload_dir', 'resume_video_upload_dir');
					
					$time = current_time('mysql');
					$overrides = array('test_form'=>false);
					
					$file = wp_handle_upload($_FILES['your-video'], $overrides, $time);
					
					remove_filter('upload_dir', 'resume_video_upload_dir');
					
					if ( !isset($file['error']) ) {					
						$posted['your-video'] = $file['url'];
						$posted['your-video-type'] = $file['type'];
						$posted['your-video-file'] = $file['file'];
					} 
					else {
						$errors->add('submit_error', __('<strong>ERROR</strong>: ', 'colabsthemes').$file['error'].'');
					}
						
				}		
			}	
		}
		
		if ($errors && sizeof($errors)>0 && $errors->get_error_code()) {} else {
			
			// No errors? Create the resume post
			global $wpdb;
			
			if ( $resume_id > 0 ) :
				
				$data = array(
					'ID' => $resume_id
					,'post_content' => $wpdb->escape($posted['summary'])
					, 'post_title' => $wpdb->escape($posted['resume_name'])
				);	
				
				wp_update_post( $data );
				
			else :
			
				$data = array(
					'post_content' => $wpdb->escape($posted['summary'])
					, 'post_title' => $wpdb->escape($posted['resume_name'])
					, 'post_status' => $wpdb->escape($posted['post_status'])
					, 'post_author' => get_current_user_id()
					, 'post_type' => 'resume'
					, 'post_name' => get_current_user_id().uniqid(rand(10,1000), false)
				);		
				
				$resume_id = wp_insert_post($data);	
				
				if ($resume_id==0 || is_wp_error($resume_id)) wp_die( __('Error: Unable to create entry.', 'colabsthemes') );
			
			endif;	
			
			### Add meta data
			
				update_post_meta($resume_id, '_skills', $posted['skills']);
				update_post_meta($resume_id, '_desired_salary', $posted['desired_salary']);
				
				update_post_meta($resume_id, '_mobile', $posted['mobile']);
				update_post_meta($resume_id, '_tel', $posted['tel']);
				update_post_meta($resume_id, '_email_address', $posted['email_address']);
				
				update_post_meta($resume_id, '_education', $posted['education']);
				update_post_meta($resume_id, '_experience', $posted['experience']);
			
			## Desired position
			
			$post_into_types[] = get_term_by( 'slug', sanitize_title($posted['desired_position']), 'resume_job_type')->slug;
		
			if (sizeof($post_into_types)>0) wp_set_object_terms($resume_id, $post_into_types, 'resume_job_type');
			
			### Category
			
				$post_into_cats = array();
		
				if ($posted['resume_cat']>0) $post_into_cats[] = get_term_by( 'id', $posted['resume_cat'], 'resume_category')->slug;
		
				if (sizeof($post_into_cats)>0) wp_set_object_terms($resume_id, $post_into_cats, 'resume_category');
			
			### Tags
			
				if ($posted['specialities']) :
					
					$thetags = explode(',', $posted['specialities']);
					$thetags = array_map('trim', $thetags);
					
					if (sizeof($thetags)>0) wp_set_object_terms($resume_id, $thetags, 'resume_specialities');
					
				endif;
				
				if ($posted['groups']) :
					
					$thetags = explode(',', $posted['groups']);
					$thetags = array_map('trim', $thetags);
					
					if (sizeof($thetags)>0) wp_set_object_terms($resume_id, $thetags, 'resume_groups');
					
				endif;
				
				if ($posted['languages']) :
					
					$thetags = explode(',', $posted['languages']);
					$thetags = array_map('trim', $thetags);
					
					if (sizeof($thetags)>0) wp_set_object_terms($resume_id, $thetags, 'resume_languages');
					
				endif;
				
			### GEO
		
		if (!empty($posted['colabs_address'])) :
			
			$latitude = colabs_clean_coordinate($posted['colabs_geo_latitude']);
			$longitude = colabs_clean_coordinate($posted['colabs_geo_longitude']);
			
			update_post_meta($resume_id, '_colabs_geo_latitude', $posted['colabs_geo_latitude'] );
			update_post_meta($resume_id, '_colabs_geo_longitude', $posted['colabs_geo_longitude'] );

			if ($latitude && $longitude) :
				$address = colabs_reverse_geocode($latitude, $longitude);
				
				update_post_meta($resume_id, 'geo_address', $address['address'] );
				update_post_meta($resume_id, 'geo_country', $address['country'] );
				update_post_meta($resume_id, 'geo_short_address', $address['short_address'] );
				update_post_meta($resume_id, 'geo_short_address_country', $address['short_address_country'] );

			endif;

		endif;	
				
			## Load APIs and Link to photo
			//image
				include_once(ABSPATH . 'wp-admin/includes/file.php');			
				include_once(ABSPATH . 'wp-admin/includes/image.php');			
				include_once(ABSPATH . 'wp-admin/includes/media.php');
		
				$name_parts = pathinfo($posted['your-photo-name']);
				$name = trim( substr( $name, 0, -(1 + strlen($name_parts['extension'])) ) );
				
				$url = $posted['your-photo'];
				$type = $posted['your-photo-type'];
				$file = $posted['your-photo-file'];
				$title = $posted['your-photo-name'];
				$content = '';
				
				if ($file) :
				
					// use image exif/iptc data for title and caption defaults if possible
					if ( $image_meta = @wp_read_image_metadata($file) ) {
						if ( trim($image_meta['title']) )
							$title = $image_meta['title'];
						if ( trim($image_meta['caption']) )
							$content = $image_meta['caption'];
					}
			
					// Construct the attachment array
					$attachment = array_merge( array(
						'post_mime_type' => $type,
						'guid' => $url,
						'post_parent' => $resume_id,
						'post_title' => $title,
						'post_content' => $content,
					), array() );
			
					// Save the data
					$id = wp_insert_attachment($attachment, $file, $resume_id);
					if ( !is_wp_error($id) ) {
						wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $file ) );
					}
					
					update_post_meta( $resume_id, '_thumbnail_id', $id );
				
				endif;
				
			//audio		
				$name_parts = pathinfo($posted['your-audio-name']);
				$name = trim( substr( $name, 0, -(1 + strlen($name_parts['extension'])) ) );
				
				$url = $posted['your-audio'];
				$type = $posted['your-audio-type'];
				$file = $posted['your-audio-file'];
				$title = $posted['your-audio-name'];
				$content = '';
				
				if ($file) :
				
					// use image exif/iptc data for title and caption defaults if possible
					if ( $image_meta = @wp_read_image_metadata($file) ) {
						if ( trim($image_meta['title']) )
							$title = $image_meta['title'];
						if ( trim($image_meta['caption']) )
							$content = $image_meta['caption'];
					}
			
					// Construct the attachment array
					$attachment = array_merge( array(
						'post_mime_type' => $type,
						'guid' => $url,
						'post_parent' => $resume_id,
						'post_title' => $title,
						'post_content' => $content,
					), array() );
					
					// Save the data
					$id = wp_insert_attachment($attachment, $file, $resume_id);
					if ( !is_wp_error($id) ) {
						wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $file ) );
					}
				
				endif;
				
			//video		
				$name_parts = pathinfo($posted['your-video-name']);
				$name = trim( substr( $name, 0, -(1 + strlen($name_parts['extension'])) ) );
				
				$url = $posted['your-video'];
				$type = $posted['your-video-type'];
				$file = $posted['your-video-file'];
				$title = $posted['your-video-name'];
				$content = '';
				
				if ($file) :
				
					// use image exif/iptc data for title and caption defaults if possible
					if ( $image_meta = @wp_read_image_metadata($file) ) {
						if ( trim($image_meta['title']) )
							$title = $image_meta['title'];
						if ( trim($image_meta['caption']) )
							$content = $image_meta['caption'];
					}
			
					// Construct the attachment array
					$attachment = array_merge( array(
						'post_mime_type' => $type,
						'guid' => $url,
						'post_parent' => $resume_id,
						'post_title' => $title,
						'post_content' => $content,
					), array() );
					
					// Save the data
					$id = wp_insert_attachment($attachment, $file, $resume_id);
					if ( !is_wp_error($id) ) {
						wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $file ) );
					}
				
				endif;
				
				// Redirect to Resume
				$url = get_permalink( $resume_id );
				if (!$url) $url = get_permalink(get_option('colabs_user_profile_page_id'));
				wp_redirect($url);
    			exit();

		}	
		
	endif;
	
	$submit_form_results = array(
		'errors' => $errors,
		'posted' => $posted
	);
	
	return $submit_form_results;

}