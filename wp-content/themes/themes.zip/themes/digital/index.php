<?php 
    global $colabs_options, $featured_job_cat_id;
	// Empty search fix
	if (isset($_GET['s']) && isset($_GET['location']) && !empty($_GET['location'])) : get_template_part('search'); exit; endif;
?>

<?php get_header('search'); ?>

<?php do_action('jobs_will_display'); ?>

	<div class="row">
		
    <?php get_sidebar(); ?>

		<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
            
            <?php
            $featured_job_cat_id = $colabs_options['colabs_featured_category_id'];
            if ( get_query_var('paged') )
                $paged = get_query_var('paged');
            elseif ( get_query_var('page') )
                $paged = get_query_var('page');
            else
                $paged = 1;
            
            // include the featured jobs
            if (is_front_page() && $paged==1 && $featured_job_cat_id)
                get_template_part('includes/featured-jobs');
            ?>

            <div class="section latest-jobs">
        
        		<h3 class="section-title">
        
        			<?php _e('Latest Jobs','colabsthemes'); ?> <?php if ($paged>1) { ?>(page <?php echo $paged; ?>)<?php } ?>
        
        			<?php if (isset($_GET['action']) && $_GET['action'] == 'Filter') { ?>
        				<small> &mdash; <a href="<?php echo colabs_get_current_url(); ?>"><?php _e('Remove Filters','colabsthemes'); ?></a></small>
        			<?php } ?>
        
        		</h3>
                
        		<?php
        			$args = colabs_filter_form();
                    $wp_query = new WP_Query( $args );
                    
        			// call the main loop-job.php file
        			get_template_part( 'loop', 'job' );
        		?>
                
            </div><!-- end section -->
            
    		<?php colabs_custom_pagination(); ?>
    		
    		<?php wp_reset_postdata(); ?>
    
    		<div class="clear"></div>

		</div><!-- .content -->

	</div>
    
<?php get_footer();?>	