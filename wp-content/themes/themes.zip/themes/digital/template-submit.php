<?php
/*
Template Name: Submit Job Template
*/
?>
<?php
	### Prevent Caching
	nocache_headers();
    
    colabs_load_form_scripts();
	 	
	global $post, $posted;
	
	$submitID = $post->ID;
	
	$posted = array();
	$errors = new WP_Error();
	
	if (!is_user_logged_in()) :
		$step = 1; 
	else :
		$step = 2;
		if (!current_user_can('can_submit_job')) :
			redirect_myjobs();
		endif;
	endif;
	
	if (isset($_POST['register']) && $_POST['register']) {
	
		$result = colabs_process_register_form( get_permalink($submitID) );
		
		$errors = $result['errors'];
		$posted = $result['posted'];

	}
	elseif (isset($_POST['login']) && $_POST['login']) {
	
		$errors = colabs_process_login_form();

	}
	elseif (isset($_POST['job_submit']) && $_POST['job_submit']) {	

		$result = colabs_process_submit_job_form();
		
		$errors = $result['errors'];
		$posted = $result['posted'];
		
		if ($errors && sizeof($errors)>0 && $errors->get_error_code()) $step = 2; else $step = 3;

	}
	elseif (isset($_POST['preview_submit']) && $_POST['preview_submit']) {
		
		$step = 4;

    	if (isset($_POST['payment_type']) && $_POST['payment_type']) :
    		$posted['payment_type'] = $_POST['payment_type'];
    	else :
    		$posted['payment_type'] = 'paypal';
    	endif;
        
		$posted = unserialize(base64_decode($_POST['posted']));
		
	}
	elseif (isset($_POST['confirm']) && $_POST['confirm']) {
		
		$step = 4;
        
		colabs_process_confirm_job_form();
		
	}
	elseif (isset($_POST['goback']) && $_POST['goback']) {
		$posted = unserialize(base64_decode($_POST['posted']));
	}
	
	if( isset($_GET['checkemail']) && 'newpass' == $_GET['checkemail'] )	
		$message = __('Thank you for registering! An email has been sent to you containing your password.','colabsthemes');
	
?>

<?php get_header(); ?>

	<div class="row">
	
	<?php get_sidebar('submit'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">

	<div class="section">
	
		<div class="section-content">
		
			<h1><?php _e('Submit a Job', 'colabsthemes'); ?></h1>

			<?php 
				echo '<ol class="steps">';
				for ($i = 1; $i <= 4; $i++) :
					echo '<li class="';
					if ($step==$i) echo 'current ';
					if (($step-1)==$i) echo 'previous ';
					if ($i<$step) echo 'done';
					echo '"><span class="';
					if ($i==1) echo 'first';
					if ($i==4) echo 'last';
					echo '">';
					switch ($i) :
						case 1 : _e('Create account', 'colabsthemes'); break;
						case 2 : _e('Enter Job Details', 'colabsthemes'); break;
						case 3 : _e('Preview/Job Options', 'colabsthemes'); break;
						case 4 : _e('Confirm', 'colabsthemes'); break;
					endswitch;
					echo '</span></li>';
				endfor;
				echo '</ol><div class="clear"></div>';
				
				// show the success message usually because a password has been emailed to new user
				if (isset($message) && !empty($message)) echo '<p class="success">'.$message.'</p>';

				colabs_show_errors( $errors ); 
				
				switch ($step) :
					
					case 1 :
						colabs_before_step_one(); // do_action hook
						?>
						<hr>
						<p><?php _e('You must login or create an account in order to post a job &mdash; this will enable you to view, remove, or relist your listing in the future.', 'colabsthemes'); ?></p>
						<div class="row">
							<div class="column col7"><div class="register-form"><?php colabs_register_form( get_permalink($submitID), '' ); ?></div></div>
							<div class="login-form column col5"><?php colabs_login_form( get_permalink($submitID), get_permalink($submitID) ); ?></div>
						</div>
						<?php						
						colabs_after_step_one(); // do_action hook						
						break;
					case 2 :	
						colabs_before_step_two(); // do_action hook
						colabs_submit_job_form(); 						
						colabs_after_step_two(); // do_action hook	
						break;
					case 3 :	
						colabs_before_step_three(); // do_action hook
						colabs_preview_job_form();
						colabs_after_step_three(); // do_action hook
						break;
					case 4 :
						colabs_before_step_four(); // do_action hook
						colabs_confirm_job_form();	
						colabs_after_step_four(); // do_action hook
						break;
					
				endswitch;	
			?>

		</div><!-- end section_content -->

	</div><!-- end section -->

	</div><!-- end content -->
	</div><!-- end row -->

<div class="clear"></div>

<?php get_footer(); ?>