<?php
/*
Template Name: My Dashboard Template
*/

get_header();

if (current_user_can('can_submit_job')) :
	get_template_part('template-myjobs');
else :
	get_template_part('template-job-seeker-dashboard');
endif;