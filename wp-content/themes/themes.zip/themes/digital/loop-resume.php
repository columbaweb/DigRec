<?php
/**
 * Main loop for displaying resumes
 *
 * @package JobJockey
 * @author ColorLabs
 *
 */
?>

<?php colabsthemes_before_loop( 'resume' ); ?>

<div class="section-content">

<?php if (have_posts()) : $alt = 1; ?>

    <ol class="resumes">

        <?php while (have_posts()) : the_post(); ?>
		
			<?php colabsthemes_before_post( 'resume' ); ?>

            <li class="resume" title="<?php echo htmlspecialchars(colabs_seeker_prefs( get_the_author_meta('ID') ), ENT_QUOTES); ?>">

                <dl>

					<?php colabsthemes_before_post_title( 'resume' ); ?>
					
                    <dt><?php _e('Resume title', 'colabsthemes'); ?></dt>
					
                    <dd class="title">
					
						<strong><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></strong>
						
						<?php 
						echo __('Resume posted by ','colabsthemes') . wptexturize(get_the_author_meta('display_name'));
						
						$terms = wp_get_post_terms($post->ID, 'resume_category');
						if ($terms) :
							_e(' in ','colabsthemes');
							echo '<a href="'.get_term_link($terms[0]->slug, 'resume_category').'">' . $terms[0]->name .'</a>';
						endif;
						?>
						
                    </dd>
					
					<?php colabsthemes_after_post_title( 'resume' ); ?>
									
					<dt><?php _e('Photo','colabsthemes'); ?></dt>
                    <dd class="photo"><a href="<?php the_permalink(); ?>"><?php if (has_post_thumbnail()) the_post_thumbnail('listing-thumbnail'); ?></a></dd>
                    
                    <dt><?php _e('Location', 'colabsthemes'); ?></dt>
                    <dd class="location"><strong><?php if ($address = get_post_meta($post->ID, 'geo_short_address', true)) echo wptexturize($address); else _e('N/A','colabsthemes'); ?></strong> <?php echo wptexturize(get_post_meta($post->ID, 'geo_short_address_country', true)); ?></dd>
					
                    <dt><?php _e('Date Posted', 'colabsthemes'); ?></dt>
                    <dd class="date"><strong><?php echo date_i18n('j M', strtotime($post->post_date)); ?></strong> <span class="year"><?php echo date_i18n('Y', strtotime($post->post_date)); ?></span></dd>

                </dl>

            </li>

        <?php endwhile; ?>
		
		<?php colabsthemes_after_endwhile( 'resume' ); ?>

    </ol>

<?php else: ?>

	<?php colabsthemes_loop_else( 'resume' ); ?>        
	
        
<?php endif; ?>

</div><!--/.section-content-->

<?php colabsthemes_after_loop( 'resume' ); ?>

