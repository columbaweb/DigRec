<div class="sidebar column col4 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'fr';}?>">

    <?php colabsthemes_before_sidebar_widgets(); ?>
    
    
        <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('sidebar_page')) : else : ?>
        
        	<!-- no dynamic sidebar setup -->
        
        <?php endif; ?>
    
    <?php colabsthemes_after_sidebar_widgets(); ?>

<?php wp_reset_postdata(); ?>
</div><!-- .sidebar -->
