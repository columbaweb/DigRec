<?php global $colabs_abbr, $header_search; $header_search = true; ?>
<?php get_header(); ?>

<?php if (get_option('colabs_show_searchbar')!=='false' && ( !isset($_GET['submit']) || ( isset($_GET['submit']) && $_GET['submit']!=='true' ) ) && ( !isset($_GET['myjobs']) || ( isset($_GET['myjobs']) && $_GET['myjobs']!=='true' ) ) ) : ?>

<div class="row job-search">

    <?php
    $items = '';
	if (get_option('colabs_submit_page_id') && (!is_user_logged_in() || (is_user_logged_in() && current_user_can('can_submit_job')))) :
        $items .= '<div class="submit-job column ';
		if (is_page(get_option('colabs_submit_page_id'))) $items .= 'current_page_item';	
		$items .= '"><a href="'.get_permalink(get_option('colabs_submit_page_id')).'">'.__('Submit A Job', 'colabsthemes').'</a></div>';
    else :
    	if (get_option('colabs_job_seeker_resume_page_id') && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('can_submit_job')))) :
            $items .= '<div class="submit-job column ';
    		if (is_page(get_option('colabs_job_seeker_resume_page_id'))) $items .= 'current_page_item';	
    		$items .= '"><a href="'.get_permalink(get_option('colabs_job_seeker_resume_page_id')).'">'.__('Add A Resume', 'colabsthemes').'</a></div>';
        endif;
	endif;
    echo $items;
    ?>

    <div class="job-searchform column">
	<form action="<?php bloginfo('url'); ?>/" method="get" id="searchform">

        <input type="hidden" name="resume_search" value="true" />
        <input type="text" id="search" title="" name="s" class="text placeholder resume-search" rel="<?php _e('Search Resumes','colabsthemes'); ?>" value="<?php if (isset($_GET['s'])) echo get_search_query(); ?>" />
        <input type="submit" alt="<?php _e('Search','colabsthemes'); ?>" title="<?php _e('Search','colabsthemes'); ?>" class="submit" />

	</form>
    </div><!-- .job-searchform -->
    
</div><!-- .job-search -->
<?php endif; ?>