<?php
	### Disabled blog check
	if (get_option('colabs_disable_blog')=='true') :
		wp_redirect(get_bloginfo('url'));
		exit;
	endif;
?>

<?php get_header(); ?>
<div class="row">
	<?php get_sidebar('blog'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
	<div class="section single">

			<?php get_template_part( 'loop' ); ?>

			<?php comments_template( '', true ); ?><!-- #comments -->

		<div class="clear"></div>
		
	</div><!-- end section single -->	
	</div>
</div>
<div class="clear"></div>
	
<?php get_footer(); ?>
