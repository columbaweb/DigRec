<?php 
/**
 * Template Name: Sitemap
 *
 *
 * @package CoLabsFramework
 * @subpackage Template
 */
?>
<?php
	### Disabled blog check
	if (get_option('colabs_disable_blog')=='true') :
		wp_redirect(get_bloginfo('url'));
		exit;
	endif;
?>

<?php get_header(); ?>
<div class="row">
	<?php get_sidebar('blog'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
		<?php colabsthemes_before_blog_post(); ?>

		<?php
			$post_class = array('post');
			$alt=$alt*-1;
			if ($alt==1) $post_class[] = 'post-alt';
		?>
		<div class="section">
				<?php colabsthemes_before_page_title(); ?>
				<h3 class="section-title"><?php the_title(); ?></h3>
				<?php colabsthemes_after_page_title(); ?>
			
				<div class="section-content">
					<h3><?php _e('Pages :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_pages('title_li='); ?>
					</ul>
				</div>
				
				<div class="section-content">
					<h3><?php _e('Categories :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_categories('title_li=&hierarchical=0&show_count=1') ?>
					</ul>
				</div>
				
				<div class="section-content">
					<h3><?php _e('Monthly Archives :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_get_archives('type=monthly'); ?>
					</ul>
				</div>
				
				<div class="section-content">
					<h3><?php _e('RSS Feed :', 'colabsthemes');?></h3>
					<ul>
						<li><a href="<?php bloginfo('rdf_url'); ?>" title="RDF/RSS 1.0 feed"><acronym title="Resource Description Framework">RDF</acronym>/<acronym title="Really Simple Syndication">RSS</acronym> 1.0 feed</a></li>
						<li><a href="<?php bloginfo('rss_url'); ?>" title="RSS 0.92 feed"><acronym title="Really Simple Syndication">RSS</acronym> 0.92 feed</a></li>
						<li><a href="<?php bloginfo('rss2_url'); ?>" title="RSS 2.0 feed"><acronym title="Really Simple Syndication">RSS</acronym> 2.0 feed</a></li>
						<li><a href="<?php bloginfo('atom_url'); ?>" title="Atom feed">Atom feed</a></li>
					</ul>
				</div>
				
				<div class="section-content">
					<?php 
					$taxonomy     = 'job_cat';
					$orderby      = 'name'; 
					$show_count   = 1;      // 1 for yes, 0 for no
					$pad_counts   = 1;      // 1 for yes, 0 for no
					$hierarchical = 1;      // 1 for yes, 0 for no
					$title        = '';
					
					$args = array(
						'taxonomy'     => $taxonomy,
						'orderby'      => $orderby,
						'show_count'   => $show_count,
						'pad_counts'   => $pad_counts,
						'hierarchical' => $hierarchical,
						'title_li'     => $title
					);
					?>
					<h3><?php _e('Job Categories :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_categories( $args ); ?>
					</ul>
				</div>
				
				<div class="section-content">
					<?php 
					$taxonomy     = 'job_type';
					$orderby      = 'name'; 
					$show_count   = 1;      // 1 for yes, 0 for no
					$pad_counts   = 1;      // 1 for yes, 0 for no
					$hierarchical = 1;      // 1 for yes, 0 for no
					$title        = '';
					
					$args = array(
						'taxonomy'     => $taxonomy,
						'orderby'      => $orderby,
						'show_count'   => $show_count,
						'pad_counts'   => $pad_counts,
						'hierarchical' => $hierarchical,
						'title_li'     => $title
					);
					?>
					<h3><?php _e('Job Types :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_categories( $args ); ?>
					</ul>
				</div>
				
				<div class="section-content">
					<?php 
					$taxonomy     = 'resume_category';
					$orderby      = 'name'; 
					$show_count   = 1;      // 1 for yes, 0 for no
					$pad_counts   = 1;      // 1 for yes, 0 for no
					$hierarchical = 1;      // 1 for yes, 0 for no
					$title        = '';
					
					$args = array(
						'taxonomy'     => $taxonomy,
						'orderby'      => $orderby,
						'show_count'   => $show_count,
						'pad_counts'   => $pad_counts,
						'hierarchical' => $hierarchical,
						'title_li'     => $title
					);
					?>
					<h3><?php _e('Resume Categories :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_categories( $args ); ?>
					</ul>
				</div>
				
				<div class="section-content">
					<?php 
					$taxonomy     = 'resume_job_type';
					$orderby      = 'name'; 
					$show_count   = 1;      // 1 for yes, 0 for no
					$pad_counts   = 1;      // 1 for yes, 0 for no
					$hierarchical = 1;      // 1 for yes, 0 for no
					$title        = '';
					
					$args = array(
						'taxonomy'     => $taxonomy,
						'orderby'      => $orderby,
						'show_count'   => $show_count,
						'pad_counts'   => $pad_counts,
						'hierarchical' => $hierarchical,
						'title_li'     => $title
					);
					?>
					<h3><?php _e('Resume Job Types :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_categories( $args ); ?>
					</ul>
				</div>
				
				<div class="section-content">
					<?php 
					$taxonomy     = 'resume_groups';
					$orderby      = 'name'; 
					$show_count   = 1;      // 1 for yes, 0 for no
					$pad_counts   = 1;      // 1 for yes, 0 for no
					$hierarchical = 1;      // 1 for yes, 0 for no
					$title        = '';
					
					$args = array(
						'taxonomy'     => $taxonomy,
						'orderby'      => $orderby,
						'show_count'   => $show_count,
						'pad_counts'   => $pad_counts,
						'hierarchical' => $hierarchical,
						'title_li'     => $title
					);
					?>
					<h3><?php _e('Groups/Associations :', 'colabsthemes');?></h3>
					<ul >
					<?php wp_list_categories( $args ); ?>
					</ul>
				</div>
		</div><!-- End section -->
	</div>
</div>
<div class="clear"></div>

<?php get_footer(); ?>				
				