<?php
/**
 * Main loop for displaying jobs
 *
 * @package JobJockey
 * @author ColorLabs
 *
 */
?>

<?php colabsthemes_before_loop( 'job_listing' ); ?>

<?php if (have_posts()) : $alt = 1; ?>

    <div class="section-content">

        <?php while (have_posts()) : the_post(); ?>
		
			<?php colabsthemes_before_post( 'job_listing' ); ?>

            <?php
				global $featured_job_cat_id;

				$post_class = array('job');
				$expired = colabs_check_expired($post);

				if ($expired) {
					$post_class[] = 'job-expired';
					$action = get_option('colabs_expired_action');
					if ($action=='hide') :
						continue;
					endif;
				}
				$alt=$alt*-1;

				if ($alt==1) $post_class[] = 'job-alt';
				if ( is_object_in_term( $post->ID, 'job_cat', array($featured_job_cat_id) ) ) $post_class[] = 'job-featured';
            ?>

            <div class="jobs-post clearfix <?php echo implode(' ', $post_class); ?>">

        		<div class="column col6">
        			<?php colabs_image('width=250&before=<div class=jobs-img>&after=</div>'); ?>
        			<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
        			<div class="jobs-meta">
        				<span class="jobs-author">
                        						
						<?php if (get_post_meta($post->ID, '_Company', true)) : ?>
						
							<?php if ($compurl = get_post_meta($post->ID, '_CompanyURL', true)) { ?>
								<a href="<?php echo wptexturize(get_post_meta($post->ID, '_CompanyURL', true)); ?>" rel="nofollow"><?php echo wptexturize(get_post_meta($post->ID, '_Company', true)); ?></a>
							<?php } else { ?>
								<?php echo wptexturize(get_post_meta($post->ID, '_Company', true)); ?>
							<?php } ?>
							
							<?php 
								$author = get_user_by('id', $post->post_author);
								if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) echo sprintf( __('<br/> Posted by <a href="%s">%s</a>', 'colabsthemes'), $link, $author->display_name );
							?> 
						
						<?php else : ?>
						
							<?php 
								$author = get_user_by('id', $post->post_author);
								if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) echo sprintf( __('Posted by <a href="%s">%s</a>', 'colabsthemes'), $link, $author->display_name );
							?> 
						
						<?php endif; ?>
						
                        </span><br/>
                        
        				<span class="jobs-date">
                        <?php echo date_i18n(__('j M','colabsthemes'), strtotime($post->post_date)); ?> <span class="year"><?php echo date_i18n(__('Y','colabsthemes'), strtotime($post->post_date)); ?></span>
                        </span>
                        
        			</div>
        		</div>
        
        		<div class="column col4">
        			<span class="jobs-place">
                    <?php if ($address = get_post_meta($post->ID, 'geo_short_address', true)) echo wptexturize($address); else _e('Anywhere','colabsthemes'); ?>
                    </span><br/>
        			<span><?php echo wptexturize(get_post_meta($post->ID, 'geo_short_address_country', true)); ?></span>
        		</div>
        
        		<div class="column col2">
        			<?php colabs_get_custom_taxonomy($post->ID, 'job_type', 'job_type'); ?>
        		</div>

            </div>

        <?php endwhile; ?>
		
		<?php colabsthemes_after_endwhile( 'job_listing' ); ?>

    </div><!--/.section-content-->

<?php else: ?>
    
    <div class="section-content">
    
        <?php colabsthemes_loop_else( 'job_listing' ); ?>
        
    </div><!--/.section-content-->        
	
<?php endif; ?>

<?php colabsthemes_after_loop( 'job_listing' ); ?>

