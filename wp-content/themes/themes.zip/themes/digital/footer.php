</div><!-- .main -->

<?php global $colabs_options; ?>

<div class="footer container">
	<div class="row">
        
        <?php if( $colabs_options['colabs_logo_footer'] == 'true' ){ ?>
		<div class="footer-logo">
			<a href="<?php echo home_url(); ?>"><img src="<?php echo $colabs_options['colabs_logo_footer_img']; ?>"/></a>
		</div><!-- .logo -->
        <?php } ?>
        
        <?php if ( $colabs_options['colabs_footer_credit_left'] == 'true' ){ ?>
		<p class="copyright fl"><?php echo $colabs_options['colabs_footer_credit_left_txt']; ?></p>
        <?php } ?>
        
        <?php if ( $colabs_options['colabs_footer_credit_right'] == 'true' ){ ?> 
		<p class="fr"><?php echo $colabs_options['colabs_footer_credit_right_txt']; ?></p>
        <?php } ?>

	</div>
</div><!-- .footer -->

	<?php wp_footer(); ?>
	<?php colabs_foot(); ?>
        
</body>
</html>

      

   

