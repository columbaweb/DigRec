<?php
/*
Template Name: Edit Job Template
*/
?>
<?php
	### Prevent Caching
	nocache_headers();
	
	colabsthemes_auth_redirect_login();
	
	if (isset($_REQUEST['relist'])) $relisting = true; else $relisting = false;
	
	if (!$relisting && get_option('colabs_allow_editing')=='false') :
		redirect_myjobs();
	endif; 
	
	if ($relisting && get_option('colabs_allow_relist')=='false') :
		redirect_myjobs();
	endif;
	
	$message = '';
	
	global $post, $job_details;
    
    colabs_load_form_scripts();

	global $posted;
	$posted = array();
	$errors = new WP_Error();
	
	### Get job details and check the user has permission to edit the listing
	
	$jobID = (int) $_GET['edit'];
	
	if ($jobID>0) :
	
		// Get job details
		$job_details = get_post($jobID);
	
		// Permission?
		global $current_user;
        get_currentuserinfo();

		if ($current_user->ID == $job_details->post_author) :
		
			// We have permission to edit this!
		
		else : redirect_myjobs(); endif;
	
	else : redirect_myjobs(); endif;
	
	### Process Forms
	
	if ($relisting) $result = colabs_process_relist_job_form();
	else $result = colabs_process_edit_job_form();
	
	$errors = $result['errors'];
	$posted = $result['posted'];
	
?>
<?php get_header(); ?>

	<div class="row">
	
	<?php get_sidebar('job'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">

	<div class="section">
	
		<div class="section-content">
		
			<h1><?php if ($relisting) _e('Relisting', 'colabsthemes'); else _e('Editing', 'colabsthemes'); ?> &ldquo;<?php echo $job_details->post_title; ?>&rdquo;</h1>

			<?php colabs_show_errors( $errors ); ?>
				
			<?php colabs_edit_job_form( $relisting ); ?>

		</div><!-- end section_content -->

	</div><!-- end section -->

	</div><!-- end content -->
	</div><!-- end row -->

<div class="clear"></div>

<?php get_footer(); ?>