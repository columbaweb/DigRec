<?php
	### Disabled resume check
	if (get_option('colabs_allow_job_seekers')=='false') :
		wp_redirect(get_bloginfo('url'));
		exit;
	endif;
	### Visibility check
	if ((get_option('colabs_resume_listing_visibility')=='members' && !is_user_logged_in()) || (get_option('colabs_resume_listing_visibility')=='listers' && !current_user_can('can_submit_job')) ) :
		wp_redirect(get_bloginfo('url'));
		exit;
	endif;
	colabs_resume_page_auth();
	colabs_resume_subscr_process();
?>
<?php get_header('resume-search'); ?>
<div class="row">
	
	<?php get_sidebar('resume'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
    <div class="section">    

        <h1 class="pagetitle"><?php 
        	_e('Resumes', 'colabsthemes'); 

        	if ( is_tax( 'resume_category' ) ) :
        		
        		$slug = get_query_var('resume_category');
		  		$term = get_term_by( 'slug', $slug, 'resume_category');
		  		echo sprintf( __(' in the %s category.', 'colabsthemes'), $term->name);
        		
        	elseif ( is_tax( 'resume_languages' ) ) :
        	
        		$slug = get_query_var('resume_languages');
		  		$term = get_term_by( 'slug', $slug, 'resume_languages');
		  		echo sprintf( __(' of people who speak %s.', 'colabsthemes'), $term->name);
        	
        	elseif ( is_tax( 'resume_interests' ) ) :
        	
        		$slug = get_query_var('resume_interests');
		  		$term = get_term_by( 'slug', $slug, 'resume_interests');
		  		echo sprintf( __(' of people interested in %s.', 'colabsthemes'), $term->name);
        	
        	elseif ( is_tax( 'resume_groups' ) ) :
        	
        		$slug = get_query_var('resume_groups');
		  		$term = get_term_by( 'slug', $slug, 'resume_groups');
		  		echo sprintf( __(' of members of %s.', 'colabsthemes'), $term->name);
        	
        	elseif ( is_tax( 'resume_specialities' ) ) :
        	
        		$slug = get_query_var('resume_specialities');
		  		$term = get_term_by( 'slug', $slug, 'resume_specialities');
		  		echo sprintf( __(' of people specialising in %s.', 'colabsthemes'), $term->name);
        	
        	endif;
        ?></h1>
				
				<?php if (colabs_resume_is_visible()) : ?>
       
					<?php get_template_part( 'loop', 'resume' ); ?>

					<?php colabs_pagination(); ?>

				<?php else : ?>
					<div class="section-content">
        	<?php if ( colabs_viewing_resumes_require_subscription() && colabs_current_user_can_subscribe_for_resumes() ) :
        		
						if ($notice = get_option('colabs_resume_subscription_notice')) echo '<p>'.wptexturize($notice).'</p>';
						
						colabs_subscribe_resumes_form();
        		
        	else :
        		
        		echo '<p>'.sprintf(__('Sorry, you do not have permission to browse and view resumes. Please <a href="%s">login or register</a>.', 'colabsthemes'), home_url('wp-login.php')).'</p>';
        		
        	endif; ?>
        	</div>
        <?php endif; ?>
        <div class="clear"></div>

    </div><!-- end section -->
	</div>
</div>
<div class="clear"></div>

<?php get_footer(); ?>