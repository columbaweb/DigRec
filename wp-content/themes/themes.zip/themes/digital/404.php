<?php get_header(); ?>
<div class="row">
	<?php get_sidebar(); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
<?php if (get_option('colabs_show_sidebar')!=='no') get_sidebar('page'); ?>
	
	<div class="section">
		
		<?php colabsthemes_before_page_title(); ?>
		<h3 class="section-title"><?php the_title(); ?></h3>
		<?php colabsthemes_after_page_title(); ?>
		
		<div class="section-content">
		
			<?php colabsthemes_before_page_loop(); ?>

			
				
					<?php colabsthemes_before_page(); ?>
					
					<?php colabsthemes_before_page_content(); ?>

					<h2><?php _e('ERROR 404','colabsthemes');?></h2>
					<p><?php _e('Whoops... It seems that page you were looking for doesn\'t exist. Try searching the site.','colabsthemes');?></p>
					
					<?php colabsthemes_after_page_content(); ?>
					
					<?php colabsthemes_after_page(); ?>

				
			
			<?php colabsthemes_after_page_loop(); ?>

			<div class="clear"></div>

		</div>

	</div>
	
	<?php comments_template( '', true ); ?><!-- #comments -->
	</div>
</div>

<div class="clear"></div>


<?php get_footer(); ?>