<?php
	### Disabled resume check
	if (get_option('colabs_allow_job_seekers')=='no') :
		wp_redirect(get_bloginfo('url'));
		exit;
	endif;
	### Visibility check
	if ((get_option('colabs_resume_listing_visibility')=='members' && !is_user_logged_in()) || (get_option('colabs_resume_listing_visibility')=='listers' && !current_user_can('can_submit_job')) ) :
		wp_redirect(get_bloginfo('url'));
		exit;
	endif;
?>
<?php get_header('resume-search'); ?>

<div class="row">

<?php get_sidebar('resume'); ?>

<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
    
	<div class="section resume-jobs jj-search">

		<?php
		global $wp_query, $query_string;
		
		$wp_query = new WP_Query( 'post_type=resume&' . $query_string );
		?>

		<h1 class="pagetitle"><?php echo sprintf( __('Searching resumes for %s', 'colabsthemes'), get_search_query()); ?> <?php if ($paged>1) : ?>(<?php _e('page','colabsthemes'); ?> <?php echo $paged; ?>)<?php endif; ?></h1>

		<h3 class="section-title">

			<?php _e('Search Results','colabsthemes'); ?>

			<?php if (isset($_GET['action']) && $_GET['action'] == 'Filter') { ?>
				<small> &mdash; <a href="<?php echo colabs_get_current_url(); ?>"><?php _e('Remove Filters','colabsthemes'); ?></a></small>
			<?php } ?>

		</h3>
        
		<?php get_template_part( 'loop', 'resume' ); ?>

        <?php colabs_pagination(); ?>

        <div class="clear"></div>

    </div><!-- end section -->

    <div class="clear"></div>

</div><!-- end main content -->

</div><!-- end row -->

<?php get_footer(); ?>