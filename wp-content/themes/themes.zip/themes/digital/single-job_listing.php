<?php get_header('search'); ?>

<div class="row">
		
<?php get_sidebar('job'); ?>

<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
        
	<div class="section">
	
    <h3 class="section-title"><?php _e( 'Job Info','colabsthemes' ); ?></h3>

				<?php colabsthemes_before_post(); ?>

				<?php colabsthemes_stats_update($post->ID); //records the page hit ?>				

				<div class="section-content">

					<?php colabsthemes_before_post_title(); ?>
					
					<h4 class="title">

							<?php the_title(); ?>

					</h4>
					
					<?php colabsthemes_after_post_title(); ?>

					<div class="job-info">
						<span class="job-author">
    						<?php if (get_post_meta($post->ID, '_Company', true)) : ?>
    						
    							<?php if ($compurl = get_post_meta($post->ID, '_CompanyURL', true)) { ?>
    								<a href="<?php echo wptexturize(get_post_meta($post->ID, '_CompanyURL', true)); ?>" rel="nofollow"><?php echo wptexturize(get_post_meta($post->ID, '_Company', true)); ?></a>
    							<?php } else { ?>
    								<?php echo wptexturize(get_post_meta($post->ID, '_Company', true)); ?>
    							<?php } ?>
    							
    							<?php 
    								$author = get_user_by('id', $post->post_author);
    								if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) echo sprintf( __(' &ndash; Posted by <a href="%s">%s</a>', 'colabsthemes'), $link, $author->display_name );
    							?> 
    						
    						<?php else : ?>
    						
    							<?php 
    								$author = get_user_by('id', $post->post_author);
    								if ($author && $link = get_author_posts_url( $author->ID, $author->user_nicename )) echo sprintf( __('<a href="%s">%s</a>', 'colabsthemes'), $link, $author->display_name );
    							?> 
    						
    						<?php endif; ?>                        
                        </span> | <span class="job-posted"><?php the_time(__('j M','colabsthemes')); ?> <span class="year"><?php the_time(__('Y','colabsthemes')); ?></span></span><br/>
                        
						<span class="jobs-place"><?php if ($address = get_post_meta($post->ID, 'geo_short_address', true)) echo wptexturize($address); else _e('Anywhere','colabsthemes'); ?></span> | <?php if(get_post_meta($post->ID, 'geo_short_address_country', true)) echo wptexturize(get_post_meta($post->ID, 'geo_short_address_country', true)); ?>
                        
						<span class="type"><?php colabs_get_custom_taxonomy($post->ID, 'job_type', 'job_type'); ?></span>
                        
					</div>
					
					<?php if(get_post_meta($post->ID, '_colabs_geo_latitude', true) != '' && get_post_meta($post->ID, '_colabs_geo_longitude', true) != '') : ?>				
					<script type="text/javascript">
						 jQuery(function($){
						  
							$('#map_wrap').gmap3({
							  map:{
								options:{
								  zoom: 15,center:[<?php echo get_post_meta(get_the_ID(), '_colabs_geo_latitude', true).','.get_post_meta(get_the_ID(), '_colabs_geo_longitude', true); ?>]
								}
							  },
							  marker:{
								values:[
								  {address:'<?php echo get_post_meta(get_the_ID(), '_colabs_geo_latitude', true).','.get_post_meta(get_the_ID(), '_colabs_geo_longitude', true); ?>', 
								   data:'<a href="#apply_form"><?php the_title(); ?></a><br><?php echo get_post_meta(get_the_ID(), 'geo_address', true); ?><a style="float:right" href="<?php colabs_image('link=url'); ?>" rel="lightbox"><?php colabs_image('width=50&height=50&link=img&class=destination-image'); ?></a>'},
								
								],
								options:{
								  draggable: false
								},
								events:{
								  click: function(marker, event, context){
									var map = $(this).gmap3("get"),
									  infowindow = $(this).gmap3({get:{name:"infowindow"}});
									if (infowindow){
									  infowindow.open(map, marker);
									  infowindow.setContent(context.data);
									} else {
									  $(this).gmap3({
										infowindow:{
										  anchor:marker, 
										  options:{content: context.data}
										}
									  });
									}
								  }
								}
							  }
							});
						  });

					</script>				
					
					<div id="geolocation_box">	
						<div id="map_wrap" style="height:200px; border:solid 2px #ddd;"></div>	
					</div>
					<?php endif; ?>                
					
					<hr/><div class="clear"></div>
					<div class="job-logo">
						<?php colabs_image('class=alignleft'); ?>						
						<?php echo colabs_share(); ?>
					</div>
					
                    <h4><?php _e('Job Description', 'colabsthemes'); ?></h4>
					<?php do_action('job_main_section', $post); ?>

					<?php colabsthemes_before_post_content(); ?>
					
					<?php the_post(); the_content(); ?>
					
					<?php colabsthemes_after_post_content(); ?>

					<?php if (get_option('colabs_submit_how_to_apply_display')=='true' && get_post_meta($post->ID, '_how_to_apply', true)) { ?>

						<h4><?php _e('How to Apply','colabsthemes') ?></h4>
						<?php echo apply_filters('the_content', get_post_meta($post->ID, '_how_to_apply', true)); ?>

					<?php } ?>
                    
                    <div class="clear"></div>
                    
					<p class="job-meta"><em><?php the_taxonomies('sep=<br />'); ?><br /><?php if (!colabs_check_expired($post) && colabs_remaining_days($post)!='-') : ?><?php _e('Job expires in', 'colabsthemes') ?> <strong><?php echo colabs_remaining_days($post); ?></strong>.<?php endif; ?></em></p>

					<?php if (get_option('colabs_ad_stats_all') == 'true') { ?><p class="stats"><?php colabsthemes_stats_counter($post->ID); ?></p> <?php } ?>

					<div class="clear"></div>

    				<?php 
    					if( $colabs_options['colabs_allow_apply'] == 'true' || is_user_logged_in() ) {
    						// load up theme-actions.php and display the apply form
    						do_action('job_footer');
    					} else { ?>
    					<hr>
    					<p><?php _e('You must login or create an account in order to apply a job', 'colabsthemes'); ?></p>
    					<div class="row">
    						<div class="register-form column col7"><?php colabs_register_form( get_permalink($post->ID), '' ); ?></div>
							<div class="login-form column col5"><?php colabs_login_form( get_permalink($post->ID), get_permalink($post->ID) ); ?></div>
						</div>
    				<?php } ?>
                    
    				<ul class="section_footer" style="">
    
    					<?php if ($url = get_post_meta($post->ID, 'job_url', true)) : ?>
    						<li class="apply"><a href="<?php echo $url; ?>" <?php
    							 if ($onmousedown = get_post_meta($post->ID, 'onmousedown', true)) :
    							 	echo 'onmousedown="'.$onmousedown.'"';
    							 endif;
    						?> target="_blank" rel="nofollow"><?php _e('View &amp; Apply Online','colabsthemes'); ?></a></li>
    					<?php else :?>
    						<!--li class="apply"><a href="#apply_form" class="apply_online"><?php _e('Apply Online','colabsthemes'); ?></a></li-->
    					<?php endif; ?>
    					<?php if (is_user_logged_in() && current_user_can('can_submit_resume')) : $starred = (array) get_user_meta(get_current_user_id(), '_starred_jobs', true); ?>
    						<?php if (!in_array($post->ID, $starred)) : ?>
    							<li class="star"><a href="<?php echo add_query_arg( 'star', 'true', get_permalink() ); ?>" class="star"><?php _e('Star Job','colabsthemes'); ?></a></li>
    						<?php else : ?>
    							<li class="star"><a href="<?php echo add_query_arg( 'star', 'false', get_permalink() ); ?>" class="star"><?php _e('Un-star Job','colabsthemes'); ?></a></li>
    						<?php endif; ?>
    					<?php endif; ?>
    					<li class="print"><a href="javascript:window.print();"><?php _e('Print Job','colabsthemes'); ?></a></li>
    
    				</ul>

                </div><!-- end section-content -->

				<?php //comments_template(); ?>
				
				<?php colabsthemes_after_post(); ?>

	</div><!-- end section -->	

	<div class="clear"></div>

</div><!--/.content column col8-->

</div><!--/.row-->

<?php get_footer(); ?>