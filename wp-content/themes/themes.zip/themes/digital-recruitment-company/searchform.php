<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
     <input type="text" class="field" name="s" id="s"  />
     <input type="submit" id="searchsubmit" value="Search" />
     <input type="hidden" value="7" name="cat" id="scat" />
</form>
        
