<!DOCTYPE html>

<!--[if lt IE 7 ]> <html class="ie ie6 no-js" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 7 ]>    <html class="ie ie7 no-js" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8 ]>    <html class="ie ie8 no-js" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 9 ]>    <html class="ie ie9 no-js" <?php language_attributes(); ?>> <![endif]-->
<!--[if gt IE 9]>  <html class="no-js" <?php language_attributes(); ?>> <![endif]-->

<html lang="en-GB" class="no-js">
<head>
<title><?php wp_title(); ?></title>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css' />
<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon.ico" />
<?php wp_enqueue_script('jquery');?>
<?php wp_head(); ?>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>

<script>
   jQuery(function() {
      jQuery( "#tabs" ).tabs({      
         x: [{opacity:'toggle', duration:'normal'},   // hide option
         {opacity:'toggle', duration:'fast'}]
      });
   });
</script>

</head> 

<body <?php body_class(); ?>>
   <div id="wrapper" class="container_12">	
      <header>
         <div id="logo" class="grid_4"><a href="<?php echo home_url(); ?>" ><img src="<?php bloginfo( 'template_url' ); ?>/images/logo.jpg" width="210" height="100" alt="" /></a></div>
         <div class="grid_8">
            <ul class="social-links">
               <li class="follow">Follow Us:</li>
               <li><a id="facebook" href="" target="_blank" >facebook</a></li>
               <li><a id="twitter" href="" target="_blank" >twitter</a></li>
               <li><a id="linkedin" href="" target="_blank" >linkedin</a></li>
               <li><a id="google" href="" target="_blank" >google</a></li>
               <li><a id="rss" href="" target="_blank" >rss</a></li>
            </ul>
            <?php include ('searchform.php'); ?>
         </div>
      </header>
      <?php wp_nav_menu( array( 'theme_location' => 'topnav' ) ); ?>