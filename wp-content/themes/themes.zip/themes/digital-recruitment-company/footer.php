<footer>
	<div class="grid_4">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer 1') ) : ?><?php endif; ?>
	</div>
	<div class="grid_4">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer 2') ) : ?><?php endif; ?>
	</div>
	<div class="grid_4">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer 2') ) : ?><?php endif; ?>
	</div>
</footer>
<p class="copy grid_12">© Copyright 2012 Reynolds Digital Ltd - All Rights Reserved - <a href="http://www.reynoldsdigital.com">Web Design London</a> | XML Sitemap | RSS Feed</p>
</div>
<?php wp_footer(); ?>
</body>
</html>
