<?php
/*
Template Name: My Jobs Template
*/

### Prevent Caching
nocache_headers();

colabsthemes_auth_redirect_login();
if (!current_user_can('can_submit_job')) redirect_profile();

do_action('colabs_lister_dashboard_process');

$message = '';
$myjobsID = $post->ID;

global $userdata;

get_header(); ?>

<div class="row">

  <?php get_sidebar('user'); ?>

	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
		
		<?php if (isset($_GET['remove_listing']) && is_numeric($_GET['remove_listing'])) : 
			
				if (isset($_GET['confirm'])) :

					$post_id = $_GET['remove_listing'];
					$post_to_remove = get_post($post_id);

					global $user_ID;

					if ($post_to_remove->ID==$post_id && $post_to_remove->post_author==$user_ID) :
					//wp_delete_post($post_to_remove->ID);

					$job_post = array();
					$job_post['ID'] = $post_id;
					$job_post['post_status'] = 'private';
					wp_update_post( $job_post );
						$message = __('Job listing was ended early.','colabsthemes');
					else :
						header('Location: '.get_permalink($myjobsID));
						exit;
					endif;

				else :

					$post_id = $_GET['remove_listing'];
					$post_to_remove = get_post($post_id);

					global $user_ID;

					if ($post_to_remove->ID==$post_id && $post_to_remove->post_author==$user_ID && $post_to_remove->post_status=='publish') :
							$message = __('Are you sure you want to end ','colabsthemes');
							$message .= '&ldquo;'.$post_to_remove->post_title.'&rdquo; [<a href="'.trailingslashit(get_permalink($myjobsID)).'?remove_listing='.$post_to_remove->ID.'&amp;confirm=true">'.__('Yes','colabsthemes').'</a>] [<a href="'.trailingslashit(get_permalink($myjobsID)).'">'.__('No','colabsthemes').'</a>]';
					else :
							header('Location: '.trailingslashit(get_permalink($myjobsID)));
							exit;
					endif;

				endif;
				
		elseif(isset($_GET['pay_for_listing']) && is_numeric($_GET['pay_for_listing'])) : 
			
			global $user_ID;
			
			$post_id = $_GET['pay_for_listing'];
			
			$colabs_order = new colabs_order();
			
			if ($colabs_order->find_order_for_job($post_id)) :
				
				if ($colabs_order->status=='pending_payment' && $colabs_order->user_id==$user_ID) :
					
					$job_post = get_post($colabs_order->job_id); 
					header('Location: '.$colabs_order->generate_paypal_link());
					exit;
				
				endif;
				
			endif;
			
		endif; ?>
		        
		<div class="employer-dashboard section">
			<h3 class="section-title"><?php printf(__("%s's Dashboard", 'colabsthemes'), ucwords($userdata->display_name)); ?></h3>
			<div class="section-content">
        <?php 
        if (isset($_GET['message'])) $message = stripslashes(urldecode($_GET['message']));
            		
        if (isset($message) && !empty($message)) {
          echo '<p class="success">'.$message.'</p>';
        }
				$sizeof_jobpacks = sizeof(colabs_get_job_packs());

				// check job packs for temporary Resumes access
				$pack = colabs_get_user_job_packs_access( $user_ID );
									
				$resume_temp_access='';
				if (!empty($pack)):
					$resume_temp_access  = in_array('resume_browse', $pack['access']) ? __('Browse','colabsthemes') : '';
					$resume_temp_access .= in_array('resume_view', $pack['access']) ? ($resume_temp_access?', ':'') . __('View','colabsthemes') : '';			
				endif;
        ?>
				<h4><?php _e('My Profile', 'colabsthemes'); ?></h4>
				<p>
          <?php _e('Username:','colabsthemes')?> <?php echo $userdata->user_login; ?> <br/>
          <?php $user = new WP_User( $userdata->ID ); if ( !empty( $user->roles ) ){
              _e('Account type:','colabsthemes')?> <?php
            	if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
            		foreach ( $user->roles as $role )
            			if ($role=='job_seeker') echo __('Job Seeker', 'colabsthemes');
            			else echo __('Job Lister', 'colabsthemes');
            	}?> <br/>
					<?php } ?>
					<?php _e('Last Login:','colabsthemes'); ?> <?php colabsthemes_get_last_login($userdata->ID); ?> <br/>
					<?php _e('Member Since:','colabsthemes')?> <?php colabsthemes_get_reg_date($userdata->user_registered); ?>
				</p>
				<hr/>

				<p>
          <?php
          $mobile_number = get_user_meta($user_ID, 'mobile_number', true);
          $company_name = get_user_meta($user_ID, 'company_name', true);
          $colabs_address = get_user_meta($user_ID, 'colabs_address', true);
          ?>
					<strong><?php _e('Email','colabsthemes') ?> : </strong> <?php echo $userdata->user_email ?> <br/>
					<?php if( !empty($mobile_number) ) { ?><strong><?php _e('Mobile','colabsthemes') ?> : </strong> <?php echo $mobile_number; ?> <br/><?php } ?>
					<?php if( !empty($company_name) ) { ?><strong><?php _e('Company Name','colabsthemes') ?> : </strong> <?php echo $company_name; ?> <br/><?php } ?>
					<?php if( !empty($colabs_address) ){ ?><strong><?php _e('Location','colabsthemes') ?> : </strong> <?php echo $colabs_address; ?>
						<fieldset>
              <div id="geolocation_box">
                <?php
                $colabs_geo_latitude = get_user_meta($user_ID, 'colabs_geo_latitude', true);
                $colabs_geo_longitude = get_user_meta($user_ID, 'colabs_geo_longitude', true);
                colabs_geolocation_scripts($colabs_geo_latitude,$colabs_geo_longitude);
                ?>
                <div id="map_wrap" style="border:solid 2px #ddd;"><div id="geolocation-map" style="width:100%;height:350px;"></div></div>
              </div>
            </fieldset>
          <?php } ?>
				</p>
				<hr/>
				<ul class="display_section">
					<li><a href="#live" class="noscroll"><?php _e('Published', 'colabsthemes'); ?></a></li>
					<li><a href="#pending" class="noscroll"><?php _e('Pending', 'colabsthemes'); ?></a></li>
					<li><a href="#ended" class="noscroll"><?php _e('Ended/Expired', 'colabsthemes'); ?></a></li>
					<?php if ( $sizeof_jobpacks > 0 ) : ?><li><a href="#packs" class="noscroll"><?php _e('Job Packs', 'colabsthemes'); ?></a></li><?php endif; ?>
					<?php if ( colabs_resume_is_active_manual_subscr() || $resume_temp_access ) : ?><li><a href="#subscriptions" class="noscroll"><?php _e('Subscriptions', 'colabsthemes'); ?></a></li><?php endif; ?>
				</ul>
        <div id="live" class="myjobs_section">
					<h4><?php _e('Published Jobs', 'colabsthemes'); ?></h4>
					<?php
    			global $user_ID;
    			$args = array(
    				'ignore_sticky_posts'	=> 1,
    				'posts_per_page' => -1,
    				'author' => $user_ID,
    				'post_type' => 'job_listing',
    				'post_status' => 'publish'
    			);
    			$my_query = new WP_Query($args);
					
    			if ($my_query->have_posts()) : ?>
						<p><?php _e('Below you will find a list of jobs you have previously posted which are visible on the site.', 'colabsthemes'); ?></p>

						<table class="posted-jobs" cellpadding="0" cellspacing="0">
              <thead>
    						<tr>
    							<th class="job-title"><?php _e('Job Title','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Date Posted','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Days Remaining','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Views','colabsthemes'); ?></th>
    							<th class="right"><?php _e('Actions','colabsthemes'); ?></th>
    						</tr>
    					</thead>
    					<tbody>  						
    							<?php while ($my_query->have_posts()) : ?>  							
    								<?php $my_query->the_post(); ?>
    								<?php if (get_post_meta($my_query->post->ID, 'colabs_total_count', true)) $job_views = number_format(get_post_meta($my_query->post->ID, 'colabs_total_count', true)); else $job_views = '-'; ?> 												
    								<?php if (colabs_check_expired($post)) continue; ?>
 
    								<tr>
    									<td class="job-title"><strong><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></strong></td>
    									<td class="date"><strong><?php the_time(__('j M','colabsthemes')); ?></strong> <span class="year"><?php the_time(__('Y','colabsthemes')); ?></span></td>
    									<td class="center days"><?php echo colabs_remaining_days($my_query->post); ?></td>
    									<td class="center"><?php echo $job_views; ?></td>
                                        
<?php
global $wp_rewrite;
if( $wp_rewrite->use_trailing_slashes ){
    $permalink = "?edit=";
}else{
    $permalink = "&edit=";
}
?>
                                        
    									<td class="actions test"><?php if (get_option('colabs_allow_editing')=='true') : ?><a href="<?php echo get_permalink(get_option('colabs_edit_job_page_id')); ?><?php echo $permalink; ?><?php echo $my_query->post->ID; ?>"><?php _e('Edit&nbsp;&rarr;','colabsthemes'); ?></a>&nbsp;<?php endif; ?><a href="<?php echo trailingslashit(get_permalink($myjobsID)); ?>?remove_listing=<?php echo $my_query->post->ID; ?>" class="delete"><?php _e('End','colabsthemes'); ?></a></td>
    								</tr>
    								<?php endwhile;?>   	
    					</tbody>
						</table><!-- .posted-jobs -->
					<?php else:?>
						<p><?php _e('No live jobs found.','colabsthemes'); ?></p>
					<?php endif;?>
        </div><!--/#live-->
        
				<?php if ( $sizeof_jobpacks > 0 ) : ?>
				<div id="packs" class="myjobs_section">
					<div class="row purchase-pack">
					<?php				
						colabs_job_pack_select('dashboard', array('user'));
					?>
					</div>
					<div class="row">
					<?php	
						if ( $enable_buy = get_option('colabs_packs_dashboard_buy') == 'true' ):
							//display job pack selection form
							colabs_lister_packs_form();																							
						endif;
					?>
					</div>
				</div>
				<?php endif; ?>	
    		<div id="pending" class="myjobs_section">
    			<h4><?php _e('Pending Jobs', 'colabsthemes'); ?></h4>
    				
    			<?php
    			global $user_ID;
    			$args = array(
    				'ignore_sticky_posts'	=> 1,
    				'posts_per_page' => -1,
    				'author' => $user_ID,
    				'post_type' => 'job_listing',
    				'post_status' => 'pending'
    			);
    			$my_query = new WP_Query($args);
					
    			if ($my_query->have_posts()) : ?>  
    				<p><?php _e('The following jobs are pending and are not visible to users.', 'colabsthemes'); ?></p> 				
    				<table cellpadding="0" cellspacing="0" class="data_list">
    					<thead>
    						<tr>
    							<th><?php _e('Job Title','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Date Posted','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Status','colabsthemes'); ?></th>
    							<th class="right"><?php _e('Actions','colabsthemes'); ?></th>
    						</tr>
    					</thead>
    					<tbody>
    						<?php while ($my_query->have_posts()) : $my_query->the_post(); ?>
    							<tr>
    								<td><strong><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></strong></td>
    								<td class="date"><strong><?php the_time(__('j M','colabsthemes')); ?></strong> <span class="year"><?php the_time(__('Y','colabsthemes')); ?></span></td>
    								<td class="center"><?php 
    									$colabs_order = new colabs_order();
    			
    									if ($colabs_order->find_order_for_job($my_query->post->ID)) :
    										if ($colabs_order->status!='completed' && $colabs_order->payment_type == 'paypal') :
    											echo __('Pending Payment', 'colabsthemes');
    										else :
    											echo __('Pending Approval', 'colabsthemes');
    										endif;
    									else :
    										echo __('Pending', 'colabsthemes');
    									endif;				
    								?></td>
    								<td class="actions">
    									<?php 
    										if ($colabs_order->status && $colabs_order->status!='completed' && $colabs_order->payment_type == 'paypal') : ?><a href="<?php echo trailingslashit(get_permalink($myjobsID)); ?>?pay_for_listing=<?php echo $my_query->post->ID; ?>"><?php _e('Pay&nbsp;&rarr;','colabsthemes'); ?></a>&nbsp;<?php 
    										endif; 
    										if (get_option('colabs_allow_editing')=='true') :
    											?><a href="<?php echo trailingslashit(get_permalink(get_option('colabs_edit_job_page_id'))); ?>?edit=<?php echo $my_query->post->ID; ?>"><?php _e('Edit&nbsp;&rarr;','colabsthemes'); ?></a>&nbsp;<?php
    										endif;
    										?><a href="<?php echo trailingslashit(get_permalink($myjobsID)); ?>?remove_listing=<?php echo $my_query->post->ID; ?>" class="delete"><?php _e('Cancel','colabsthemes'); ?></a>
    								</td>
    							</tr>
    						<?php endwhile; ?>				
    					</tbody>
    				</table>
    			<?php else : ?>
    				<p><?php _e('No pending jobs found.', 'colabsthemes'); ?></p>
    			<?php endif; ?>
    		</div><!-- #pending -->

    		<div id="ended" class="myjobs_section">
    			
    			<?php
    			global $user_ID;
    			$args = array(
    						'ignore_sticky_posts'	=> 1,
    						'posts_per_page' => -1,
    						'author' => $user_ID,
    						'post_type' => 'job_listing',
    						'post_status' => 'private'
    			);
    			$my_query = new WP_Query($args);
    			$args = array(
    							'ignore_sticky_posts'	=> 1,
    							'posts_per_page' => -1,
    							'author' => $user_ID,
    							'post_type' => 'job_listing',
    							'post_status' => 'publish'
    			);
    			$my_query2 = new WP_Query($args);
    			$count = 0;
					
    			if ($my_query->have_posts() || $my_query2->have_posts()) : ?>
    				<h4><?php _e('Ended/Expired Jobs', 'colabsthemes'); ?></h4>
    				
    				<p><?php _e('The following jobs have expired or have been ended and are not visible to users.', 'colabsthemes'); ?></p>
    				
    				<table cellpadding="0" cellspacing="0" class="data_list">
    					<thead>
    						<tr>
    							<th><?php _e('Job Title','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Date Posted','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Status','colabsthemes'); ?></th>
    							<th class="center"><?php _e('Views','colabsthemes'); ?></th>
    							<th class="right"><?php _e('Actions','colabsthemes'); ?></th>
    						</tr>
    					</thead>
    					<tbody>
    						<?php if ($my_query->have_posts()) while ($my_query->have_posts()) : $my_query->the_post(); ?>
    
    						<?php if (get_post_meta($my_query->post->ID, 'colabs_total_count', true)) $job_views = number_format(get_post_meta($my_query->post->ID, 'colabs_total_count', true)); else $job_views = '-'; ?>
    
    							<tr>
    								<td><strong><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></strong></td>
    								<td class="date"><strong><?php the_time(__('j M','colabsthemes')); ?></strong> <span class="year"><?php the_time(__('Y','colabsthemes')); ?></span></td>
    								<td class="center"><?php 
    									$colabs_order = new colabs_order();
    			
    									if ($colabs_order->find_order_for_job($my_query->post->ID)) :
    										if ($colabs_order->status!='completed') :
    											echo __('Ended (order incomplete)', 'colabsthemes');
    										else :
    											echo __('Ended', 'colabsthemes');
    										endif;
    									else :
    										echo __('Ended', 'colabsthemes');
    									endif;				
    								?></td>
    								<td class="center"><?php echo $job_views; ?></td>
    								<td class="actions">
    									<?php if (get_option('colabs_allow_relist')=='true') : ?><a href="<?php echo trailingslashit(get_permalink(get_option('colabs_edit_job_page_id'))); ?>?edit=<?php echo $my_query->post->ID; ?>&amp;relist=true"><?php _e('Relist&nbsp;&rarr;','colabsthemes'); ?></a><?php endif; ?>
    								</td>
    							</tr>
    						<?php $count++; endwhile; ?>
    						<?php if ($my_query2->have_posts()) while ($my_query2->have_posts()) : $my_query2->the_post(); if (!colabs_check_expired($post)) continue; ?>
    							<tr>
    								<td><strong><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></strong></td>
    								<td class="date"><strong><?php the_time(__('j M','colabsthemes')); ?></strong> <span class="year"><?php the_time(__('Y','colabsthemes')); ?></span></td>
    								<td class="center"><?php _e('Expired', 'colabsthemes'); ?></td>
    								<td class="center"><?php echo $job_views; ?></td>
    								<td class="actions">
    									<?php if (get_option('colabs_allow_relist')=='true') : ?><a href="<?php echo trailingslashit(get_permalink(get_option('colabs_edit_job_page_id'))); ?>?edit=<?php echo $my_query2->post->ID; ?>&amp;relist=true"><?php _e('Relist&nbsp;&rarr;','colabsthemes'); ?></a><?php endif; ?>
    								</td>
    							</tr>
    						<?php $count++; endwhile;
    						
    						if ($count==0) : ?>
    								<tr>
    									<td colspan="4"><?php _e('No jobs found.','colabsthemes'); ?></td>
    								</tr>
    						<?php endif; ?>			
    					</tbody>
    				</table>
    			<?php endif; ?>
    		</div><!-- #ended -->
					
				<?php if('true' == get_option('colabs_resume_require_subscription')):?>
				<div id="subscriptions" class="myjobs_section">
						<h4><?php _e('Resume Subscriptions', 'colabsthemes');?></h4>
						<?php if (colabs_resume_is_active_manual_subscr()) :
								$valid_subscription = (get_user_meta( $user_ID, '_valid_resume_subscription', true ) == '1');
								$valid_trial =  (get_user_meta( $user_ID, '_valid_resume_trial', true ) == '1');
								$valid_subscr_date = get_user_meta( $user_ID, '_valid_resume_subscription_end', true );					
								$active_subscription = ($valid_subscription && $valid_subscr_date);
							?>

							<?php if ($active_subscription): ?>
								<p><?php echo sprintf (__('Your Resume <em>%s</em> ends <strong>%s</strong>.','colabsthemes'), ($valid_trial?'Trial':'Subscription'), date_i18n(__('j M Y g:i:s a','colabsthemes'), $valid_subscr_date)); ?></p>
							<?php else: ?>
								
								<?php
								if ($notice = get_option('colabs_resume_subscription_notice')) echo '<p>'.wptexturize($notice).'</p>';
						
								colabs_subscribe_resumes_form(get_post_type_archive_link('resume'));
								?>
							<?php endif;?>

						<?php endif; ?>

						<?php if ($resume_temp_access): ?>

							<p><?php echo sprintf(__('You have temporary access to <em>%s</em> our Resumes until <strong>%s</strong>.','colabsthemes'), $resume_temp_access, date_i18n(__('j M Y g:i:s a','colabsthemes'), strtotime($pack['expires'])) ); ?></p>

						<?php endif; ?>
				</div>
				<?php endif;?>
			</div><!-- .section-content -->
		</div><!-- .section -->

	</div><!-- .content -->

		<script type="text/javascript">
			/* <![CDATA[ */
				jQuery(function() {
					jQuery('a.delete').click(function(){
						var answer = confirm("<?php _e('Are you sure you want to end this job listing? This action cannot be undone.',"colabsthemes"); ?>")
						if (answer){
							jQuery(this).attr('href', jQuery(this).attr('href') + '&confirm=true');
							return true;
						}
						else{
							return false;
						}					
					});	
					
					jQuery('.employer-dashboard ul.display_section li a').click(function(){
						
						jQuery('.employer-dashboard div.myjobs_section').hide();
						
						jQuery(jQuery(this).attr('href')).show();
						
						jQuery('.employer-dashboard ul.display_section li').removeClass('active');
						
						jQuery(this).parent().addClass('active');
						
						return false;
					});
					jQuery('.employer-dashboard ul.display_section li a:eq(0)').click();
				});
			/* ]]> */
		</script>

</div><!-- end row -->

	<div class="clear"></div>

<?php get_footer(); ?>