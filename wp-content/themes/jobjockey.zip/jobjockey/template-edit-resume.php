<?php
/*
Template Name: Edit Resume Template
*/
?>
<?php
	### Prevent Caching
	nocache_headers();
	
	colabsthemes_auth_redirect_login();
	
	if (!current_user_can('can_submit_resume')) :
		nocache_headers();
        wp_redirect(home_url());
        exit();
	endif;
	
	if (isset($_REQUEST['edit'])) $editing = true; else $editing = false;
	
	$message = '';
	
	global $post, $job_details, $posted;
    
    colabs_load_form_scripts();

	$posted = array();
	$errors = new WP_Error();
	
	### Edit?
	
	$resume_id = 0;
	
	if (isset($_GET['edit'])) $resume_id = $_GET['edit'];
	
	if ($resume_id>0) :
		
		// Get job details
		$resume_details = get_post($resume_id);
			
		if (!isset($_POST['save_resume'])) :
			// Set post data
			$posted['resume_name'] = $resume_details->post_title;
			$posted['summary'] = $resume_details->post_content;
			$posted['skills'] = get_post_meta($resume_id, '_skills', true);
			$posted['desired_salary'] = get_post_meta($resume_id, '_desired_salary', true);
			$posted['desired_position'] = get_post_meta($resume_id, '_desired_position', true);
			
			$posted['mobile'] = get_post_meta($resume_id, '_mobile', true);
			$posted['tel'] = get_post_meta($resume_id, '_tel', true);
			$posted['email_address'] = get_post_meta($resume_id, '_email_address', true);
			
			$posted['education'] = get_post_meta($resume_id, '_education', true);
			$posted['experience'] = get_post_meta($resume_id, '_experience', true);
			
			$terms = wp_get_post_terms($resume_id, 'resume_category');
			$terms_array = array();
			foreach ($terms as $t) $terms_array[] = $t->term_id;
			if (isset($terms_array[0])) $posted['resume_cat'] = $terms_array[0];
			
			$terms = wp_get_post_terms($resume_id, 'resume_specialities');
			$terms_array = array();
			foreach ($terms as $t) $terms_array[] = $t->name;
			$posted['specialities'] = implode(', ', $terms_array);
			
			$terms = wp_get_post_terms($resume_id, 'resume_groups');
			$terms_array = array();
			foreach ($terms as $t) $terms_array[] = $t->name;
			$posted['groups'] = implode(', ', $terms_array);
			
			$terms = wp_get_post_terms($resume_id, 'resume_languages');
			$terms_array = array();
			foreach ($terms as $t) $terms_array[] = $t->name;
			$posted['languages'] = implode(', ', $terms_array);
			
			$terms = wp_get_post_terms($resume_id, 'resume_job_type');
			if ($terms) : 
				$terms = current($terms);
				$posted['desired_position'] = $terms->slug;
			else :
				$posted['desired_position'] = '';
			endif;
			
			$posted['colabs_geo_latitude'] = get_post_meta($resume_id, '_colabs_geo_latitude', true);
			$posted['colabs_geo_longitude'] = get_post_meta($resume_id, '_colabs_geo_longitude', true);
			$posted['colabs_address'] = get_post_meta($resume_id, 'geo_address', true);
			
		endif;
	
		// Permission?
		global $current_user;
        get_currentuserinfo();

		if ($current_user->ID == $resume_details->post_author) :
		
			// We have permission to edit this!
		
		else : redirect_myjobs(); endif;
	
	endif;
	
	### Process Forms
	
	$result = colabs_process_submit_resume_form( $resume_id );
		
	$errors = $result['errors'];
	$posted = $result['posted'];
?>

<?php get_header(); ?>

	<div class="row">
	
	<?php get_sidebar('resume'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
		<div class="section">
		
			<div class="section-content">
			
				<h1><?php if ($editing) _e('Edit Resume', 'colabsthemes'); else _e('Add Resume', 'colabsthemes'); ?></h1>
				
				<?php colabs_show_errors( $errors ); ?>
					
				<?php colabs_submit_resume_form( $resume_id ); ?>

			</div><!-- end section_content -->

		</div><!-- end section -->
	</div><!-- end content -->
	</div><!-- end row -->

<div class="clear"></div>

<?php get_footer(); ?>