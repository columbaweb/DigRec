<?php 

/*-----------------------------------------------------------------------------------

TABLE OF CONTENTS

Add specific IE hacks to HEAD
Add Custom Taxonomy Styling to HEAD
JobJockey Action hook

-----------------------------------------------------------------------------------*/


add_action('wp_head','colabs_IE_head');					// Add specific IE styling/hacks to HEAD
add_action('colabs_head','colabs_custom_styling');			// Add custom styling to HEAD

/*-----------------------------------------------------------------------------------*/
/* Add specific IE hacks to HEAD */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_IE_head')) {
	function colabs_IE_head() {
?>
<!--[if IE 6]>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/includes/js/pngfix.js"></script>
<![endif]-->	
<?php
	}
}

/*-----------------------------------------------------------------------------------*/
/* Add Custom Taxonomy Styling to HEAD */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_custom_styling')) {
	function colabs_custom_styling() {
	
		global $colabs_options;
		
		$output = '';
        $args = array( 'hide_empty' => 0 );
        $terms = get_terms('job_type', $args);
        $count = count($terms);
         
        if ( $count > 0 ){
            
            foreach ( $terms as $term ) {
                //get option
                $t_ID = $term->term_id;
                $button = get_option("job_type_$t_ID");
            
                if ($button) {
                	$output .= '.button.'.$term->slug.' { background-color:'.$button['color'].' !important }' . "\n";
                }
            }
        }



		// Output styles
		if (isset($output) && $output != '') {
			$output = strip_tags($output);
			$output = "<!-- ColorLabs Custom Taxonomy Styling -->\n<style type=\"text/css\">\n" . $output . "</style>\n";
			echo $output;
		}
			
	}
} 

/*-----------------------------------------------------------------------------------*/
/* JobJockey Action hook */
/*-----------------------------------------------------------------------------------*/

function colabs_menu() { colabs_do_atomic( 'colabs_menu' ); }
function colabs_prof_menu() { colabs_do_atomic( 'colabs_prof_menu' ); }

// add the post meta before the blog post content 
function colabs_blog_post_meta() {
	if(is_page()) return; // don't do post-meta on pages
	global $post;	
	
	?>
	<p class="meta"><em><?php _e('Posted by', 'colabsthemes'); ?></em> <?php the_author_posts_link(); ?> | <?php echo colabs_ad_posted($post->post_date); ?> | <?php the_category(', '); ?><?php edit_post_link('Edit', ' | ', ''); ?></p>
	<?php
}
add_action('colabsthemes_after_blog_post_title', 'colabs_blog_post_meta');


// add the post tags and counter after the blog post content only on single blog page
function colabs_blog_post_after() {
	if( !is_singular('post') ) return; // only show on blog post single page
	if(is_page()) return; // don't do post-meta on pages
	global $post;	
	
	if (get_option('colabs_ad_stats_all') == 'true') :
		?>
		<p class="stats"><?php colabsthemes_stats_counter($post->ID); ?></p>
		<?php
	endif;				
	
	the_tags('<p class="tags">' . __('Tags:', 'colabsthemes') . ' ', ', ', '</p>');
}
add_action('colabsthemes_after_blog_post_content', 'colabs_blog_post_after');


// add the error message if no pages are found
function colabs_page_loop_else() {
	?>	
	<p><?php _e('Sorry, no posts matched your criteria.', 'colabsthemes'); ?></p>
	<?php
}
add_action('colabsthemes_page_loop_else', 'colabs_page_loop_else');


// add the error message if no blog posts are found
function colabs_blog_loop_else() {
	?>	
	<p class="posts"><?php _e('No blog posts found.', 'colabsthemes'); ?></p>
	<?php
}
add_action('colabsthemes_blog_loop_else', 'colabs_blog_loop_else');


// add the error message if no resume posts are found
function colabs_resume_loop_else() {
	?>	
	<p class="resumes"><?php _e('No matching resumes found.', 'colabsthemes'); ?></p>
	<?php
}
add_action('colabsthemes_resume_loop_else', 'colabs_resume_loop_else');

// add the error message if no pages are found
function colabs_job_loop_else() {
	?>	
	<p class="jobs"><?php _e('No jobs found.', 'colabsthemes'); ?></p>
	<?php
}
add_action('colabsthemes_job_listing_loop_else', 'colabs_job_loop_else');


/* Job Listing Pages */
function colabs_expired_action() {
	$action = get_option('colabs_expired_action');
	if ($action=='hide') :
		add_filter('posts_where', 'colabs_job_not_expired');
	endif;
}
add_action('jobs_will_display', 'colabs_expired_action');


/* Main Section */
add_action('job_main_section', 'colabs_process_application_form', 1);
add_action('job_main_section', 'colabs_expired_message', 1, 1);

/* Footer */
add_action('job_footer', 'colabs_application_form', 2);
add_action('job_footer', 'colabs_share_form', 1);

?>