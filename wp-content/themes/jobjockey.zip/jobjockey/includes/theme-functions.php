<?php 

/*-----------------------------------------------------------------------------------

TABLE OF CONTENTS

- Excerpt
- Page navigation
- CoLabsTabs - Popular Posts
- CoLabsTabs - Latest Posts
- CoLabsTabs - Latest Comments
- Post Meta
- Dynamic Titles
- WordPress 3.0 New Features Support
- using_ie - Check IE
- post-thumbnail - WP 3.0 post thumbnails compatibility
- automatic-feed-links Features
- Twitter button - twitter
- Facebook Like Button - fblike
- Facebook Share Button - fbshare
- Google +1 Button - [google_plusone]
-- Load Javascript for Google +1 Button
- colabs_link - Alternate Link & RSS URL
- Open Graph Meta Function
- colabs_share - Twitter, FB & Google +1
- JobJockey Function Codes
- Pagination Single Post
- Colabs Change email name
- Allow uploading more file types
	
-----------------------------------------------------------------------------------*/

global $colabs_abbr, $colabs_log;
$colabs_abbr = get_option('colabs_shortname');

// Define the db tables we use
$colabs_db_tables = array('colabs_job_packs', 'colabs_customer_packs', 'colabs_orders', 'colabs_counter_daily', 'colabs_counter_total');

// setup the custom post types and taxonomies as constants
// do not modify this after installing or it will break your theme!
// started using in places in 1.4. slowly migrate over with the next version
define('COLABS_POST_TYPE', 'job_listing');
define('COLABS_POST_TYPE_RESUME', 'resume');
define('COLABS_TAX_CAT', 'job_cat');
define('COLABS_TAX_TAG', 'job_tag');
define('COLABS_TAX_TYPE', 'job_type');
define('COLABS_TAX_SALARY', 'job_salary');
define('COLABS_TAX_RESUME_SPECIALITIES', 'resume_specialities');
define('COLABS_TAX_RESUME_GROUPS', 'resume_groups');
define('COLABS_TAX_RESUME_LANGUAGES', 'resume_languages');
define('COLABS_TAX_RESUME_CATEGORY', 'resume_category');
define('COLABS_TAX_RESUME_JOB_TYPE', 'resume_job_type');


// Classes
include( TEMPLATEPATH . '/includes/classes/packs.class.php' );
include( TEMPLATEPATH . '/includes/classes/orders.class.php' );

// Include functions

// Payment
get_template_part('includes/gateways/paypal');

// Logging
get_template_part('includes/theme-log');
$colabs_log = new jjLog();

// Framework functions
get_template_part('includes/colabsthemes-hooks');
get_template_part('includes/theme-hooks');
get_template_part('includes/colabsthemes-functions');

// Theme functions
get_template_part('includes/theme-init');
get_template_part('includes/theme-support');
get_template_part('includes/theme-emails');
get_template_part('includes/theme-geolocation');
get_template_part('includes/theme-actions');
get_template_part('includes/theme-cron');
get_template_part('includes/theme-indeed');
get_template_part('includes/theme-resumes');
get_template_part('includes/theme-stats');
get_template_part('includes/theme-users');

// Front-end includes
if (!is_admin()) :
    get_template_part('includes/countries');
    get_template_part('includes/theme-login');
    get_template_part('includes/forms/submit-job/submit-job-process');
    get_template_part('includes/forms/submit-job/submit-job-form');
    get_template_part('includes/forms/edit-job/edit-job-process');
    get_template_part('includes/forms/edit-job/relist-job-process');
    get_template_part('includes/forms/edit-job/edit-job-form');
    get_template_part('includes/forms/confirm-job/confirm-job-process');
    get_template_part('includes/forms/confirm-job/confirm-job-form');
    get_template_part('includes/forms/preview-job/preview-job-form');
    get_template_part('includes/forms/application/application-process');
    get_template_part('includes/forms/application/application-form');
    get_template_part('includes/forms/filter/filter-process');
    get_template_part('includes/forms/filter/filter-form');
    get_template_part('includes/forms/share/share-form');
    get_template_part('includes/forms/login/login-form');
    get_template_part('includes/forms/login/login-process');
    get_template_part('includes/forms/register/register-form');
    get_template_part('includes/forms/register/register-process');
    get_template_part('includes/forms/forgot-password/forgot-password-form');
    get_template_part('includes/forms/submit-resume/submit-resume-process');
    get_template_part('includes/forms/submit-resume/submit-resume-form');
    get_template_part('includes/forms/resume/edit_parts');
    get_template_part('includes/forms/seeker-prefs/seeker-prefs-form');
    get_template_part('includes/forms/seeker-prefs/seeker-prefs-process');
		get_template_part('includes/forms/subscribe-resumes/subcribe-resumes-form');
		get_template_part('includes/forms/lister-packs/lister-packs-form');
		get_template_part('includes/forms/lister-packs/lister-packs-process');
endif;

// Admin Only Functions
if (is_admin()) :
    get_template_part('includes/admin/write-panel');
endif;
include( TEMPLATEPATH . '/includes/admin/admin-orders.php' );
include( TEMPLATEPATH . '/includes/admin/admin-jobpacks.php' );
include( TEMPLATEPATH . '/includes/admin/admin-subscriptions.php' );
include( TEMPLATEPATH . '/includes/admin/install-script.php' );
/*-----------------------------------------------------------------------------------*/
/* SET GLOBAL CoLabs VARIABLES
/*-----------------------------------------------------------------------------------*/

// Slider Tags
	$GLOBALS['slide_tags_array'] = array();
// Duplicate posts 
	$GLOBALS['shownposts'] = array();

/*-----------------------------------------------------------------------------------*/
/* Excerpt
/*-----------------------------------------------------------------------------------*/

//Add excerpt on pages
if(function_exists('add_post_type_support'))
add_post_type_support('page', 'excerpt');

/** Excerpt character limit */
/* Excerpt length */
function colabs_excerpt_length($length) {
if( get_option('colabs_excerpt_length') != '' ){
        return get_option('colabs_excerpt_length');
    }else{
        return 45;
    }
}
add_filter('excerpt_length', 'colabs_excerpt_length');

/** Remove [..] in excerpt */
function colabs_trim_excerpt($text) {
  return rtrim($text,'[...]');
}
add_filter('get_the_excerpt', 'colabs_trim_excerpt');

/** Add excerpt more */
function colabs_excerpt_more($more) {
    global $post;
	//return '<span class="more"><a href="'. get_permalink($post->ID) . '">'. __( 'Read more', 'colabsthemes' ) . '&hellip;</a></span>';
}
add_filter('excerpt_more', 'colabs_excerpt_more');

// Shorten Excerpt text for use in theme
function colabs_excerpt($text, $chars = 120) {
	$text = $text." ";
	$text = substr($text,0,$chars);
	$text = substr($text,0,strrpos($text,' '));
	$text = $text."...";
	return $text;
}



// get_the_excerpt filter
remove_filter('get_the_excerpt', 'wp_trim_excerpt');
add_filter('get_the_excerpt', 'custom_trim_excerpt');

function custom_trim_excerpt($text) { // Fakes an excerpt if needed
global $post;
	if ( '' == $text ) {
		$text = get_the_content('');

		$text = strip_shortcodes( $text );

		$text = apply_filters('the_content', $text);
		$text = str_replace(']]>', ']]&gt;', $text);
		$text = strip_tags($text);
		$excerpt_length = apply_filters('excerpt_length', 45);
		$words = explode(' ', $text, $excerpt_length + 1);
		if (count($words) > $excerpt_length) {
			array_pop($words);
            $excerpt_more = apply_filters('excerpt_more', '...');
			array_push($words, '...');
            array_push($words, $excerpt_more);
			$text = implode(' ', $words);
		}
	}
	return $text;
}
//Custom Excerpt Function
function colabs_custom_excerpt($limit,$more) {
	global $post;
	if ($limit=='')$limit=35;
	$print_excerpt = '<p>';
	$output = $post->post_excerpt;
	if ($output!=''){
	$print_excerpt .= $output;
	}else{
	$content = get_the_content('');
	$content = strip_shortcodes( $content );
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]&gt;', $content);
	$content = strip_tags($content);	
	$excerpt = explode(' ',$content, $limit);
	array_pop($excerpt);
	$print_excerpt .= implode(" ",$excerpt).$more;
	}
	$print_excerpt .= '</p>';
	echo $print_excerpt;
}
function colabs_product_excerpt($limit,$more) {
	if ($limit=='')$limit=35;
	$print_excerpt = '<p>';
	$content = get_the_content('');
	$content = strip_shortcodes( $content );
	$content = str_replace(']]>', ']]&gt;', $content);
	$content = strip_tags($content);	
	$excerpt = explode(' ',$content, $limit);
	array_pop($excerpt);
	$print_excerpt .= implode(" ",$excerpt).$more;
	$print_excerpt .= '</p>';
	echo $print_excerpt;
}


/*-----------------------------------------------------------------------------------*/
/* Page navigation */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_pagenav')) {
	function colabs_pagenav() {   
	    
			 if ( get_next_posts_link() || get_previous_posts_link() ) { ?>

                <div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav">&laquo;</span> Previous Entries', 'colabsthemes' ) ); ?></div>
                <div class="nav-next"><?php previous_posts_link( __( 'Next Entries <span class="meta-nav">&raquo;</span>', 'colabsthemes' ) ); ?></div>

			<?php } ?>

		<?php 
	}
}

if (!function_exists('colabs_postnav')) {
	function colabs_postnav() {
		?>
    <div class="navigation">
        <div class="navleft fl"><?php next_post_link('%link','&laquo; Prev') ;?></div>
		<div class="navcenter gohome"><a href="<?php echo home_url();?>">Back to home</a></div>
        <div class="navright fr"><?php previous_post_link('%link','Next &raquo;'); ?></div>
        
    </div><!--/.navigation-->
		<?php 
	}
}


if (!function_exists('colabs_custom_pagination')) {
function colabs_custom_pagination($pages = '', $range = 2)
{
     $showitems = ($range * 2)+1;
 
     global $paged;
     if(empty($paged)) $paged = 1;
 
     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }
	 
 
     if(1 != $pages)
     {
         echo "<div id='pagination'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a class='link-button' href='".get_pagenum_link(1)."'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a class='link-button' href='".get_pagenum_link($paged - 1)."'>Previous</a>";
 
         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class='link-button current'>".$i."</span>":"<a class='link-button' href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
             }
         }
 
         if ($paged < $pages && $showitems < $pages) echo "<a class='link-button' href='".get_pagenum_link($paged + 1)."'>Next</a>";
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a class='link-button' href='".get_pagenum_link($pages)."'>&raquo;</a>";
         echo "</div>\n";
     }
}
}
/*-----------------------------------------------------------------------------------*/
/* CoLabsTabs - Popular Posts */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_404')) {
	function colabs_404(){

        echo "<p>It seems that page you were looking for doesn't exist.Try searching the site.</p>";
   
	}
}
/*-----------------------------------------------------------------------------------*/
/* CoLabsTabs - Popular Posts */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_tabs_popular')) {
	function colabs_tabs_popular( $posts = 5, $size = 35 ) {
		global $post;
		$args=array(
			  'post_type' => array('post','review'),
			  'post_status' => 'publish',
			  'showposts' => $posts,
			  'orderby' => 'comment_count',
			  'caller_get_posts'=> 1
			);
		$popular = get_posts($args);
		foreach($popular as $post) :
			setup_postdata($post);
	?>
	<li>
		<?php if ($size <> 0) colabs_image('height='.$size.'&width='.$size.'&class=thumbnail&single=true'); ?>
		<a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a>
		<span class="meta"><?php the_time( get_option( 'date_format' ) ); ?></span>
		<div class="fix"></div>
	</li>
	<?php endforeach;
	}
}

/*-----------------------------------------------------------------------------------*/
/* CoLabsTabs - Latest Posts */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_tabs_latest')) {
	function colabs_tabs_latest( $posts = 5, $size = 35 ) {
		global $post;
		$args=array(
			  'post_type' => array('post','review'),
			  'post_status' => 'publish',
			  'showposts' => $posts,
			  'orderby' => 'post_date',
			  'order'=> 'desc',
			  'caller_get_posts'=> 1
			);
		$latest = get_posts($args);
		foreach($latest as $post) :
			setup_postdata($post);
	?>
	<li>
		<?php if ($size <> 0) colabs_image('height='.$size.'&width='.$size.'&class=thumbnail&single=true'); ?>
		<a title="<?php the_title(); ?>" href="<?php the_permalink() ?>"><?php the_title(); ?></a>
		<span class="meta"><?php the_time( get_option( 'date_format' ) ); ?></span>
		<div class="fix"></div>
	</li>
	<?php endforeach; 
	}
}

/*-----------------------------------------------------------------------------------*/
/* CoLabsTabs - Latest Comments */
/*-----------------------------------------------------------------------------------*/
if (!function_exists('colabs_tabs_comments')) {
	function colabs_tabs_comments( $posts = 5, $size = 35 ) {
		global $wpdb;
		$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
		comment_post_ID, comment_author, comment_author_email, comment_date_gmt, comment_approved,
		comment_type,comment_author_url,
		SUBSTRING(comment_content,1,50) AS com_excerpt
		FROM $wpdb->comments
		LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
		$wpdb->posts.ID)
		WHERE comment_approved = '1' AND comment_type = '' AND
		post_password = ''
		ORDER BY comment_date_gmt DESC LIMIT ".$posts;
		
		$comments = $wpdb->get_results($sql);
		
		foreach ($comments as $comment) {
		?>
		<li>
			<?php echo get_avatar( $comment, $size ); ?>
		
			<a href="<?php echo get_permalink($comment->ID); ?>#comment-<?php echo $comment->comment_ID; ?>" title="<?php _e('on ', 'colabsthemes'); ?> <?php echo $comment->post_title; ?>">
                <span class="author"><?php echo strip_tags($comment->comment_author); ?></span></a>: <span class="comment"><?php echo strip_tags($comment->com_excerpt); ?>...</span>
			
			<div class="fix"></div>
		</li>
		<?php 
		}
	}
}


/*-----------------------------------------------------------------------------------*/
/* WordPress 3.0 New Features Support */
/*-----------------------------------------------------------------------------------*/

if ( function_exists('register_nav_menus') ) {
	add_theme_support( 'nav-menus' );
    register_nav_menus( array(
        'primary' => __( 'Main Menu','colabsthemes' ),
		'secondary' => __( 'Secondary Menu','colabsthemes' ),
));    
}

if (!function_exists('colabs_nav_fallback')) {
function colabs_nav_fallback($div_id){
    if (is_array($div_id)){ $div_id = $div_id['theme_location']; }
    if ( $div_id == 'primary' ){
		
        wp_page_menu('depth=0&title_li=&menu_class=');
		
    };
    if ( $div_id == 'secondary' ){
       
		wp_page_menu('depth=1&title_li=&menu_class=');
		
        };
}}

/*-----------------------------------------------------------------------------------*/
/* Colabs Nav Menu */
/*-----------------------------------------------------------------------------------*/
class dropdown_walker extends Walker {
	var $tree_type = array( 'post_type', 'taxonomy', 'custom' );
	var $db_fields = array( 'parent' => 'menu_item_parent', 'id' => 'db_id' );
	function start_el(&$output, $item, $depth, $args) {
		global $wp_query;
		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
		$class_names = $value = '';
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[] = 'menu-item-' . $item->ID;
		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = ' class="' . esc_attr( $class_names ) . '"';
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
		$id = strlen( $id ) ? ' id="' . esc_attr( $id ) . '"' : '';
		$value = ' value="'. esc_attr( $item->url        ).'" ';
		$output .= $indent . '<option' . $id . $value . $class_names .'>';
		$attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
		$attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
		$attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
		$attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
		$item_output = $args->before;
		$item_output .= '<a'. $attributes .'>';
		$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
		$item_output .= '</a>';
		$item_output .= $args->after;
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
	function end_el(&$output, $item, $depth) {
		$output .= "</option>\n";
	}
}
function colabs_nav_menu( $args = array() ) {
	static $menu_id_slugs = array();
	$defaults = array( 'menu' => '', 'container' => '', 'container_class' => '', 'container_id' => '', 'menu_class' => 'menu', 'menu_id' => '',
	'echo' => true, 'fallback_cb' => 'wp_page_menu', 'before' => '', 'after' => '', 'link_before' => '', 'link_after' => '', 'items_wrap' => '<select id="%1$s" class="%2$s select">%3$s</select>','depth' => 0, 'walker' => '', 'theme_location' => '', 'show_option_none' => '' );
	$args = wp_parse_args( $args, $defaults );
	$args = apply_filters( 'wp_nav_menu_args', $args );
	$args = (object) $args;
	// Get the nav menu based on the requested menu
	$menu = wp_get_nav_menu_object( $args->menu );
	// Get the nav menu based on the theme_location
	if ( ! $menu && $args->theme_location && ( $locations = get_nav_menu_locations() ) && isset( $locations[ $args->theme_location ] ) )
		$menu = wp_get_nav_menu_object( $locations[ $args->theme_location ] );
	// get the first menu that has items if we still can't find a menu
	if ( ! $menu && !$args->theme_location ) {
		$menus = wp_get_nav_menus();
		foreach ( $menus as $menu_maybe ) {
			if ( $menu_items = wp_get_nav_menu_items($menu_maybe->term_id) ) {
				$menu = $menu_maybe;
				break;
			}
		}
	}
	// If the menu exists, get its items.
	if ( $menu && ! is_wp_error($menu) && !isset($menu_items) )
		$menu_items = wp_get_nav_menu_items( $menu->term_id );
	// If no menu was found or if the menu has no items and no location was requested, call the fallback_cb if it exists
	if ( ( !$menu || is_wp_error($menu) || ( isset($menu_items) && empty($menu_items) && !$args->theme_location ) )
		&& $args->fallback_cb && is_callable( $args->fallback_cb ) )
			return call_user_func( $args->fallback_cb, (array) $args );
	// If no fallback function was specified and the menu doesn't exists, bail.
	if ( !$menu || is_wp_error($menu) )
		return false;
	$nav_menu = $items = '';
	$show_container = false;
	if ( $args->container ) {
		$allowed_tags = apply_filters( 'wp_nav_menu_container_allowedtags', array( 'div', 'nav' ) );
		if ( in_array( $args->container, $allowed_tags ) ) {
			$show_container = true;
			$class = $args->container_class ? ' class="' . esc_attr( $args->container_class ) . '"' : ' class="menu-'. $menu->slug .'-container"';
			$id = $args->container_id ? ' id="' . esc_attr( $args->container_id ) . '"' : '';
			$nav_menu .= '<'. $args->container . $id . $class . '>';
		}
	}
	// Set up the $menu_item variables
	_wp_menu_item_classes_by_context( $menu_items );
	$sorted_menu_items = array();
	foreach ( (array) $menu_items as $key => $menu_item )
		$sorted_menu_items[$menu_item->menu_order] = $menu_item;
	unset($menu_items);
	$sorted_menu_items = apply_filters( 'wp_nav_menu_objects', $sorted_menu_items, $args );
	if ( $args->show_option_none )
			$items .= "\t<option value=\"-1\">".$args->show_option_none."</option>\n";
	$items .= walk_nav_menu_tree2( $sorted_menu_items, $args->depth, $args );
	unset($sorted_menu_items);
	// Attributes
	if ( ! empty( $args->menu_id ) ) {
		$wrap_id = $args->menu_id;
	} else {
		$wrap_id = 'menu-' . $menu->slug;
		while ( in_array( $wrap_id, $menu_id_slugs ) ) {
			if ( preg_match( '#-(\d+)$#', $wrap_id, $matches ) )
				$wrap_id = preg_replace('#-(\d+)$#', '-' . ++$matches[1], $wrap_id );
			else
				$wrap_id = $wrap_id . '-1';
		}
	}
	$menu_id_slugs[] = $wrap_id;
	$wrap_class = $args->menu_class ? $args->menu_class : '';
	// Allow plugins to hook into the menu to add their own <li>'s
	$items = apply_filters( 'wp_nav_menu_items', $items, $args );
	$items = apply_filters( "wp_nav_menu_{$menu->slug}_items", $items, $args );
	$nav_menu .= sprintf( $args->items_wrap, esc_attr( $wrap_id ), esc_attr( $wrap_class ), $items );
	unset( $items );
	if ( $show_container )
		$nav_menu .= '</' . $args->container . '>';
	$nav_menu = apply_filters( 'wp_nav_menu', $nav_menu, $args );
	if ( $args->echo )
		echo $nav_menu;
	else
		return $nav_menu;
}
function walk_nav_menu_tree2( $items, $depth, $r ) {
	$walker = ( empty($r->walker) ) ? new dropdown_walker : $r->walker;
	$args = array( $items, $depth, $r );
	return call_user_func_array( array(&$walker, 'walk'), $args );
}
function colabs_dropdown_pages($args = '') {
	$defaults = array(
		'depth' => 0, 'child_of' => 0,
		'selected' => 0, 'echo' => 1,
		'name' => 'page_id', 'id' => '',
		'show_option_none' => '', 'show_option_no_change' => '',
		'option_none_value' => '',
		'class' => 'page-dropdown-menu'
	);
	$r = wp_parse_args( $args, $defaults );
	extract( $r, EXTR_SKIP );
	$pages = get_pages($r);
	$output = '';
	$name = esc_attr($name);
	$class = esc_attr($class);
	// Back-compat with old system where both id and name were based on $name argument
	if ( empty($id) )
		$id = $name;
	if ( ! empty($pages) ) {
		$output = "<select name=\"$name\" id=\"$id\" class=\"$class\">\n";
		if ( $show_option_no_change )
			$output .= "\t<option value=\"-1\">$show_option_no_change</option>";
		if ( $show_option_none )
			$output .= "\t<option value=\"-1\">$show_option_none</option>\n";
		$output .= walk_page_dropdown_tree($pages, $depth, $r);
		$output .= "</select>\n";
	}
	$output = apply_filters('colabs_dropdown_pages', $output);
	if ( $echo )
		echo $output;
	return $output;
}

/*-----------------------------------------------------------------------------------*/
/* using_ie - Check IE */
/*-----------------------------------------------------------------------------------*/
//check IE
function using_ie()
{
    if (isset($_SERVER['HTTP_USER_AGENT']) && 
    (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false))
        return true;
    else
        return false;    
}



/*-----------------------------------------------------------------------------------*/
/* colabs_link - Alternate Link & RSS URL */
/*-----------------------------------------------------------------------------------*/
add_action( 'wp_head', 'colabs_link' );
if (!function_exists('colabs_link')) {
function colabs_link(){ 
?>	
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php if ( get_option('colabs_feedlinkurl') ) { echo get_option('colabs_feedlinkurl'); } else { echo get_bloginfo_rss('rss2_url'); } ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	
<?php 
}}

/*-----------------------------------------------------------------------------------*/
/*  Open Graph Meta Function    */
/*-----------------------------------------------------------------------------------*/
function colabs_meta_head(){
    do_action( 'colabs_meta' );
}
add_action( 'colabs_meta', 'og_meta' );  

if (!function_exists('og_meta')) {
function og_meta(){ ?>
	<?php if ( is_home() && get_option( 'colabs_og_enable' ) == '' ) { ?>
	<meta property="og:title" content="<?php echo bloginfo('name');; ?>" />
	<meta property="og:type" content="author" />
	<meta property="og:url" content="<?php echo get_option('home'); ?>" />
	<meta property="og:image" content="<?php echo get_option('colabs_og_img'); ?>"/>
	<meta property="og:site_name" content="<?php echo get_option('colabs_og_sitename'); ?>" />
	<meta property="fb:admins" content="<?php echo get_option('colabs_og_admins'); ?>" />
	<meta property="og:description" content="<?php echo get_option('blogdescription '); ?>" />
	<?php } ?>
	
	<?php if ( ( is_page() || is_single() ) && get_option( 'colabs_og_enable' ) == '' ) { ?>
	<meta property="og:title" content="<?php the_title(); ?>" />
	<meta property="og:type" content="article" />
	<meta property="og:url" content="<?php echo get_post_meta($post->ID, 'yourls_shorturl', true) ?>" />
	<meta property="og:image" content="<?php $values = get_post_custom_values("Image"); ?><?php echo get_option('home'); ?>/<?php echo $values[0]; ?>"/>
	<meta property="og:site_name" content="<?php echo get_option('colabs_og_sitename'); ?>" />
	<meta property="fb:admins" content="<?php echo get_option('colabs_og_admins'); ?>" />
	<?php } ?>
    
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<?php
}}
	
/*-----------------------------------------------------------------------------------*/	
/* Search Form*/
/*-----------------------------------------------------------------------------------*/
function custom_search( $form ) {

    $form = '<form role="search" method="get" id="searchform" action="' . home_url( '/' ) . '" >
    <input type="text" value="' . get_search_query() . '" name="s" id="s" />
    <input type="submit" id="searchsubmit" value="'. esc_attr__('Search') .'" />
    </form>';

    return $form;
}

add_filter( 'get_search_form', 'custom_search' );

/*-----------------------------------------------------------------------------------*/
/* CoLabs - Footer Credit */
/*-----------------------------------------------------------------------------------*/
function colabs_credit(){
global $themename,$colabs_options;
if( $colabs_options['colabs_footer_credit'] != 'true' ){ ?>
            Copyright &copy; 2013 <a href="http://colorlabsproject.com/themes/<?php echo get_option('colabs_themename'); ?>/" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo get_option('colabs_themename'); ?></a> by <a href="http://colorlabsproject.com/" title="Colorlabs">ColorLabs & Company</a>. All rights reserved.
<?php }else{ echo stripslashes( $colabs_options['colabs_footer_credit_txt'] ); } 
}


/*-----------------------------------------------------------------------------------*/
/*  is_mobile - Check Mobile Version */
/*-----------------------------------------------------------------------------------*/
if(!function_exists('is_mobile')){
function is_mobile(){
	$regex_match="/(nokia|iphone|android|motorola|^mot\-|softbank|foma|docomo|kddi|up\.browser|up\.link|";
	$regex_match.="htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
	$regex_match.="blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";	
	$regex_match.="symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\-|longcos|pantech|gionee|^sie\-|portalmmm|";
	$regex_match.="jig\s browser|hiptop|^ucweb|^benq|haier|^lct|opera\s*mobi|opera\*mini|320x320|240x320|176x220";
	$regex_match.=")/i";		
	return isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE']) or preg_match($regex_match, strtolower($_SERVER['HTTP_USER_AGENT']));
}}


/*-----------------------------------------------------------------------------------*/
/*  colabs_share - Twitter, FB & Google +1    */
/*-----------------------------------------------------------------------------------*/

if ( !function_exists( 'colabs_share' ) ) {
function colabs_share() {
    
$return = '';


$colabs_share_twitter = get_option('colabs_single_share_twitter');
$colabs_share_fblike = get_option('colabs_single_share_fblike');
$colabs_share_fb = get_option('colabs_single_share_fb');
$colabs_share_google_plusone = get_option('colabs_single_share_google_plusone');
$colabs_share_linked = get_option('colabs_single_share_linked');

if( $colabs_share_twitter != "true" && $colabs_share_fblike != "true" && $colabs_share_fb != "true" && $colabs_share_google_plusone != "true" ) return;

    //Share Button Functions 
    global $colabs_options;
    $url = get_permalink();
    $share = '';
    
    //Twitter Share Button
    if(function_exists('colabs_shortcode_twitter') && $colabs_share_twitter == "true"){
        $tweet_args = array(  'url' => $url,
   							'style' => 'horizontal',
   							'source' => ( $colabs_options['colabs_twitter_username'] )? $colabs_options['colabs_twitter_username'] : '',
   							'text' => '',
   							'related' => '',
   							'lang' => '',
   							'float' => 'left'
                        );

        $share .= colabs_shortcode_twitter($tweet_args);
    }
    
   
        
    //Google +1 Share Button
    if( function_exists('colabs_shortcode_google_plusone') && $colabs_share_google_plusone == "true"){
        $google_args = array(
						'size' => 'medium',
						'language' => '',
						'count' => '',
						'href' => $url,
						'callback' => '',
						'annotation' => 'bubble',
						'float' => 'left'
					);        

        $share .= colabs_shortcode_google_plusone($google_args);       
    }
	
	 //Facebook Like Button
    if(function_exists('colabs_shortcode_fblike') && $colabs_share_fblike == "true"){
    $fblike_args = 
    array(	
        'float' => 'left',
        'url' => '',
        'style' => 'button_count',
        'showfaces' => 'false',
        'width' => '100',
        'height' => '',
        'verb' => 'like',
        'colorscheme' => 'light',
        'font' => 'arial'
        );
        $share .= colabs_shortcode_fblike($fblike_args);    
    }
    
			//Linked Share Button
    if( function_exists('colabs_shortcode_linkedin_share') && $colabs_share_linked == "true"){
        $linked_args = array(
						'style' => 'right',
						'float'	=> 'none'
					);        

        $share .= colabs_shortcode_linkedin_share($linked_args);       
    }
    $return .= '<div class="social_share">'.$share.'</div><div class="clear"></div>';
    
    return $return;
}
}


/*-----------------------------------------------------------------------------------*/
/*  JobJockey Function Codes    */
/*-----------------------------------------------------------------------------------*/


// Buffer the output so headers work correctly
add_action('init', 'buffer_the_output');

function buffer_the_output() {
	ob_start();
}

// Add custom post types to the Main RSS feed
function colabs_rss_request($qv) {
	if (isset($qv['feed']) && !isset($qv['post_type'])) :
		$qv['post_type'] = array('post', 'job_listing');
	endif;
	return $qv;
}
add_filter('request', 'colabs_rss_request');

function colabs_rss_pre_get_posts($query) {
	if ($query->is_feed) $query->set('post_status','publish');
	return $query;
}
add_filter('pre_get_posts', 'colabs_rss_pre_get_posts');



// get the custom taxonomy array and loop through the values
function colabs_get_custom_taxonomy($post_id, $tax_name, $tax_class) {
    $tax_array = get_terms( $tax_name, array( 'hide_empty' => '0' ) );
    if ($tax_array && sizeof($tax_array) > 0) {
        foreach ($tax_array as $tax_val) {
            if ( is_object_in_term( $post_id, $tax_name, array( $tax_val->term_id ) ) ) { 
                echo '<span class="button '.$tax_class .' '. $tax_val->slug .'">'.$tax_val->name.'</span>';
                break;
            }
        }
    }
}

// deletes all the database tables
function colabs_delete_db_tables() {
    global $wpdb, $colabs_db_tables;

    foreach ($colabs_db_tables as $key => $value) :

        $sql = "DROP TABLE IF EXISTS ". $wpdb->prefix . $value;
        $wpdb->query($sql);

        printf(__("Table '%s' has been deleted.", 'colabsthemes'), $value);
        echo '<br/>';

    endforeach;
}

// deletes all the theme options from wp_options
function colabs_delete_all_options() {
    global $wpdb;

    $sql = "DELETE FROM ". $wpdb->options
          ." WHERE option_name like 'colabs_%'";
    $wpdb->query($sql);

    echo __("All JobJockey options have been deleted.", 'colabsthemes');
}

// Function to get theme image directory (so we can support sub themes)
if (!function_exists('get_template_image_url')) {
function get_template_image_url($image = '') {
    $theme = str_replace('.css','', get_option('colabs_child_theme'));
    if ($theme && $theme!=='style-default') return get_bloginfo('template_url').'/images/'.$theme.'/'.$image;
    else return get_bloginfo('template_url').'/images/'.$image;
}
}


// Remaining days function
if (!function_exists('colabs_remaining_days')) {
function colabs_remaining_days($post) { 
    $date = get_post_meta($post->ID, '_expires', true);
   
    if ($date) :
    
    $days = floor(($date-strtotime('NOW'))/86400);
	if ($days==1) return $days.' '.__('day','colabsthemes');
	if ($days<1) return __('Expired', 'colabsthemes'); 
	return $days.' '.__('days','colabsthemes');
	
	endif;
	
	return '-';
}
}

// Expiry check function
if (!function_exists('colabs_check_expired')) {
function colabs_check_expired($post) { 
    $date = get_post_meta($post->ID, '_expires', true);
   	
   	if ($date) if ( $date < strtotime('NOW') ) return true;
    
    return false;
}
}


// Expired Message
if (!function_exists('colabs_expired_message')) {
function colabs_expired_message($post) {
	$expired = colabs_check_expired($post); 
	if ($expired) :
		?><p class="expired"><?php _e('<strong>NOTE:</strong> This job listing has expired and may no longer be relevant!','colabsthemes'); ?></p><?php
	endif;
}
}

// Filter out expired posts
function colabs_job_not_expired($where = '') {
	
	global $wpdb;
	
	// First we need to find posts that are expired by looking at the custom value
	$exlude_ids = $wpdb->get_col($wpdb->prepare("
		SELECT      postmeta.post_id
		FROM        $wpdb->postmeta postmeta
		WHERE       postmeta.meta_key = '_expires' 
		            and postmeta.meta_value < '%s'
	", strtotime('NOW'))); 
	
	if (sizeof($exlude_ids)>0) $where .= " AND ID NOT IN (".implode(',', $exlude_ids).") ";
	
	return $where;
}
function remove_colabs_job_not_expired() {
	remove_filter('posts_where', 'colabs_job_not_expired');
}
add_action('get_footer', 'remove_colabs_job_not_expired');


// Get Page URL
if ( !function_exists('colabs_get_current_url') ) {
function colabs_get_current_url($url = '') {

	if (is_front_page() || is_search() || is_front_page()) :
		return trailingslashit(get_bloginfo('wpurl'));
	elseif (is_category()) :
		return trailingslashit(get_category_link(get_cat_id(single_cat_title("", false))));
	elseif (is_tax()) :
		
		$job_cat = get_query_var('job_cat');
		$job_type = get_query_var('job_type');
		$job_salary = get_query_var('job_salary');
		$job_tag = get_query_var( 'job_tag' );
		
		if ( isset($job_cat) && $job_cat ) :
			return trailingslashit(get_term_link( $job_cat, 'job_cat' ));
		elseif ( isset($job_type) && $job_type ) :
			return trailingslashit(get_term_link( $job_type, 'job_type' ));
		elseif ( isset($job_salary) && $job_salary ) :
			return trailingslashit(get_term_link( $job_salary, 'job_salary' ));
		elseif ( isset($job_tag) && $job_tag ) :
			return trailingslashit(get_term_link( $job_tag, 'job_tag' ));
		endif;
		
	endif;
	return trailingslashit($url);	
}
}

// Get currency function
if (!function_exists('colabs_get_currency')) {
function colabs_get_currency( $amount = '' ) {
    $currency = get_option('colabs_jobs_paypal_currency');
    $currency_pos = get_option('colabs_curr_symbol_pos');
    $currency_symbol = '';
    
    switch ($currency) :
        case 'GBP':
           $currency_symbol = '&pound;';
        break;
        case 'JPY':
            $currency_symbol = '&yen;';
        break;
        case 'EUR':
            $currency_symbol = '&euro;';
        break;
        case 'PLN' :
        	$currency_symbol = 'zl';
        break;
        default:
            $currency_symbol = '$';
        break;
    endswitch;
	    
    if ($amount) :
    
    	$amount_string = '';
    	
    	switch ($currency_pos) :
    		case 'left_space' :
    			$amount_string = '{currency} '.$amount;
    		break;
    		case 'right' :
    			$amount_string = $amount.'{currency}';
    		break;
    		case 'right_space' :
    			$amount_string = $amount.' {currency}';
    		break;
    		default:
    			$amount_string = '{currency}'.$amount;
    		break;
    	endswitch;
    	
    	return str_replace('{currency}', $currency_symbol, $amount_string);
    
    else :
    	return $currency_symbol;
    endif;

    return;
}
function colabs_get_currency_in_position( $position = 'left' ) {
    $currency = get_option('colabs_jobs_paypal_currency');
    $currency_pos = get_option('colabs_curr_symbol_pos');
    
    switch ($currency) :
        case 'GBP':
           $currency_symbol = '&pound;';
        break;
        case 'JPY':
            $currency_symbol = '&yen;';
        break;
        case 'EUR':
            $currency_symbol = '&euro;';
        break;
        case 'PLN' :
        	$currency_symbol = 'zl';
        break;
        default:
            $currency_symbol = '$';
        break;
    endswitch;
    
    switch ($currency_pos) :
		case 'left_space' :
			if ($position=='left') return $currency_symbol.' ';
		break;
		case 'right' :
			if ($position=='right') return $currency_symbol;
		break;
		case 'right_space' :
			if ($position=='right') return ' '.$currency_symbol;
		break;
		default:
			if ($position=='left') return $currency_symbol;
		break;
	endswitch;

    return '';
}
}


// get the visitor IP so we can include it with the job submission
if (!function_exists('colabs_getIP')) {
function colabs_getIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {  //check ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  //to check ip is pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
}

// tinyMCE text editor
if (!function_exists('colabs_tinymce')) {
function colabs_tinymce($width='', $height='') {
?>
<script type="text/javascript">
    <!--

	tinyMCEPreInit = {
		base : "<?php echo includes_url('js/tinymce'); ?>",
		suffix : "",
		mceInit : {
			mode : "specific_textareas",
			editor_selector : "mceEditor",
			theme : "advanced",
			skin : "default",
	        theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,formatselect,fontselect,fontsizeselect",
	        theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,bullist,numlist,|,outdent,indent,|,undo,redo,|,link,unlink,cleanup,code,|,forecolor,backcolor,|,media",
			theme_advanced_buttons3 : "",
			theme_advanced_toolbar_location : "top",
			theme_advanced_toolbar_align : "left",
			theme_advanced_statusbar_location : "bottom",
			theme_advanced_resizing : true,
			theme_advanced_resize_horizontal : false,
			content_css : "<?php echo get_bloginfo('stylesheet_directory'); ?>/style.css",
			languages : 'en',
			disk_cache : true,
			width : "<?php echo $width; ?>",
			height : "<?php echo $height; ?>",
			language : 'en'
		},
		load_ext : function(url,lang){var sl=tinymce.ScriptLoader;sl.markDone(url+'/langs/'+lang+'.js');sl.markDone(url+'/langs/'+lang+'_dlg.js');}
	};
	
	(function(){var t=tinyMCEPreInit,sl=tinymce.ScriptLoader,ln=t.mceInit.language,th=t.mceInit.theme;sl.markDone(t.base+'/langs/'+ln+'.js');sl.markDone(t.base+'/themes/'+th+'/langs/'+ln+'.js');sl.markDone(t.base+'/themes/'+th+'/langs/'+ln+'_dlg.js');})(); 
	tinyMCE.init(tinyMCEPreInit.mceInit);
    
    -->
</script>
<?php
}
}

// get the date/time of the post
if (!function_exists('colabs_ad_posted')) {
function colabs_ad_posted($m_time) {
    //$t_time = get_the_time(__('Y/m/d g:i:s A'));
    $time = get_post_time('G', true);
    $time_diff = time() - $time;

    if ( $time_diff > 0 && $time_diff < 24*60*60 )
            $h_time = sprintf( __('%s ago', 'colabsthemes'), human_time_diff( $time ) );
    else
            $h_time = mysql2date(get_option('date_format'), $m_time);
    echo $h_time;
}
}

// Filters
function custom_excerpt($text) {
	global $post;
	return str_replace(' [...]', '&hellip; <a href="'. get_permalink($post->ID) . '" class="more">' . __('read more','colabsthemes') . '</a>', $text);
}
add_filter('the_excerpt', 'custom_excerpt');

// search on custom fields
function custom_search_join($join) {
    if ( is_search() && isset($_GET['s'])) {
        global $wpdb;
       $join = " LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id ";
    }
    return($join);
}
// search on custom fields
function custom_search_groupby($groupby) {
    if ( is_search() && isset($_GET['s'])) {
        global $wpdb;
        $groupby = " $wpdb->posts.ID ";
    }
    return($groupby);
}
// search on custom fields
function custom_search_where($where) {
    global $wpdb;
    $old_where = $where;
    if (is_search() && isset($_GET['s']) && !isset($_GET['resume_search'])) {
		// add additional custom fields here to include them in search results
        $customs = array('_Company', 'geo_address', '_CompanyURL', 'geo_short_address', 'geo_country', 'geo_short_address_country');
        $query = '';
        $var_q = stripslashes($_GET['s']);
        preg_match_all('/".*?("|$)|((?<=[\\s",+])|^)[^\\s",+]+/', $var_q, $matches);
        $search_terms = array_map(create_function('$a', 'return trim($a, "\\"\'\\n\\r ");'), $matches[0]);
        
        $n = '%';
        $searchand = '';
        foreach((array)$search_terms as $term) {
            $term = addslashes_gpc($term);
            $query .= "{$searchand}(";
            $query .= "($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
            $query .= " OR ($wpdb->posts.post_content LIKE '{$n}{$term}{$n}')";
            foreach($customs as $custom) {
                $query .= " OR (";
                $query .= "($wpdb->postmeta.meta_key = '$custom')";
                $query .= " AND ($wpdb->postmeta.meta_value  LIKE '{$n}{$term}{$n}')";
                $query .= ")";
            }
            $query .= ")";
            $searchand = ' AND ';
        }
        $term = $wpdb->escape($var_q);
        $where .= " OR ($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
        $where .= " OR ($wpdb->posts.post_content LIKE '{$n}{$term}{$n}')";

        if (!empty($query)) {
            $where = " AND ({$query}) AND ($wpdb->posts.post_status = 'publish') AND ($wpdb->posts.post_type = 'job_listing')";
        }
    } else if (is_search() && isset($_GET['s'])) {
    	// add additional custom fields here to include them in search results
        $customs = array(
        	'_desired_position', 
        	'_resume_websites', 
        	'_experience', 
        	'_education', 
        	'_skills',
        	'_desired_salary',
        	'_email_address',
        	'geo_address',
        	'geo_country'
        );
        $query = '';
        $var_q = stripslashes($_GET['s']);
        preg_match_all('/".*?("|$)|((?<=[\\s",+])|^)[^\\s",+]+/', $var_q, $matches);
        $search_terms = array_map(create_function('$a', 'return trim($a, "\\"\'\\n\\r ");'), $matches[0]);
        
        $n = '%';
        $searchand = '';
        foreach((array)$search_terms as $term) {
            $term = addslashes_gpc($term);
            $query .= "{$searchand}(";
            $query .= "($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
            $query .= " OR ($wpdb->posts.post_content LIKE '{$n}{$term}{$n}')";
            foreach($customs as $custom) {
                $query .= " OR (";
                $query .= "($wpdb->postmeta.meta_key = '$custom')";
                $query .= " AND ($wpdb->postmeta.meta_value  LIKE '{$n}{$term}{$n}')";
                $query .= ")";
            }
            $query .= ")";
            $searchand = ' AND ';
        }
        $term = $wpdb->escape($var_q);
        $where .= " OR ($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
        $where .= " OR ($wpdb->posts.post_content LIKE '{$n}{$term}{$n}')";

        if (!empty($query)) {
            $where = " AND ({$query}) AND ($wpdb->posts.post_status = 'publish') AND ($wpdb->posts.post_type = 'resume')";
        }
    }
    return($where);
}
if (!is_admin()) :
	// search on custom fields
	// add_filter('posts_join', 'custom_search_join');
	// add_filter('posts_where', 'custom_search_where');
	// add_filter('posts_groupby', 'custom_search_groupby');
endif;

// redirects a user to my jobs
if (!function_exists('redirect_myjobs')) {
function redirect_myjobs( $query_string = '' ) {
	$url = get_permalink(get_option('colabs_dashboard_page_id'));
	if (is_array($query_string)) $url = add_query_arg( $query_string, $url );
    wp_redirect($url);
    exit();
}
}

// redirects a user to my profile
if (!function_exists('redirect_profile')) {
function redirect_profile( $query_string = '' ) {
	$url = get_permalink(get_option('colabs_user_profile_page_id'));
	if (is_array($query_string)) $url = add_query_arg( $query_string, $url );
    wp_redirect($url);
    exit();
}
}

// Output errors
if (!function_exists('colabs_show_errors')) {
function colabs_show_errors( $errors, $id = '' ) {
	if ($errors && sizeof($errors)>0 && $errors->get_error_code()) :
		echo '<ul class="errors" id="'.$id.'">';
		foreach ($errors->errors as $error) {
			echo '<li>'.$error[0].'</li>';
		}
		echo '</ul>';
	endif;
}
}

if (!function_exists('let_to_num')) {
	function let_to_num($v){ 
		$l = substr($v, -1);
	    $ret = substr($v, 0, -1);
	    switch(strtoupper($l)){
	    case 'P':
	        $ret *= 1024;
	    case 'T':
	        $ret *= 1024;
	    case 'G':
	        $ret *= 1024;
	    case 'M':
	        $ret *= 1024;
	    case 'K':
	        $ret *= 1024;
	        break;
	    }
	    return $ret;
	}
}

// Check if current user can select free packs
if (!function_exists('colabs_can_select_free_job_packs')):
function colabs_can_select_free_job_packs($user_id) {
	global $wpdb, $app_abbr;

	if ( !get_option($app_abbr.'_packs_free_limit') ) return true;

	$limit = get_option($app_abbr.'_packs_free_limit');
	$total = $wpdb->get_var( $wpdb->prepare("SELECT count(1) as total FROM ".$wpdb->prefix."colabs_job_packs packs, ".$wpdb->prefix."colabs_customer_packs user_packs WHERE packs.id = user_packs.pack_id AND pack_cost = '' and user_id = %d", $user_id) );

	return ($total < $limit);
}
endif;

// Get job packs
if (!function_exists('colabs_get_job_packs')):
function colabs_get_job_packs( $pack_types = array(), $filter_by_job_cat = 'yes' ) {
	global $wpdb, $posted, $user_ID;

	$where = '';
	// block free packs if the use limit is reached - ignore limit with backend job packs
	if ( ( sizeof($pack_types) > 0 && !in_array('free', $pack_types) ) || ( !colabs_can_select_free_job_packs($user_ID) && !is_admin() ) )
		$where = " WHERE pack_cost <> ''";

	$results = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."colabs_job_packs {$where}");

	$results_by_cat = array();
	if ( $results && isset($posted['job_term_cat']) && $filter_by_job_cat == 'yes' ) :
	
			foreach ( $results as $result )
				if  ( empty($result->job_cats) || (!empty($result->job_cats) && in_array( $posted['job_term_cat'], explode(',', $result->job_cats) ) ) )
					 $results_by_cat[] = $result;
				
			// only output packs by category if there's at least one pack returned. Fallback and return all the packs, otherwise 	
			if ( isset($results_by_cat) && sizeof($results_by_cat) > 0 ) $results = $results_by_cat;
				
	endif;		
	
	return $results;
}
endif;

// Get user job packs
if (!function_exists('colabs_get_user_job_packs')):
function colabs_get_user_job_packs( $user_id = 0, $filter_by_job_cat = 'yes' ) {
	global $wpdb, $posted;

	if (!$user_id)
		$user_id = get_current_user_id();

	$results_by_cat = array();
	if ($user_id>0) {
		$results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."colabs_customer_packs WHERE user_id = %d AND (jobs_count < jobs_limit OR jobs_limit = 0) AND (pack_expires > NOW() OR pack_expires = NULL OR pack_expires = '0000-00-00 00:00:00')", $user_id ) );

		if ( $results && isset($posted['job_term_cat']) && $filter_by_job_cat == 'yes' ) :
		
				foreach ( $results as $result )
					if  ( empty($result->job_cats) || ( !empty($result->job_cats) && in_array( $posted['job_term_cat'], explode(',', $result->job_cats) ) ) )
					 $results_by_cat[] = $result;
	
				$results = $results_by_cat;
				
		endif;		
			
		return $results;
	}
}
endif;

if (!function_exists('colabs_display_pack')):
function colabs_display_pack( $pack_type, $pack, $default='', $echo = FALSE, $display_options = array() ) {

	$echo_pack_jobs = $echo_pack_duration_expire = $echo_pack_access = '';
	$select_pack_html =  $operations_html = $pack_order_html = '';

	$display_defaults = array (
		'class'				=> '',	  																		// additional CSS class for the pack
		'order'				=> 'no',  																		// if set to 'yes' displays the Pack order
		'selectable'		=> 'yes', 																		// should the job pack be user selectable
	);
	$display_options = wp_parse_args( $display_options, $display_defaults);

	$echo_pack_class[] = $display_options['class'];
	$echo_pack_class[] = 'pack-id-' . $pack->id;

	switch ($pack_type): 
		case 'user':
			
			$echo_pack_class[] = 'user-pack';
			
			$pack->pack_description = '';
			$pack_remain_job_offers = $pack->job_offers;
			$pack_remain_feat_job_offers = $pack->feat_job_offers;

			if ( !$pack->jobs_limit ):
				$jobs_count = __('Unlimited', 'colabsthemes');
				$pack->jobs_count = 9999;
			else :
				$jobs_count = $pack->jobs_limit - $pack->jobs_count . ( $pack_remain_job_offers > 0 ? ' (+'.$pack_remain_job_offers.__(' Free','colabsthemes').')' : '');
				$pack->jobs_count = $pack->jobs_limit - ($pack->jobs_count+$pack_remain_job_offers);
			endif;

			if ($pack->job_duration) $echo_pack_jobs .= sprintf(' %s <small>%s</small>', __(' lasting ', 'colabsthemes'), $pack->job_duration.__(' days' ,'colabsthemes') );					
			if ($pack->pack_expires) $echo_pack_duration_expire = sprintf('%s <small>%s</small>',__('Usable before ', 'colabsthemes'), mysql2date(get_option('date_format'), $pack->pack_expires));				

			$echo_pack_cost = __('Purchased','colabsthemes');
			$echo_pack_jobs = sprintf( '<small>%s</small> %s', $jobs_count , _n(' Job Remaining', ' Jobs Remaining', (int)$pack->jobs_count, 'colabsthemes'));
						
			$select_pack_html = sprintf(
					'<div class="job-pack-choose">
						<label>%s<input type="radio" name="job_pack" value="user_%s" %s /></label>
		    	  	 </div>', __('Choose This Pack!','colabsthemes'), esc_attr($pack->id), checked($default,1, FALSE)
			);

			break;

		default:

			$echo_pack_class[] = 'new-pack';

			$echo_pack_cost = $pack->pack_cost ? colabs_get_currency($pack->pack_cost) : __('Free','colabsthemes');

			if ($pack->pack_duration) $echo_pack_duration_expire = sprintf('%s <small>%s</small>',__(' usable within ', 'colabsthemes'),$pack->pack_duration.__(' days', 'colabsthemes') );
			else $echo_pack_duration_expire =  __('Unlimited', 'colabsthemes');

			if ($pack->job_duration)$echo_pack_jobs .= sprintf('%s <small>%s</small>',__(' lasting ', 'colabsthemes'),$pack->job_duration.__(' days' ,'colabsthemes') );												

			$echo_pack_jobs = (!$pack->job_count ? __('Unlimited', 'colabsthemes') : sprintf( '<small>%s</small>', $pack->job_count . __(' Jobs', 'colabsthemes')) );

			$select_pack_html = sprintf(
					'<div class="job-pack-choose">
						<label>%s<input type="radio" name="job_pack" value="%s" %s /></label>
		    	  	 </div>',($pack->pack_cost>0?__('Buy This Pack!','colabsthemes'):__('Choose This Pack!','colabsthemes')), esc_attr($pack->id), checked($default,1, FALSE)
			);

		endswitch;

	### access

	// set the default access to job_lister (add/edit/delete jobs)
	$default_access = array('job_lister');

	if (!is_array($pack->access)) $pack->access = array_merge($default_access, explode(',', $pack->access ));

	$access = array (
					  'job_lister'     => get_option('colabs_allow_editing') == 'true' ?
					  					  __('Add/Edit/Delete Jobs', 'colabsthemes') : __('Add/Delete Jobs', 'colabsthemes'),
					  'resume_view'    => __('View Resumes', 'colabsthemes'),
					  'resume_browse'  => __('Browse Resumes', 'colabsthemes'),
			 );
	// hook into this filter to add custom access options - these must match the admin values set within the 'colabs_admin_job_pack_access_options' hook
	$access = apply_filters('colabs_job_pack_access_options', $access);
	
	foreach ($access as $key => $value)
		if ( in_array($key, $pack->access) ) $echo_pack_access .= ($echo_pack_access?', ':'').$value;
	
	
	### output
	
	// display admin only pack options
	if ( is_admin() ) :

		$operations_html = sprintf(
				'<div class="job-pack-actions"><a href="admin.php?page=jobpacks&amp;edit=%d">%s</a>
  		   		   <a href="admin.php?page=jobpacks&amp;delete=%d" class="deletepack">%s</a>
				 </div>', $pack->id, __('Edit this Pack','colabsthemes'), $pack->id, __('Delete this pack','colabsthemes')
		);

		if ( $display_options['order'] == 'yes' )
			$pack_order_html = sprintf(
					'<div class="pack-order" title="%s"><small>#%s</small></div>',
					esc_attr__('Pack Order','colabsthemes'), $pack->pack_order.($default==1?'<br/>'.__('default','colabsthemes'):'')
			);

	endif;
	
	$pack_output = sprintf(
			'<li class="%s">'.
				$pack_order_html.
				'<span class="cost">%s</span><h3>%s</h3>'.
				 ( $display_options['selectable'] == 'yes' ?$select_pack_html:'').
			    '<p class="job-pack-description">%s</p>
			    <ul class="job-pack-details">
			    	<li class="job-pack-duration"><strong>%s</strong> '.$echo_pack_duration_expire.'</li>
					<li class="job-pack-jobs-duration"><strong>%s</strong> '.$echo_pack_jobs.'</li></ul>'
				 .$operations_html.
			'</li><!-- job-pack -->',
			esc_attr(implode(' ', $echo_pack_class)), $echo_pack_cost, $pack->pack_name, $pack->pack_description, 
			__('Duration:','colabsthemes'), __('Jobs:','colabsthemes'));
			
	if ($echo) echo $pack_output;
	else return $pack_output;			  
	  
}
endif;
if (!function_exists('colabs_job_pack_select')):
function colabs_job_pack_select( $page = 'preview', $pack_types = array ( 'user', 'paid', 'free' ) ) {

	$pack_select = $pack_list = '';

	// do not filter packs by job category when relisting jobs (edit page)
	$filter_by_job_cat = ($page != 'edit' ? 'yes' : 'no');

	$packs = array();
	if (empty($pack_types) || ( in_array('free', $pack_types) || in_array('paid', $pack_types) ))
		$packs = colabs_get_job_packs( $pack_types, $filter_by_job_cat );

	$user_packs = array();
	if (empty($pack_types) || ( in_array('user', $pack_types) ))
		$user_packs = colabs_get_user_job_packs( 0, $filter_by_job_cat );

	// display packs if any, or the no active packs message
	if (sizeof($packs) > 0 || sizeof($user_packs)>0 || $page == 'dashboard' ) :

		$posted_job_pack = !empty($_POST['job_pack']) ? (int)$_POST['job_pack'] : 0;
		$default_pack=1;

		switch ( $page ):
			case 'dashboard':
				
				$title = __('My Packs', 'colabsthemes');
				if ( sizeof($user_packs) > 0 ) $sub_title = __('Below you will find a list of active packs you have purchased.', 'colabsthemes');
				else $sub_title = __('No active packs found.', 'colabsthemes');

				break;
			default:
			
				$title =  __('Select a Job Pack:', 'colabsthemes');
				$sub_title = '';
					
		endswitch;

		$pack_select = '<h2 class="pack_select '.$page.'">'. $title .'</h2><p>'.$sub_title.'</p>';

		// iterate through the user packs
		if ( sizeof($user_packs)>0 ):

			$pack_list = '';
			foreach ($user_packs as $pack) :
			
				if ($pack->id == $posted_job_pack) $default_pack = 1;
				$pack_list .= colabs_display_pack( 'user', $pack, $default_pack, $echo = FALSE, ($page=='dashboard'?array( 'selectable' => 'no' ):'') );							
				$default_pack = '';

			endforeach;

			$pack_select .= '<ul class="packs">'.$pack_list.'</ul>';

		endif;

		// iterate through the job packs
		if ( sizeof($packs)>0 ):

			$pack_list = '';
			foreach ($packs as $pack) :

				if ($pack->id == $posted_job_pack) $default_pack = 1;
				$pack_list .= colabs_display_pack( 'new', $pack, $default_pack, $echo = FALSE );
				$default_pack = '';

			endforeach;

			$title = __('Buy a Job Pack:', 'colabsthemes');
			$sub_title = __('Below you will find a list of all the job packs available for purchase.', 'colabsthemes');

			$pack_select .= '<ul class="packs">'.$pack_list.'</ul>';

		endif;

	endif;

	echo $pack_select;

	return sizeof($packs) + sizeof($user_packs);
}
endif;
// Radial location search
function colabs_radial_search($location, $radius) {
	global $wpdb, $colabs_abbr;
	
	if (function_exists('json_decode') && isset($location)) :
	
		if (!$radius) $radius = 50;
	
		// KM/Miles
		if (get_option($colabs_abbr.'_distance_unit')=='km') $radius = $radius / 1.609344;
		
		$colabs_gmaps_lang = get_option('colabs_gmaps_lang');
		$colabs_gmaps_region = get_option('colabs_gmaps_region');
	
		$address = "http://maps.google.com/maps/geo?q=".urlencode($location)."&output=json&language=".$colabs_gmaps_lang."&region=".$colabs_gmaps_region."";
		//&key=$key
		
		$cached = wp_cache_get( 'geo_'.urlencode($location) );
		
		if ($cached) :
			$address = $cached;
		else :
			$address = json_decode((file_get_contents($address)), true);
			if (is_array($address)) wp_cache_set( 'geo_'.urlencode($location) , $address ); 
		endif;
		
	   	if (is_array($address)) :
	   	
	   		$full_address = $address['Placemark'][0]['address'];
	   		
	   		if (isset($address['Placemark'][0]['Point']['coordinates'][0]) && isset($address['Placemark'][0]['Point']['coordinates'][1])) :
	   			
	   			$lng_min = 0;
	   			$lng_max = 0;
	   			$lat_min = 0;
	   			$lat_max = 0;
	   			
	   			if (isset($address['Placemark'][0]['ExtendedData']['LatLonBox'])) {
	   				// Box
	   				$north = $address['Placemark'][0]['ExtendedData']['LatLonBox']['north'];
	   				$south = $address['Placemark'][0]['ExtendedData']['LatLonBox']['south'];
	   				$east = $address['Placemark'][0]['ExtendedData']['LatLonBox']['east'];
	   				$west = $address['Placemark'][0]['ExtendedData']['LatLonBox']['west'];
	   				
	   				$lng_max = $east + ($radius / 69);
					$lng_min = $west - ($radius / 69);
					$lat_min = $south - ($radius / 69);
					$lat_max = $north + ($radius / 69);
					
	   			} else {
	   				// Point (fallback)
	   				$longitude = $address['Placemark'][0]['Point']['coordinates'][0];
		   			$latitude = $address['Placemark'][0]['Point']['coordinates'][1];
		   			
		   			$lng_min = $longitude - $radius / abs(cos(deg2rad($latitude)) * 69);
					$lng_max = $longitude + $radius / abs(cos(deg2rad($latitude)) * 69);
					$lat_min = $latitude - ($radius / 69);
					$lat_max = $latitude + ($radius / 69);
	   			}
				
	   			$results1 = $wpdb->get_col("
	   				SELECT ID
	   				FROM $wpdb->posts
	   				LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
	   				WHERE meta_key = '_colabs_geo_latitude'
	   				AND (meta_value+0) between ('$lat_min') AND ('$lat_max');
	   			");
	   			$results2 = $wpdb->get_col("
	   				SELECT ID
	   				FROM $wpdb->posts
	   				LEFT JOIN $wpdb->postmeta ON $wpdb->posts.ID = $wpdb->postmeta.post_id
	   				WHERE meta_key = '_colabs_geo_longitude'
	   				AND (meta_value+0)  between ('$lng_min') AND ('$lng_max');
	   			");
	   			
	   			$posts = array_intersect($results1, $results2);
				
				return array('address' => $full_address, 'posts' => $posts);
	   		endif;
	   	endif;
		
	endif;
	return false;
}

// Outputs a single or plural textual date unit
function colabs_format_date_unit ($unit, $length=1){

	$plural = ($length > 1?'s':'');

	$text = array (
		'm' => 'month',
		'd' => 'day',
		'w' => 'week',
		'y' => 'year'
	);

	return $text[strtolower($unit)].$plural;
}

// creates the charts on the dashboard
function colabs_dashboard_charts() {
	global $wpdb;

	$sql = "SELECT COUNT(post_title) as total, post_date FROM ". $wpdb->posts ." WHERE post_type = 'job_listing' AND post_date > '" . date('Y-m-d', strtotime('-30 days')) . "' GROUP BY DATE(post_date) DESC";
	$results = $wpdb->get_results($sql);

	$listings = array();

	// put the days and total posts into an array
	foreach ($results as $result) {
		$the_day = date('Y-m-d', strtotime($result->post_date));
		$listings[$the_day] = $result->total;
	}

	// setup the last 30 days
	for($i = 0; $i < 30; $i++) {
		$each_day = date('Y-m-d', strtotime('-'. $i .' days'));

		// if there's no day with posts, insert a goose egg
		if (!in_array($each_day, array_keys($listings))) $listings[$each_day] = 0;
	}

	// sort the values by date
	ksort($listings);

	// print_r($listings);

	// Get sales - completed orders with a cost
	$sql = "SELECT SUM(cost) as total, order_date FROM ".$wpdb->prefix."colabs_orders WHERE status = 'completed' AND order_date > '" . date('Y-m-d', strtotime('-30 days')) . "' GROUP BY DATE(order_date) DESC";
	$results = $wpdb->get_results($sql);

	$sales = array();

	// put the days and total posts into an array
	foreach ($results as $result) {
		$the_day = date('Y-m-d', strtotime($result->order_date));
		$sales[$the_day] = $result->total;
	}

	// setup the last 30 days
	for($i = 0; $i < 30; $i++) {
		$each_day = date('Y-m-d', strtotime('-'. $i .' days'));

		// if there's no day with posts, insert a goose egg
		if (!in_array($each_day, array_keys($sales))) $sales[$each_day] = 0;
	}

	// sort the values by date
	ksort($sales);
?>

<div id="placeholder"></div>

<script language="javascript" type="text/javascript">
// <![CDATA[
jQuery(function () {

    var posts = [
		<?php
		foreach ($listings as $day => $value) {
			$sdate = strtotime($day);
			$sdate = $sdate * 1000; // js timestamps measure milliseconds vs seconds
			$newoutput = "[$sdate, $value],\n";
			//$theoutput[] = $newoutput;
			echo $newoutput;
		}
		?>
	];

	var sales = [
		<?php
		foreach ($sales as $day => $value) {
			$sdate = strtotime($day);
			$sdate = $sdate * 1000; // js timestamps measure milliseconds vs seconds
			$newoutput = "[$sdate, $value],\n";
			//$theoutput[] = $newoutput;
			echo $newoutput;
		}
		?>
	];


	var placeholder = jQuery("#placeholder");

	var output = [
		{
			data: posts,
			label: "<?php _e('New Job Listings', 'colabsthemes') ?>",
			symbol: ''
		},
		{
			data: sales,
			label: "<?php _e('Total Sales', 'colabsthemes') ?>",
			symbol: '<?php echo colabs_get_currency(); ?>',
			yaxis: 2
		}
	];

	var options = {
       series: {
		   lines: { show: true },
		   points: { show: true }
	   },
	   grid: {
		   tickColor:'#f4f4f4',
		   hoverable: true,
		   clickable: true,
		   borderColor: '#f4f4f4',
		   backgroundColor:'#FFFFFF'
	   },
       xaxis: { mode: 'time',
				timeformat: "%m/%d"
	   },
	   yaxis: { min: 0 },
	   y2axis: { min: 0, tickFormatter: function (v, axis) { return "<?php echo colabs_get_currency_in_position('left'); ?>" + v.toFixed(axis.tickDecimals) + "<?php echo colabs_get_currency_in_position('right'); ?>" }},
	   legend: { position: 'nw' }
    };

	jQuery.plot(placeholder, output, options);

	// reload the plot when browser window gets resized
	jQuery(window).resize(function() {
		jQuery.plot(placeholder, output, options);
	});

	function showChartTooltip(x, y, contents) {
		jQuery('<div id="charttooltip">' + contents + '</div>').css( {
		position: 'absolute',
		display: 'none',
		top: y + 5,
		left: x + 5,
		opacity: 1
		}).appendTo("body").fadeIn(200);
	}

	var previousPoint = null;
	jQuery("#placeholder").bind("plothover", function (event, pos, item) {
		jQuery("#x").text(pos.x.toFixed(2));
		jQuery("#y").text(pos.y.toFixed(2));
		if (item) {
			if (previousPoint != item.datapoint) {
                previousPoint = item.datapoint;

				jQuery("#charttooltip").remove();
				var x = new Date(item.datapoint[0]), y = item.datapoint[1];
				var xday = x.getDate(), xmonth = x.getMonth()+1; // jan = 0 so we need to offset month
				showChartTooltip(item.pageX, item.pageY, xmonth + "/" + xday + " - <b>" + item.series.symbol + y + "</b> " + item.series.label);
			}
		} else {
			jQuery("#charttooltip").remove();
			previousPoint = null;
		}
	});
});
// ]]>
</script>

<?php 
}

function colabs_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
	
	// Default Layout
	$wp_customize->add_section( 'colabs_layout_settings', array(
		'title'    => __( 'Layout', 'colabsthemes' ),
		'priority' => 50,
	) );

	$wp_customize->add_setting( 'colabs_layout_settings', array(
		'type'              => 'option',
		'default'           => get_option('colabs_layout_settings'),
		'capability' 		=> 'manage_options'
	) );

	$layout_options = array(
		'content-sidebar' => array(
			'value' => 'two-col-left',
			'label' => __( 'Content on left', 'colabsthemes' )
		),
		'sidebar-content' => array(
			'value' => 'two-col-right',
			'label' => __( 'Content on right', 'colabsthemes' )
		),
		
	);
	$choices = array();
	foreach ( $layout_options as $layout ) {
		$choices[$layout['value']] = $layout['label'];
	}

	$wp_customize->add_control( 'colabs_layout_settings', array(
		'section'    => 'colabs_layout_settings',
		'type'       => 'radio',
		'choices'    => $choices,
	) );
	
	// Logo Settings
	  // -------------
	  $wp_customize->add_section( 'logo_settings', array(
		'title'    => __( 'Logo Settings', 'colabsthemes' ),
		'priority' => 50,
	  ) );

	  $wp_customize->add_setting( 'colabs_logo', array(
		'type'        => 'option',
		'capability'  => 'manage_options',
	  ) );

	  $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'colabs_logo', array(
		'label'    => __( 'Logo', 'colabsthemes' ),
		'section'  => 'logo_settings',
		'settings' => 'colabs_logo',
		'priority' => 5,
		'label'      => __('Upload a logo for your theme. Best image size in 149x168 px', 'colabsthemes')
	  ) ) );
}
add_action( 'customize_register', 'colabs_customize_register' );	

function colabs_customize_preview_js() {
	wp_enqueue_script( 'colabs-customizer', get_template_directory_uri() . '/includes/js/theme-customizer.js', array( 'customize-preview' ), '20120523', true );
}
add_action( 'customize_preview_init', 'colabs_customize_preview_js' );

//Fix for home page navigation error on WP 3.4
function colabs_query_for_homepage( $query ) {
global $paged;
    if( $query->is_main_query() && $query->is_home() ) {
        $query->set( 'post_type', array( 'post', 'job_listing' ) );
    }
		if ($query->is_author)
        $query->set( 'post_type', array('post', 'page', 'job_listing') );
    remove_action( 'pre_get_posts', 'colabs_query_for_homepage' );
}
add_action( 'pre_get_posts', 'colabs_query_for_homepage' );

/*-----------------------------------------------------------------------------------*/
/* Pagination Single Post */
/*-----------------------------------------------------------------------------------*/
if ( function_exists('pagination_after_post') ) {	
add_filter ('get_the_content', 'pagination_after_post');
add_filter ('the_content', 'pagination_after_post');
function pagination_after_post($content) {
   if(is_single()) {
      $content.= wp_link_pages(array('before' => __('<p><strong>Pages:</strong>','colabsthemes'), 'after' => '</p>', 'next_or_number' => 'number','echo'=>0));
   }
   return $content;
}
}
	
/*-----------------------------------------------------------------------------------
Colabs Change email name
-----------------------------------------------------------------------------------*/
function colabs_email_name($name = '') {
	$name = get_option('colabs_email_name','');
	if($name!='')
     return $name;
	else
     return get_bloginfo('name');
}
add_filter('wp_mail_from_name', 'colabs_email_name');

/*-----------------------------------------------------------------------------------
Allow uploading more file types
-----------------------------------------------------------------------------------*/
function colabs_upload_mime_types( $mime_types ) {
	$mime_types['rtf'] = 'application/rtf';
	$mime_types['txt'] = 'text/plain';
	$mime_types['zip'] = 'application/zip';

	return $mime_types;
}
add_filter( 'upload_mimes', 'colabs_upload_mime_types' );

function SearchFilterJOB($query) {
	if ($query->is_search) {
		$query->set('post_type', 'job_listing');
	}
	return $query;
}

add_action('pre_get_posts','SearchFilterJOB');
?>