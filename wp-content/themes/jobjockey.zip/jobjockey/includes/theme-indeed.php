<?php
/**
 * Indeed Integration
 * Posts Jobs from Indeed Hourly
 *
 *
 * @version 1.0
 * @author ColorLabs
 * @package Jobjockey
 * @copyright 2012 all rights reserved
 *
 */
 
define('INDEED_VERSION', 2);
define('INDEED_SORT', 'date');

// Map Job Types Taxonomy
define('INDEED_FULLTIME', 'Full-Time');
define('INDEED_PARTTIME', 'Part-Time');
define('INDEED_CONTRACT', 'Freelance');
define('INDEED_TEMP', 'Temporary');
define('INDEED_INTERN', 'Internship');

function colabs_schedule_get_indeed_jobs(){
	wp_schedule_event(time(), 'hourly', 'colabs_get_indeed_jobs');
	wp_schedule_event(time(), 'daily', 'colabs_check_indeed_jobs');
	update_option('colabs_get_indeed_jobs', 'true');
}

if (get_option('colabs_get_indeed_jobs')!=='true') colabs_schedule_get_indeed_jobs();

add_action('colabs_get_indeed_jobs', 'colabs_get_indeed_jobs');
add_action('colabs_check_indeed_jobs', 'colabs_check_indeed_jobs');
// add_action('init', 'colabs_get_indeed_jobs');
// add_action('init', 'colabs_check_indeed_jobs');

function colabs_get_indeed_jobs() {
	
	global $wpdb, $colabs_log;
	
	$colabs_enable_indeed_feeds = get_option('colabs_enable_indeed_feeds');
	$colabs_indeed_publisher_id = get_option('colabs_indeed_publisher_id');
	$colabs_indeed_queries = get_option('colabs_indeed_queries');
	$colabs_indeed_status = get_option('colabs_indeed_status');
	if ($colabs_enable_indeed_feeds=='true' && $colabs_indeed_publisher_id && $colabs_indeed_queries) :
	
		if (!$colabs_indeed_status) $colabs_indeed_status = 'publish';
		
		if ($colabs_indeed_queries) :
		
			$colabs_indeed_queries = explode("\n", $colabs_indeed_queries);
			
			// 1 per cron to prevent memory outage
			$index = get_option('colabs_indeed_xml_index');
			$index++;
			
			if (sizeof($colabs_indeed_queries) < $index) $index = 0;
			update_option('colabs_indeed_xml_index', $index);
			
			$loop = -1;
			
			if (sizeof($colabs_indeed_queries)>0) foreach ($colabs_indeed_queries as $query_row) : $loop++;
			
				if ($loop!=$index) continue;
				
				$colabs_log->write_log('Running Indeed Query - '.$query_row); 
				
				$query = explode('|', $query_row);
				
				if (sizeof($query)==5) :
					$keyword = urlencode(strtolower(trim($query[0])));
					$limit = $query[1];
					$country = $query[2];
					$job_type = $query[3];
					$job_cat = $query[4];
					
					if ($limit>100) $limit = 100;
					
					$indeed_result = wp_remote_get('http://api.indeed.com/ads/apisearch?v='.INDEED_VERSION.'&publisher='.trim($colabs_indeed_publisher_id).'&sort='.INDEED_SORT.'&limit='.$limit.'&co='.$country.'&jt='.$job_type.'&q='.$keyword);
					
					if (is_wp_error($indeed_result)) :
						$colabs_log->write_log('Indeed - wp_remote_get failed.');
						return false;
					else :
						$colabs_log->write_log('Indeed - wp_remote_get succeeded.');
					endif;
					
					$indeed_result = $indeed_result['body'];
					
					$xml = new SimpleXMLElement($indeed_result);
					
					$xmlresults = $xml->results;
					
					$colabs_log->write_log('Indeed Query Results Size - '.(sizeof($xmlresults->result))); 

					foreach($xmlresults->result as $result) :
					
						$x = array();
						
						if (isset($result->jobkey))  $x['jobkey']  = (string) $result->jobkey;

						$found_job = $wpdb->get_var('SELECT meta_value FROM '.$wpdb->postmeta.' WHERE meta_key="indeed_key" AND meta_value="'.$wpdb->prepare($x['jobkey']).'";');
						
						if (!$found_job) :
						
							if (isset($result->snippet)) 	$x['snippet'] 	= (string) $result->snippet;
							if (isset($result->jobtitle)) 	$x['jobtitle'] 	= (string) $result->jobtitle;
							if (isset($result->company)) 	$x['company'] 	= (string) $result->company;
							if (isset($result->url)) 		$x['url'] 		= (string) $result->url;
							if (isset($result->latitude)) 	$x['latitude'] 	= (string) $result->latitude;
							if (isset($result->longitude)) 	$x['longitude'] = (string) $result->longitude;
							if (isset($result->formattedLocation)) $x['formattedLocation'] 	= (string) $result->formattedLocation;
							if (isset($result->country)) 	$x['country'] 	= (string) $result->country;
							if (isset($result->onmousedown)) $x['onmousedown'] 	= (string) $result->onmousedown;
							
							$x = array_map('trim', $x);
							
							$formatted_job_content = '';
							if (!empty($x['company'])) $formatted_job_content = '<em>'.$x['company'].'</em>'.__(' require a ', 'colabsthemes');
							$formatted_job_content .= '&ldquo;<strong>'.$x['jobtitle'].'</strong>&rdquo;'.__(' in ', 'colabsthemes').$x['formattedLocation'].':<br /><br />
								<blockquote>'.$x['snippet'].'</blockquote>
								
								<p class="attribution"><a href="http://www.indeed.com/">jobs</a> by <a href="http://www.indeed.com/" title="Job Search"><img src="http://www.indeed.com/p/jobsearch.gif" alt="Indeed job search" /></a></p>
								';
							
							$data = array(
								'post_content' => $wpdb->escape( $formatted_job_content )
								, 'post_title' => $wpdb->escape($x['jobtitle'])
								, 'post_status' => $colabs_indeed_status
								, 'post_type' => 'job_listing'
							);
							$post_id = wp_insert_post($data);
							
							add_post_meta($post_id, '_Company', $x['company'], true);
							add_post_meta($post_id, 'job_url', $x['url'], true);
							add_post_meta($post_id, 'indeed_key', $x['jobkey'], true);
							add_post_meta($post_id, 'onmousedown', $x['onmousedown'], true);
							
							if (isset($x['latitude']) && !empty($x['latitude']) && isset($x['longitude']) && !empty($x['longitude'])) :
							
								$latitude = colabs_clean_coordinate($x['latitude']);
								$longitude = colabs_clean_coordinate($x['longitude']);
								
								add_post_meta($post_id, '_colabs_geo_latitude', $latitude, true);
								add_post_meta($post_id, '_colabs_geo_longitude', $longitude, true);
								
								if ($latitude && $longitude) :
									$address = colabs_reverse_geocode($latitude, $longitude);
									
									add_post_meta($post_id, 'geo_address', $address['address'], true);
									add_post_meta($post_id, 'geo_country', $address['country'], true);
									add_post_meta($post_id, 'geo_short_address', $address['short_address'], true);
									add_post_meta($post_id, 'geo_short_address_country', $address['short_address_country'], true);
						
								endif;
							else :
								
								add_post_meta($post_id, 'geo_address', $x['formattedLocation'], true);
								add_post_meta($post_id, 'geo_country', $x['country'], true);
								add_post_meta($post_id, 'geo_short_address', $x['formattedLocation'], true);
								add_post_meta($post_id, 'geo_short_address_country', $x['country'], true);
								
								if (function_exists('json_decode') && isset($x['formattedLocation'])) :
							
									$address = wp_remote_get("http://maps.google.com/maps/geo?q=".urlencode($x['formattedLocation'])."&output=json");
					
									if (!is_wp_error($address)) :
					
										$address = json_decode($address['body'], true);
								
									   	if (is_array($address)) :
									   		if (isset($address['Placemark'][0]['Point']['coordinates'][0]) && isset($address['Placemark'][0]['Point']['coordinates'][1])) :
									   			$longitude = $address['Placemark'][0]['Point']['coordinates'][0];
									   			$latitude = $address['Placemark'][0]['Point']['coordinates'][1];
									   			
									   			add_post_meta($post_id, '_colabs_geo_latitude', $latitude, true);
												add_post_meta($post_id, '_colabs_geo_longitude', $longitude, true);
									   		endif;
									   	endif;
									   	
									endif;
									
								endif;
								
								unset($address);
							
							endif;		

							$post_into_cats = array();
							$post_into_types = array();
							
							if ($job_cat) $post_into_cats[] = $job_cat;

							if (sizeof($post_into_cats)>0) wp_set_object_terms($post_id, $post_into_cats, 'job_cat');
							
							switch ($job_type) :
								case "fulltime" :
									$post_into_types[] = INDEED_FULLTIME;
								break;
								case "parttime" :
									$post_into_types[] = INDEED_PARTTIME;
								break;
								case "contract" :
									$post_into_types[] = INDEED_CONTRACT;
								break;
								case "internship" :
									$post_into_types[] = INDEED_INTERN;
								break;
								case "temporary" :
									$post_into_types[] = INDEED_TEMP;
								break;
							endswitch;
							
							if (sizeof($post_into_types)>0) wp_set_object_terms($post_id, $post_into_types, 'job_type');
							
						endif;
					
					endforeach;
					
					unset($xml);
					unset($xmlresults);
					unset($indeed_result);
								
				endif;
				
			endforeach;
			
		endif;
	
	endif;
	
}

function colabs_check_indeed_jobs() {
	
	global $wpdb;
	
	// Auto delete option
	$auto_trash = get_option('colabs_indeed_auto_trash');
	
	if ($auto_trash > 0) :
		
		$postids = $wpdb->get_col($wpdb->prepare("
			SELECT      DISTINCT postmeta.post_id
			FROM        $wpdb->postmeta postmeta
			LEFT JOIN	$wpdb->posts posts ON postmeta.post_id = posts.ID
			WHERE       postmeta.meta_key = 'indeed_key' 
			            AND posts.post_date < DATE_SUB(CURDATE(), INTERVAL %s DAY)
			            AND posts.post_status = 'publish'
			            AND posts.post_type = 'job_listing'
			LIMIT 200
		", $auto_trash)); 	
			
		if ($postids) foreach ($postids as $id) :
			wp_delete_post($id, false);
		endforeach;
	
	endif;
	
	// Check expired indeed jobs and delete any
	$colabs_indeed_publisher_id = get_option('colabs_indeed_publisher_id');
	
	$job_keys = $wpdb->get_col('
		SELECT meta_value 
		FROM '.$wpdb->postmeta.' 
		LEFT JOIN '.$wpdb->posts.' ON '.$wpdb->postmeta.'.post_id = '.$wpdb->posts.'.ID 
		WHERE meta_key="indeed_key"
		AND '.$wpdb->posts.'.post_status = "publish"
		LIMIT 200
		');

	$indeed_result = wp_remote_get('http://api.indeed.com/ads/apigetjobs?v='.INDEED_VERSION.'&publisher='.trim($colabs_indeed_publisher_id).'&jobkeys='.implode(',', $job_keys));
					
	if (is_wp_error($indeed_result)) return false;
					
	$xml = new SimpleXMLElement($indeed_result['body']);
					
	$xmlresults = $xml->results;

	foreach($xmlresults->result as $result) :
	
		$x = array();
	
		if (isset($result->jobkey))  $x['jobkey']  = (string) $result->jobkey;
		if (isset($result->expired)) $x['expired'] = (string) $result->expired;
		
		if ($x['expired']=='true') :
		
			// Remove post
			$id = $wpdb->get_var('
				SELECT '.$wpdb->posts.'.ID 
				FROM '.$wpdb->posts.' 
				LEFT JOIN '.$wpdb->postmeta.' ON '.$wpdb->posts.'.ID = '.$wpdb->postmeta.'.post_id 
				WHERE meta_key="indeed_key"
				AND '.$wpdb->posts.'.post_status = "publish"
				AND meta_value = "'.$x['jobkey'].'"
				LIMIT 1
			');
			
			if ($id>0) :
				wp_delete_post($id, false);
				/*$job_post = array();
				$job_post['ID'] = $id;				
				$job_post['post_status'] = 'private';					
				wp_update_post( $job_post );
				
				// Update counts for the post's terms.
				foreach ( (array) get_object_taxonomies('job_listing') as $taxonomy ) {	
					$tt_ids = wp_get_object_terms($id, 'job_cat', array('fields' => 'tt_ids'));
					wp_update_term_count($tt_ids, 'job_cat');
					$tt_ids = wp_get_object_terms($id, 'job_type', array('fields' => 'tt_ids'));
					wp_update_term_count($tt_ids, 'job_type');
				}
				
				add_post_meta($id, 'indeed_expired', 'true', true);*/
			endif;
		endif;

	endforeach;

}

// No search results indeed search

function colabs_indeed_search_results() {
	
	wp_reset_postdata();
	
	if (!is_search()) return;
	
	$colabs_indeed_publisher_id = get_option('colabs_indeed_publisher_id');
	
	if ($colabs_indeed_publisher_id) :
	
		$keyword = urlencode(strtolower(trim(get_search_query())));
		$limit = 20;
		$job_type = 'fulltime';
		if(isset($_SERVER['HTTP_X_FORWARD_FOR'])) $ip = $_SERVER['HTTP_X_FORWARD_FOR']; else $ip = $_SERVER['REMOTE_ADDR'];
		
		// Location
		$location_query = '';
		$country = '';
		$colabs_gmaps_lang = get_option('colabs_gmaps_lang');
		$colabs_gmaps_region = get_option('colabs_gmaps_region');
		if (isset($_GET['location'])) $location = trim($_GET['location']); else $location = '';
		if (isset($_GET['radius']) && $_GET['radius']>0) $radius = trim($_GET['radius']); else $radius = 50;
		
		if ($location) :
			
			
			
			$address = "http://maps.google.com/maps/geo?q=".urlencode($location)."&output=json&language=".$colabs_gmaps_lang."&region=".$colabs_gmaps_region."";
			
			$cached = wp_cache_get( 'geo_'.urlencode($location) );
			
			if ($cached) :
				$address = $cached;
			else :
				$address = json_decode((file_get_contents($address)), true);
				if (is_array($address)) wp_cache_set( 'geo_'.urlencode($location) , $address ); 
			endif;
	
		   	if (is_array($address)) :
		   		
		   		if (isset($address['Placemark'][0]['AddressDetails']['Country']['CountryNameCode'])) $country = $address['Placemark'][0]['AddressDetails']['Country']['CountryNameCode'];
		   		
		   		//if (isset($address['Placemark'][0]['address'])) $location = $address['Placemark'][0]['address'];
		   		
		   	endif;
		   	
		   	$location_query = '&l='.urlencode($location);
		
		else :
			// Get user country to search instead
			$country = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
			$result = wp_remote_get('http://api.hostip.info/country.php?ip='.$ip);				
			if (!is_wp_error($result)) $country = $result['body'];
		endif;

		// Default to US
		if (!$country) $country = 'US';
		
		$country = strtolower($country);
		
		// Do the query				
		$indeed_result = wp_remote_get('http://api.indeed.com/ads/apisearch?v='.INDEED_VERSION.'&publisher='.trim($colabs_indeed_publisher_id).'&sort='.INDEED_SORT.'&limit='.$limit.'&co='.$country.'&jt='.$job_type.'&q='.$keyword.$location_query);
						
		if (is_wp_error($indeed_result)) return false;
						
		$xml = new SimpleXMLElement($indeed_result['body']);
						
		$xmlresults = $xml->results;
		
		$search_results = array();
						
		foreach($xmlresults->result as $result) :
						
			$x = array();
	
			if (isset($result->jobkey)) 	$x['jobkey'] 	= (string) $result->jobkey;
			if (isset($result->jobtitle)) 	$x['jobtitle'] 	= (string) $result->jobtitle;
			if (isset($result->company)) 	$x['company'] 	= (string) $result->company;
			if (isset($result->url)) 		$x['url'] 		= (string) $result->url;
			if (isset($result->formattedLocation)) $x['formattedLocation'] 	= (string) $result->formattedLocation;
			if (isset($result->country)) 	$x['country'] 	= (string) $result->country;
			if (isset($result->onmousedown)) $x['onmousedown'] 	= (string) $result->onmousedown;
			if (isset($result->date)) $x['date'] 	= (string) $result->date;
							
			$x = array_map('trim', $x);
			
			$search_results[] = $x;
							
		endforeach;
									
		if (sizeof($search_results)==0) return;
	
		$alt = 1;
		
		echo '<h2>' . sprintf( __('Sponsored Search Results for &ldquo;%s&rdquo;', 'colabsthemes'), get_search_query() ) . '</h2>';
	
	    foreach ($search_results as $x) :
			
			$post_class = array('job');
			if ($alt==1) $post_class[] = 'job-alt';
			
			?>
			<div class="jobs-post clearfix <?php echo implode(' ', $post_class); ?>">

        		<div class="column col6">
        			<h4><a href="<?php echo $x['url']; ?>" onmousedown="<?php echo $x['onmousedown']; ?>" target="_blank" rel="nofollow"><?php echo $x['jobtitle']; ?></a></h4>
        			<div class="jobs-meta">
        				<span class="jobs-author"><?php echo wptexturize($x['company']); ?></span><br>                        
        				<span class="jobs-date"> <?php echo date_i18n('j M', strtotime($x['date'])); ?> <span class="year"><?php echo date_i18n('Y', strtotime($x['date'])); ?></span> </span>                        
        			</div>
        		</div>
        
        		<div class="column col4">
        			<span class="jobs-place"> <?php echo $x['formattedLocation']; ?> </span><br>
        			<span><?php echo $x['country']; ?></span>
        		</div>
        
        		<div class="column col2">
					<span class="button job_type full-time"><a href="<?php echo $x['url']; ?>" onmousedown="<?php echo $x['onmousedown']; ?>" target="_blank" rel="nofollow"><?php _e('Readmore', 'colabsthemes'); ?></a></span>        		
				</div>

            </div>
			
			<?php
			
		endforeach;
	
	endif;
	
}
if (get_option('colabs_dynamic_search_results')=='true') add_action('colabsthemes_job_listing_loop_else', 'colabs_indeed_search_results');

