<?php
// sidebar top Listings overall widget
class CoLabs_Widget_Top_Listings_Overall extends WP_Widget {

    function CoLabs_Widget_Top_Listings_Overall() {
        $widget_ops = array( 'description' => __( 'Your sidebar top listings overall', 'colabsthemes') );
        $this->WP_Widget('top_listings_overall', __('ColorLabs - Popular listings Overall', 'colabsthemes'), $widget_ops);
    }

    function widget( $args, $instance ) {

        extract($args);
        
        $post_type = (isset($instance['post_type']) && $instance['post_type']) ? $instance['post_type'] : 'job_listing';
        
        if ($post_type=='job_listing') :
        	$title = apply_filters('widget_title', empty($instance['title']) ? __('Popular Jobs Overall', 'colabsthemes') : $instance['title']);
		else :
			$title = apply_filters('widget_title', empty($instance['title']) ? __('Popular Resumes Overall', 'colabsthemes') : $instance['title']);
		endif;
		
        echo $before_widget;
        if ( $title )
			echo $before_title . $title . $after_title;
        
        colabs_todays_overall_count_widget($post_type, 10);

        echo $after_widget;
    }

    function update($new_instance, $old_instance) {
        $instance['title'] = strip_tags(stripslashes($new_instance['title']));
        $instance['post_type'] = strip_tags(stripslashes($new_instance['post_type']));
        return $instance;
    }

    function form($instance) {
    
    $post_type = (isset($instance['post_type'])) ? $instance['post_type'] : 'job_listing';
    
?>
    <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'colabsthemes') ?></label>
    <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php if (isset ($instance['title'])) { echo esc_attr( $instance['title']);} ?>" /></p>
    
    <p><label for="<?php echo $this->get_field_id('taxonomy'); ?>"><?php _e('Post type:', 'colabsthemes') ?></label>
	<select class="widefat" id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type'); ?>">
		<option value="job_listing" <?php selected('job_listing', $post_type) ?>><?php _e('Job', 'colabsthemes') ?></option>
		<option value="resume" <?php selected('resume', $post_type) ?>><?php _e('Resume', 'colabsthemes') ?></option>
	</select>
	</p>
<?php
    }
}

register_widget('CoLabs_Widget_Top_Listings_Overall');
?>