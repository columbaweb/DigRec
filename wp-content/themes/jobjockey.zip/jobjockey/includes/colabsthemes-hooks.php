<?php

/**
 * Add and initiate the ColorLabs hooks
 *
 * @since 1.0.0
 * @uses add_action() calls to trigger the hooks.
 *
 * DO NOT UPDATE WITHOUT UPDATING ALL OTHER THEMES!
 * This is a shared file so changes need to be propagated to insure sync 
 */

// called before anything is loaded in the theme 
function colabsthemes_init() { 
	do_action('colabsthemes_init'); 
}

// called in the header.php before meta tags appear
function colabsthemes_meta() { 
	do_action('colabsthemes_meta'); 
}

// called in header.php after the opening body tag
function colabsthemes_before() { 
	do_action('colabsthemes_before'); 
}

// called in footer.php before the closing body tag
function colabsthemes_after() { 
	do_action('colabsthemes_after'); 
}

// called in header.php
function colabsthemes_before_header() { 
	do_action('colabsthemes_before_header'); 
}

// called in header.php
function colabsthemes_header() { 
	do_action('colabsthemes_header'); 
}

// called in header.php
function colabsthemes_after_header() { 
	do_action('colabsthemes_after_header'); 
}


/**
* Page action hooks
*
*/

// called in page.php before the loop executes
function colabsthemes_before_page_loop() { 
	do_action('colabsthemes_before_page_loop'); 
}

// called in page.php before the page post section
function colabsthemes_before_page() { 
	do_action('colabsthemes_before_page'); 
}

// called in page.php before the page post title tag
function colabsthemes_before_page_title() { 
	do_action('colabsthemes_before_page_title'); 
}

// called in page.php after the page post title tag
function colabsthemes_after_page_title() { 
	do_action('colabsthemes_after_page_title'); 
}

// called in page.php before the page post content
function colabsthemes_before_page_content() { 
	do_action('colabsthemes_before_page_content'); 
}

// called in page.php after the page post content
function colabsthemes_after_page_content() { 
	do_action('colabsthemes_after_page_content'); 
}

// called in page.php after the page post section
function colabsthemes_after_page() { 
	do_action('colabsthemes_after_page'); 
}

// called in page page.php after the loop endwhile
function colabsthemes_after_page_endwhile() { 
	do_action('colabsthemes_after_page_endwhile'); 
}

// called in page page.php after the loop else
function colabsthemes_page_loop_else() { 
	do_action('colabsthemes_page_loop_else'); 
}

// called in page page.php after the loop executes
function colabsthemes_after_page_loop() { 
	do_action('colabsthemes_after_page_loop'); 
}

// called in page comments-page.php before the comments list block
function colabsthemes_before_page_comments() { 
	do_action('colabsthemes_before_page_comments'); 
}

// called in page comments-page.php in the ol block
function colabsthemes_list_page_comments() { 
	do_action('colabsthemes_list_page_comments'); 
}

// called in comments-page.php after the single li comment
function colabsthemes_page_comment() { 
	do_action('colabsthemes_page_comment'); 
}

// called in page comments-page.php after the comments list block
function colabsthemes_after_page_comments() { 
	do_action('colabsthemes_after_page_comments'); 
}

// called in page comments.php before the pings list block
function colabsthemes_before_page_pings() { 
	do_action('colabsthemes_before_page_pings'); 
}

// called in page comments.php in the ol block
function colabsthemes_list_page_pings() { 
	do_action('colabsthemes_list_page_pings'); 
}

// called in page comments.php after the pings list block
function colabsthemes_after_page_pings() { 
	do_action('colabsthemes_after_page_pings'); 
}

// called in page comments-page.php before the comments respond block
function colabsthemes_before_page_respond() { 
	do_action('colabsthemes_before_page_respond'); 
}	

// called in page comments-page.php after the comments respond block
function colabsthemes_after_page_respond() { 
	do_action('colabsthemes_after_page_respond'); 
}

// called in page comments-page.php before the comments form block
function colabsthemes_before_page_comments_form() { 
	do_action('colabsthemes_before_page_comments_form'); 
}

// called in page comments-page.php to include the comments form block
function colabsthemes_page_comments_form() { 
	do_action('colabsthemes_page_comments_form'); 
}

// called in page comments-page.php after the comments form block
function colabsthemes_after_page_comments_form() { 
	do_action('colabsthemes_after_page_comments_form'); 
}



/**
* Blog action hooks
*
*/

// called in loop.php before the loop executes
function colabsthemes_before_blog_loop() { 
	do_action('colabsthemes_before_blog_loop'); 
}

// called in loop.php before the blog post section
function colabsthemes_before_blog_post() { 
	do_action('colabsthemes_before_blog_post'); 
}

// called in loop.php before the blog post title tag
function colabsthemes_before_blog_post_title() { 
	do_action('colabsthemes_before_blog_post_title'); 
}

// called in loop.php after the blog post title tag
function colabsthemes_after_blog_post_title() { 
	do_action('colabsthemes_after_blog_post_title'); 
}

// called in loop.php before the blog post content
function colabsthemes_before_blog_post_content() { 
	do_action('colabsthemes_before_blog_post_content'); 
}

// called in loop.php after the blog post content
function colabsthemes_after_blog_post_content() { 
	do_action('colabsthemes_after_blog_post_content'); 
}

// called in loop.php after the blog post section
function colabsthemes_after_blog_post() { 
	do_action('colabsthemes_after_blog_post'); 
}

// called in blog loop.php after the loop endwhile
function colabsthemes_after_blog_endwhile() { 
	do_action('colabsthemes_after_blog_endwhile'); 
}

// called in blog loop.php after the loop else
function colabsthemes_blog_loop_else() { 
	do_action('colabsthemes_blog_loop_else'); 
}

// called in blog loop.php after the loop executes
function colabsthemes_after_blog_loop() { 
	do_action('colabsthemes_after_blog_loop'); 
}

// called in blog comments-blog.php before the comments list block
function colabsthemes_before_blog_comments() { 
	do_action('colabsthemes_before_blog_comments'); 
}

// called in job comments.php in the ol block
function colabsthemes_list_blog_comments() { 
	do_action('colabsthemes_list_blog_comments'); 
}

// called in comments.php after the single li comment
function colabsthemes_blog_comment() { 
	do_action('colabsthemes_blog_comment'); 
}

// called in blog comments-blog.php after the comments list block
function colabsthemes_after_blog_comments() { 
	do_action('colabsthemes_after_blog_comments'); 
}

// called in blog comments.php before the pings list block
function colabsthemes_before_blog_pings() { 
	do_action('colabsthemes_before_blog_pings'); 
}

// called in blog comments.php in the ol block
function colabsthemes_list_blog_pings() { 
	do_action('colabsthemes_list_blog_pings'); 
}

// called in blog comments.php after the pings list block
function colabsthemes_after_blog_pings() { 
	do_action('colabsthemes_after_blog_pings'); 
}

// called in blog comments-blog.php before the comments respond block
function colabsthemes_before_blog_respond() { 
	do_action('colabsthemes_before_blog_respond'); 
}	

// called in blog comments-blog.php after the comments respond block
function colabsthemes_after_blog_respond() { 
	do_action('colabsthemes_after_blog_respond'); 
}

// called in blog comments-blog.php before the comments form block
function colabsthemes_before_blog_comments_form() { 
	do_action('colabsthemes_before_blog_comments_form'); 
}

// called in blog comments-blog.php to include the comments form block
function colabsthemes_blog_comments_form() { 
	do_action('colabsthemes_blog_comments_form'); 
}

// called in blog comments-blog.php after the comments form block
function colabsthemes_after_blog_comments_form() { 
	do_action('colabsthemes_after_blog_comments_form'); 
}




/**
* Custom post type action hooks
*
*/

// called in loop-[custom-post-type].php before the loop executes
function colabsthemes_before_loop( $type = '' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_before_' . $type . 'loop'); 
}

// called in loop-[custom-post-type].php before the blog post section
function colabsthemes_before_post( $type = 'post' ) { 
	do_action('colabsthemes_before_' . $type); 
}

// called in loop-[custom-post-type].php before the blog post title tag
function colabsthemes_before_post_title( $type = 'post' ) { 
	do_action('colabsthemes_before_'.$type.'_title'); 
}

// called in loop-[custom-post-type].php after the blog post title tag
function colabsthemes_after_post_title( $type = 'post' ) { 
	do_action('colabsthemes_after_'.$type.'_title'); 
}

// called in loop-[custom-post-type].php before the blog post content
function colabsthemes_before_post_content( $type = 'post' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_before_'.$type.'_content'); 
}

// called in loop-[custom-post-type].php after the blog post content
function colabsthemes_after_post_content( $type = 'post' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_after_'.$type.'_content'); 
}

// called in loop-[custom-post-type].php after the blog post section
function colabsthemes_after_post( $type = 'post' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_after_'.$type); 
}

// called in loop-[custom-post-type].php after the loop endwhile
function colabsthemes_after_endwhile( $type = '' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_after_' . $type . 'endwhile'); 
}

// called in loop-[custom-post-type].php after the loop else
function colabsthemes_loop_else( $type = '' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_' . $type . 'loop_else'); 
}

// called in loop-[custom-post-type].php after the loop executes
function colabsthemes_after_loop( $type = '' ) { 
	if ($type) $type .= '_';
	do_action('colabsthemes_after_' . $type . 'loop'); 
}





/**
* Comment action hooks
*
*/

// called in job comments.php before the comments list block
function colabsthemes_before_comments() { 
	do_action('colabsthemes_before_comments'); 
}

// called in job comments.php in the ol block
function colabsthemes_list_comments() { 
	do_action('colabsthemes_list_comments'); 
}

// called in comments.php after the single li comment
function colabsthemes_comment() { 
	do_action('colabsthemes_comment'); 
}

// called in job comments.php after the comments list block
function colabsthemes_after_comments() { 
	do_action('colabsthemes_after_comments'); 
}

// called in job comments.php before the pings list block
function colabsthemes_before_pings() { 
	do_action('colabsthemes_before_pings'); 
}

// called in job comments.php in the ol block
function colabsthemes_list_pings() { 
	do_action('colabsthemes_list_pings'); 
}

// called in job comments.php after the pings list block
function colabsthemes_after_pings() { 
	do_action('colabsthemes_after_pings'); 
}

// called in job comments.php before the comments respond block
function colabsthemes_before_respond() { 
	do_action('colabsthemes_before_respond'); 
}	

// called in job comments.php after the comments respond block
function colabsthemes_after_respond() { 
	do_action('colabsthemes_after_respond'); 
}

// called in job comments.php before the comments form block
function colabsthemes_before_comments_form() { 
	do_action('colabsthemes_before_comments_form'); 
}

// called in job comments.php to include the comments form block
function colabsthemes_comments_form() { 
	do_action('colabsthemes_comments_form'); 
}

// called in job comments.php after the comments form block
function colabsthemes_after_comments_form() { 
	do_action('colabsthemes_after_comments_form'); 
}




/**
* sidebar hooks
*
*/

// called in the sidebar template files before the widget section
function colabsthemes_before_sidebar_widgets() { 
	do_action('colabsthemes_before_sidebar_widgets'); 
}

// called in the sidebar template files after the widget section
function colabsthemes_after_sidebar_widgets() { 
	do_action('colabsthemes_after_sidebar_widgets'); 
}




/**
* footer hooks
*
*/

// called in the footer.php before the footer section
function colabsthemes_before_footer() { 
	do_action('colabsthemes_before_footer'); 
}

// called in footer.php 
function colabsthemes_footer() { 
	do_action('colabsthemes_footer'); 
}

// called in the footer.php after the footer section
function colabsthemes_after_footer() { 
	do_action('colabsthemes_after_footer'); 
	
}



/**
* admin hooks
*
*/


/**
* called in admin-options.php  to create a sub-menu page under theme menu
* @since 1.2
*/
function colabsthemes_add_submenu_page() { 
	do_action('colabsthemes_add_submenu_page'); 
}

/**
* called in admin-options.php  to create the sub-menu page content
* @since 1.2
*/
function colabsthemes_add_submenu_page_content() { 
	do_action('colabsthemes_add_submenu_page_content'); 
}
function colabs_order_gateway_redirect($description, $data) { 
	do_action('colabs_order_gateway_redirect', $description, $data);
}
function colabs_order_gateway_options(){
	do_action('colabs_order_gateway_options');
}