<?php

/**
 * Init User Roles
 */
function colabs_init_roles() {
	global $wp_roles;

	if (class_exists('WP_Roles')) 	
		if ( ! isset( $wp_roles ) )
			$wp_roles = new WP_Roles();	
	
	if (is_object($wp_roles)) :
		$wp_roles->add_cap( 'administrator', 'can_submit_job' );
		//$wp_roles->remove_cap( 'administrator', 'can_submit_resume' );
		$wp_roles->add_cap( 'editor', 'can_submit_job' );
		$wp_roles->add_cap( 'contributor', 'can_submit_job' );
		$wp_roles->add_cap( 'author', 'can_submit_job' );
	endif;
	
	//$wp_roles->remove_role('job_seeker');
	//$wp_roles->remove_role('job_lister');
	
	$wp_roles->add_role( 'job_seeker', 'Job Seeker', array(
	    'read' => true,
	    'edit_posts' => false,
	    'delete_posts' => false,
	    'can_submit_resume' => true
	));
	
	$wp_roles->add_role( 'job_lister', 'Job Lister', array(
	    'read' => true,
	    'edit_posts' => false,
	    'delete_posts' => false,
	    'can_submit_job' => true
	));
	
}

add_action('init', 'colabs_init_roles');

/**
 * Track User Job Views
 */
function colabs_viewed_jobs() {
	global $post;
	if( is_single() && is_user_logged_in() && get_post_type() == 'job_listing' ) :
		
		$_viewed_jobs = get_user_meta(get_current_user_id(), '_viewed_jobs', true);
		if (!is_array($_viewed_jobs)) $_viewed_jobs = array();
		
		if (!in_array($post->ID, $_viewed_jobs)) $_viewed_jobs[] = $post->ID;
		
		$_viewed_jobs = array_reverse($_viewed_jobs);
		$_viewed_jobs = array_slice($_viewed_jobs, 0, 5);
		$_viewed_jobs = array_reverse($_viewed_jobs);
		
		update_user_meta(get_current_user_id(), '_viewed_jobs', $_viewed_jobs);
	endif;
}

add_action('colabsthemes_before_post', 'colabs_viewed_jobs');

/**
 * Star Jobs
 */
function colabs_star_jobs() {
	global $post;
	if( isset($_GET['star']) && is_single() && is_user_logged_in() && get_post_type() == 'job_listing' ) :
		
		$_starred_jobs = get_user_meta(get_current_user_id(), '_starred_jobs', true);
		if (!is_array($_starred_jobs)) $_starred_jobs = array();
		
		if ($_GET['star']=='true') :
			if (!in_array($post->ID, $_starred_jobs)) : $_starred_jobs[] = $post->ID; endif;
		else :
			$_starred_jobs = array_diff($_starred_jobs, array($post->ID));
		endif;

		update_user_meta(get_current_user_id(), '_starred_jobs', $_starred_jobs);
	endif;
}

add_action('colabsthemes_before_post', 'colabs_star_jobs');


/**
 * Get job seeker prefs table
 */
function colabs_seeker_prefs( $user_id ) {
	
	$prefs = '<table cellspacing="0" class="user_prefs">';
	
	$availability_month 	= get_user_meta($user_id, 'availability_month', true);
	$availability_year 	= get_user_meta($user_id, 'availability_year', true);
	//$your_location			= get_user_meta($user_id, 'your_location', true);
	$career_status 			= get_user_meta($user_id, 'career_status', true);
	$willing_to_relocate 	= get_user_meta($user_id, 'willing_to_relocate', true);
	$willing_to_travel 		= get_user_meta($user_id, 'willing_to_travel', true);
	$where_you_can_work 	= get_user_meta($user_id, 'where_you_can_work', true);
	
	if ($career_status) :
		$prefs .= '<tr><th>' . __('Career Status:', 'colabsthemes') . '</th><td>';
		switch ($career_status) :
			case "looking" :
				$prefs .= __('Actively looking', 'colabsthemes');
			break;
			case "open" :
				$prefs .= __('Open to new opportunities', 'colabsthemes');
			break;
			case "notlooking" :
				$prefs .= __('Not actively looking', 'colabsthemes');
			break;
		endswitch;
		echo '</td></tr>';
	endif;
	
	//if ($your_location) $prefs .= '<tr><th>' . __('Location:', 'colabsthemes') . '</th><td>' . wptexturize($your_location) . '</td></tr>';
	
	if ($availability_month && $availability_year) :
		$prefs .= '<tr><th>' . __('Availability:', 'colabsthemes') . '</th><td>' .  date('F Y', mktime(0, 0, 0, $availability_month, 11, $availability_year)) . '</td></tr>';
	else :
		$prefs .= '<tr><th>' . __('Availability:', 'colabsthemes') . '</th><td>' .  __('Immediate', 'colabsthemes') . '</td></tr>';
	endif;
	
	if ($willing_to_relocate=='yes') $prefs .= '<tr><th>' . __('Willing to relocate:', 'colabsthemes') . '</th><td><img class="load" src="'.get_bloginfo('template_url').'/images/check.png" alt="yes" /></td></tr>';

	if ($willing_to_travel) :
		$prefs .= '<tr><th>' . __('Willingness to travel:', 'colabsthemes') . '</th><td>';
		switch ($willing_to_travel) :
			case "100" :
				$prefs .= __('Willing to travel', 'colabsthemes');
			break;
			case "75" :
				$prefs .= __('Fairly willing to travel', 'colabsthemes');
			break;
			case "50" :
				$prefs .= __('Not very willing to travel', 'colabsthemes');
			break;
			case "25" :
				$prefs .= __('Local opportunities only', 'colabsthemes');
			break;
			case "0" :
				$prefs .= __('Not willing to travel/working from home', 'colabsthemes');
			break;
		endswitch;
		$prefs .='</td></tr>';
	endif;
	
	$prefs .= '</table>';
	return $prefs;
}