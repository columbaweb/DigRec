<?php

/**
 * Reserved for any theme-specific hooks
 * For general ColorLabs hooks, see colabsthemes-hooks.php
 *
 * @since 1.0.0
 * @uses add_action() calls to trigger the hooks.
 *
 */


/**
 * called in template-submit.php before step one page content is displayed
 *
 * @since 1.0.0
 */
function colabs_before_step_one() { 
	do_action('colabs_before_step_one');
} 

/**
 * called in template-submit.php after step one page content is displayed
 *
 * @since 1.0.0
 */
function colabs_after_step_one() { 
	do_action('colabs_after_step_one');
} 

/**
 * called in template-submit.php before step two page content is displayed
 *
 * @since 1.0.0
 */
function colabs_before_step_two() { 
	do_action('colabs_before_step_two');
} 

/**
 * called in template-submit.php after step two page content is displayed
 *
 * @since 1.0.0
 */
function colabs_after_step_two() { 
	do_action('colabs_after_step_two');
} 

/**
 * called in template-submit.php before step three page content is displayed
 *
 * @since 1.0.0
 */
function colabs_before_step_three() { 
	do_action('colabs_before_step_three');
} 

/**
 * called in template-submit.php after step three page content is displayed
 *
 * @since 1.0.0
 */
function colabs_after_step_three() { 
	do_action('colabs_after_step_three');
}

/**
 * called in template-submit.php before step four page content is displayed
 *
 * @since 1.0.0
 */
function colabs_before_step_four() { 
	do_action('colabs_before_step_four');
} 

/**
 * called in template-submit.php after step four page content is displayed
 *
 * @since 1.0.0
 */
function colabs_after_step_four() { 
	do_action('colabs_after_step_four');
}

/**
 * called in template-add-new-submit.php after returning from payment gateway
 * but before the order is actually processed in the log db table
 * make sure to return $_POST['custom'] in your function 
 *
 * @since 1.0.0
 * @param array $_POST['custom'] Gateway return posted elements
 *@todo already included in files but need to test first. Not sure if will work since theme-actions.php isn't directly included
 */
// function colabs_before_gateway_process($_POST['custom']) { 
	// do_action('colabs_before_gateway_process', $_POST['custom']);
// }

/**
 * called in template-add-new-submit.php after returning from payment gateway
 * and after the order is actually processed in the log db table
 *
 * @since 1.0.0
 * @param array $_POST['custom'] Gateway return posted elements
 *@todo already included in files but need to test first. Not sure if will work since theme-actions.php isn't directly included
 */
// function colabs_after_gateway_process($newjobid) { 
	// do_action('colabs_after_gateway_process', $newjobid);
// }
 
 
/**
 * called before the new job is created
 * make sure to return $data in your function
 *
 * @since 1.0.0
 * @param array $data Post array before running wp_insert_post 
 */
function colabs_before_insert_job($data) { 
	do_action('colabs_before_insert_job', $data);
}

/**
 * called after the new job is created
 *
 * @since 1.0.0
 * @param string $post_id Passes in newly created job id
 */
function colabs_after_insert_job($post_id) { 
	do_action('colabs_after_insert_job', $post_id);
}

/**
 * called above a single resume
 *
 * @since 1.0.0
 */
function colabs_resume_header($post) { do_action('colabs_resume_header', $post); }

/**
 * called below a single resume
 *
 * @since 1.0.0
 */
function colabs_resume_footer($post) { do_action('colabs_resume_footer', $post); }

/**
 * called in template-job-seeker-dashboard.php before dashboard jobs
 *
 * @since 1.0.0
 */
function colabs_before_job_seeker_dashboard() { 
	do_action('colabs_before_job_seeker_dashboard');
} 

/**
 * called in template-job-seeker-dashboard.php after dashboard jobs
 *
 * @since 1.0.0
 */
function colabs_after_job_seeker_dashboard() { 
	do_action('colabs_after_job_seeker_dashboard');
} 

/**
 * called in sidebar-nav.php after filters
 *
 * @since 1.0.0
 */
function colabs_sidebar_nav_browseby() { 
	do_action('colabs_sidebar_nav_browseby');
} 

/**
 * called in sidebar-resume-nav.php after filters
 *
 * @since 1.0.0
 */
function colabs_sidebar_resume_nav_browseby() { 
	do_action('colabs_sidebar_resume_nav_browseby');
} 