<?php
/**
 * JobJockey Cron Jobs
 * This file contains the cron job for auto-expiring posts on a daily basis.
 *
 *
 * @version 1.0.0
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_schedule_expire_check(){
	wp_schedule_event(time(), 'hourly', 'colabs_check_jobs_expired');
}

if (get_option('colabs_check_jobs_expired')==true) colabs_schedule_expire_check();

add_action('colabs_check_jobs_expired', 'colabs_check_expired_cron');

function colabs_check_expired_cron() {
	global $wpdb;
	$action = get_option('colabs_expired_action');
	
	// Get list of expired posts that are published
	$postids = $wpdb->get_col($wpdb->prepare("
		SELECT      postmeta.post_id
		FROM        $wpdb->postmeta postmeta
		LEFT JOIN	$wpdb->posts posts ON postmeta.post_id = posts.ID
		WHERE       postmeta.meta_key = '_expires' 
		            AND postmeta.meta_value < '%s'
		            AND post_status = 'publish'
		            AND post_type = 'job_listing'
	", strtotime('NOW'))); 
	
	if ($action=='hide') :
		if ($postids) foreach ($postids as $id) { 		
			// Captains log supplemental, we have detected a job which is out of date
			// Activate Cloak
			$post = get_post($id);
			if ( empty($post) ) return;
			if ( 'private' == $post->post_status ) return;
			
			$old_status = $post->post_status;
			
			$job_post = array();
			$job_post['ID'] = $id;				
			$job_post['post_status'] = 'private';					
			wp_update_post( $job_post );

			$post->post_status = 'private';
			wp_transition_post_status('private', $old_status, $post);
			
			// Update counts for the post's terms.
			foreach ( (array) get_object_taxonomies('job_listing') as $taxonomy ) {	
				$tt_ids = wp_get_object_terms($id, 'job_cat', array('fields' => 'tt_ids'));
				wp_update_term_count($tt_ids, 'job_cat');
				$tt_ids = wp_get_object_terms($id, 'job_type', array('fields' => 'tt_ids'));
				wp_update_term_count($tt_ids, 'job_type');
			}
			
			do_action('edit_post', $id, $post);
			do_action('save_post', $id, $post);
			do_action('wp_insert_post', $id, $post);
		}
	endif;
	
	if (get_option('colabs_expired_job_email_owner')=='true') :
	
		$notify_ids = array();
		
		// Get list of expiring posts that are published
		$postids = $wpdb->get_col($wpdb->prepare("
			SELECT      DISTINCT postmeta.post_id
			FROM        $wpdb->postmeta postmeta
			LEFT JOIN	$wpdb->posts posts ON postmeta.post_id = posts.ID
			WHERE       postmeta.meta_key = '_expires' 
			            AND postmeta.meta_value > '%s'
			            AND postmeta.meta_value < '%s'
			            AND post_status = 'publish'
			            AND post_type = 'job_listing'
		", strtotime('NOW'), strtotime('NOW + 5 DAY'))); 
		
		if (sizeof($postids)>0) :
		
			// of those, get ids of posts that have already been notified
			$jobs_notified = $wpdb->get_col($wpdb->prepare("
				SELECT      postmeta.post_id
				FROM        $wpdb->postmeta postmeta
				WHERE       postmeta.meta_key = 'reminder_email_sent' 
				            AND postmeta.meta_value IN ('5','1')
			")); 
			//var_dump($postids);
			//var_dump($jobs_notified);
			//exit;
			// Now only send to those who need sending to
			$notify_ids = array_diff($postids, $jobs_notified);
			if ($notify_ids && sizeof($notify_ids)>0) foreach ($notify_ids as $id) {
				update_post_meta( $id, 'reminder_email_sent', '5' );
				colabs_owner_job_expiring_soon( $id, 5 );
			}
		endif;
		
		// Get list of expiring posts (1 day left) that are published
		$postids = $wpdb->get_col($wpdb->prepare("
			SELECT      postmeta.post_id
			FROM        $wpdb->postmeta postmeta
			LEFT JOIN	$wpdb->posts posts ON postmeta.post_id = posts.ID
			WHERE       postmeta.meta_key = '_expires' 
			            AND postmeta.meta_value > '%s'
			            AND postmeta.meta_value < '%s'
			            AND post_status = 'publish'
			            AND post_type = 'job_listing'
		", strtotime('NOW'), strtotime('NOW + 1 DAY'))); 
		
		if (sizeof($postids)>0) :
		
			// of those, get ids of posts that have already been notified
			$jobs_notified = $wpdb->get_col($wpdb->prepare("
				SELECT      postmeta.post_id
				FROM        $wpdb->postmeta postmeta
				WHERE       postmeta.meta_key = 'reminder_email_sent' 
				            AND postmeta.meta_value IN ('1')
			", implode(',', $postids) )); 
			
			// Now only send to those who need sending to
			$notify_ids_2 = array_diff($postids, $jobs_notified, $notify_ids);
			
			if ($notify_ids_2 && sizeof($notify_ids_2)>0) foreach ($notify_ids_2 as $id) {
				update_post_meta( $id, 'reminder_email_sent', '1' );
				colabs_owner_job_expiring_soon( $id, 1 );
			}
			
		endif;
	endif;
}