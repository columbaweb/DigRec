<?php
/**
 * Custom post types and taxonomies
 *
 */



// create the custom post type and category taxonomy for ad listings
// Define the custom post types
function colabs_post_type() {
	global $colabs_abbr;

		// get the slug value for the ad custom post type & taxonomies
		if(get_option($colabs_abbr.'_job_permalink')) $post_type_base_url = get_option($colabs_abbr.'_job_permalink'); else $post_type_base_url = 'jobs';
		if(get_option($colabs_abbr.'_job_cat_tax_permalink')) $cat_tax_base_url = get_option($colabs_abbr.'_job_cat_tax_permalink'); else $cat_tax_base_url = 'job-category';
	if(get_option($colabs_abbr.'_job_type_tax_permalink')) $type_tax_base_url = get_option($colabs_abbr.'_job_type_tax_permalink'); else $type_tax_base_url = 'job-type';
		if(get_option($colabs_abbr.'_job_tag_tax_permalink')) $tag_tax_base_url = get_option($colabs_abbr.'_job_tag_tax_permalink'); else $tag_tax_base_url = 'job-tag';
	if(get_option($colabs_abbr.'_job_salary_tax_permalink')) $sal_tax_base_url = get_option($colabs_abbr.'_job_salary_tax_permalink'); else $sal_tax_base_url = 'salary';	
	if(get_option($colabs_abbr.'_resume_permalink')) $resume_post_type_base_url = get_option($colabs_abbr.'_resume_permalink'); else $resume_post_type_base_url = 'resumes';

$post_type_base_url = 'jobs';$cat_tax_base_url = 'job-category';$type_tax_base_url = 'job-type';$tag_tax_base_url = 'job-tag';$sal_tax_base_url = 'salary';$resume_post_type_base_url = 'resumes';
		// create the custom post type and category taxonomy for job listings
		register_post_type( COLABS_POST_TYPE,
				array('labels' => array(
					'name' => __( 'Jobs', 'colabsthemes' ),
					'singular_name' => __( 'Jobs', 'colabsthemes' ),
					'add_new' => __( 'Add New', 'colabsthemes' ),
					'add_new_item' => __( 'Add New Job', 'colabsthemes' ),
					'edit' => __( 'Edit', 'colabsthemes' ),
					'edit_item' => __( 'Edit Job', 'colabsthemes' ),
					'new_item' => __( 'New Job', 'colabsthemes' ),
					'view' => __( 'View Jobs', 'colabsthemes' ),
					'view_item' => __( 'View Job', 'colabsthemes' ),
					'search_items' => __( 'Search Jobs', 'colabsthemes' ),
					'not_found' => __( 'No jobs found', 'colabsthemes' ),
					'not_found_in_trash' => __( 'No jobs found in trash', 'colabsthemes' ),
					'parent' => __( 'Parent Job', 'colabsthemes' ),
										),
										'description' => __( 'This is where you can create new job listings on your site.', 'colabsthemes' ),
										'public' => true,
										'show_ui' => true,
										'capability_type' => 'post',
										'publicly_queryable' => true,
										'exclude_from_search' => false,
										'menu_position' => 8,
										'menu_icon' => get_stylesheet_directory_uri() . '/images/icon/job_icon.png',
										'hierarchical' => false,
										'rewrite' => array( 'slug' => $post_type_base_url, 'with_front' => false ), /* Slug set so that permalinks work when just showing post name */
										'query_var' => true,
										'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky' ),
						)
		);

		// register the new job category taxonomy
		register_taxonomy( COLABS_TAX_CAT,
						array( COLABS_POST_TYPE ),
						array('hierarchical' => true,                    
										'labels' => array(
														'name' => __( 'Job Categories', 'colabsthemes'),
														'singular_name' => __( 'Job Category', 'colabsthemes'),
														'search_items' =>  __( 'Search Job Categories', 'colabsthemes'),
														'all_items' => __( 'All Job Categories', 'colabsthemes'),
														'parent_item' => __( 'Parent Job Category', 'colabsthemes'),
														'parent_item_colon' => __( 'Parent Job Category:', 'colabsthemes'),
														'edit_item' => __( 'Edit Job Category', 'colabsthemes'),
														'update_item' => __( 'Update Job Category', 'colabsthemes'),
														'add_new_item' => __( 'Add New Job Category', 'colabsthemes'),
														'new_item_name' => __( 'New Job Category Name', 'colabsthemes')
										),
										'show_ui' => true,
										'query_var' => true,
					'update_count_callback' => '_update_post_term_count',
										'rewrite' => array( 'slug' => $cat_tax_base_url, 'hierarchical' => true ),
						)
		);

		// register the new job type taxonomy
		register_taxonomy( COLABS_TAX_TYPE,
						array( COLABS_POST_TYPE ),
						array('hierarchical' => true,
										'labels' => array(
														'name' => __( 'Job Types', 'colabsthemes'),
														'singular_name' => __( 'Job Type', 'colabsthemes'),
														'search_items' =>  __( 'Search Job Types', 'colabsthemes'),
														'all_items' => __( 'All Job Types', 'colabsthemes'),
														'parent_item' => __( 'Parent Job Type', 'colabsthemes'),
														'parent_item_colon' => __( 'Parent Job Type:', 'colabsthemes'),
														'edit_item' => __( 'Edit Job Type', 'colabsthemes'),
														'update_item' => __( 'Update Job Type', 'colabsthemes'),
														'add_new_item' => __( 'Add New Job Type', 'colabsthemes'),
														'new_item_name' => __( 'New Job Type Name', 'colabsthemes')
										),
										'show_ui' => true,
										'query_var' => true,
					'update_count_callback' => '_update_post_term_count',
										'rewrite' => array( 'slug' => $type_tax_base_url, 'hierarchical' => true ),
						)
		);

		// register the new job tag taxonomy
		register_taxonomy( COLABS_TAX_TAG,
						array( COLABS_POST_TYPE ),
						array('hierarchical' => false,
										'labels' => array(
														'name' => __( 'Job Tags', 'colabsthemes'),
														'singular_name' => __( 'Job Tag', 'colabsthemes'),
														'search_items' =>  __( 'Search Job Tags', 'colabsthemes'),
														'all_items' => __( 'All Job Tags', 'colabsthemes'),
														'parent_item' => __( 'Parent Job Tag', 'colabsthemes'),
														'parent_item_colon' => __( 'Parent Job Tag:', 'colabsthemes'),
														'edit_item' => __( 'Edit Job Tag', 'colabsthemes'),
														'update_item' => __( 'Update Job Tag', 'colabsthemes'),
														'add_new_item' => __( 'Add New Job Tag', 'colabsthemes'),
														'new_item_name' => __( 'New Job Tag Name', 'colabsthemes')
										),
										'show_ui' => true,
										'query_var' => true,
										'rewrite' => array( 'slug' => $tag_tax_base_url ),
										'update_count_callback' => '_update_post_term_count'
						)
		);

		// register the salary taxonomy
		register_taxonomy( COLABS_TAX_SALARY,
						array( COLABS_POST_TYPE ),
						array('hierarchical' => true,
										'labels' => array(
														'name' => __( 'Salary', 'colabsthemes'),
														'singular_name' => __( 'Salary', 'colabsthemes'),
														'search_items' =>  __( 'Search Salaries', 'colabsthemes'),
														'all_items' => __( 'All Salaries', 'colabsthemes'),
														'parent_item' => __( 'Parent Salary', 'colabsthemes'),
														'parent_item_colon' => __( 'Parent Salary:', 'colabsthemes'),
														'edit_item' => __( 'Edit Salary', 'colabsthemes'),
														'update_item' => __( 'Update Salary', 'colabsthemes'),
														'add_new_item' => __( 'Add New Salary', 'colabsthemes'),
														'new_item_name' => __( 'New Salary', 'colabsthemes')
										),
										'show_ui' => true,
										'query_var' => true,
										'rewrite' => array( 'slug' => $sal_tax_base_url ),
						)
		);
		
		if (get_option('colabs_allow_job_seekers')=='true') $show_ui = true; else $show_ui = false;
		
		register_post_type( COLABS_POST_TYPE_RESUME,
				array('labels' => array(
					'name' => __( 'Resumes', 'colabsthemes' ),
					'singular_name' => __( 'Resume', 'colabsthemes' ),
					'add_new' => __( 'Add New', 'colabsthemes' ),
					'add_new_item' => __( 'Add New Resume', 'colabsthemes' ),
					'edit' => __( 'Edit', 'colabsthemes' ),
					'edit_item' => __( 'Edit Resume', 'colabsthemes' ),
					'new_item' => __( 'New Resume', 'colabsthemes' ),
					'view' => __( 'View Resumes', 'colabsthemes' ),
					'view_item' => __( 'View Resume', 'colabsthemes' ),
					'search_items' => __( 'Search Resumes', 'colabsthemes' ),
					'not_found' => __( 'No Resumes found', 'colabsthemes' ),
					'not_found_in_trash' => __( 'No Resumes found in trash', 'colabsthemes' ),
					'parent' => __( 'Parent Resume', 'colabsthemes' ),
								),
								'description' => __( 'Resumes are created and edited by job_seekers.', 'colabsthemes' ),
								'public' => true,
								'show_ui' => $show_ui,
								'capability_type' => 'post',
								'publicly_queryable' => true,
								'exclude_from_search' => false,
								'menu_position' => 8,
								'menu_icon' => get_stylesheet_directory_uri() . '/images/icon/resume_icon.png',
								'hierarchical' => false,
								'rewrite' => array( 'slug' => $resume_post_type_base_url, 'with_front' => false ), /* Slug set so that permalinks work when just showing post name */
								'query_var' => true,
								'has_archive' => $resume_post_type_base_url,
								'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'custom-fields' ),
						)
		);
		register_taxonomy( COLABS_TAX_RESUME_SPECIALITIES,
				array( COLABS_POST_TYPE_RESUME ),
				array('hierarchical' => false,                    
								'labels' => array(
												'name' => __( 'Resume Specialities', 'colabsthemes'),
												'singular_name' => __( 'Resume Speciality', 'colabsthemes'),
												'search_items' =>  __( 'Search Resume Specialities', 'colabsthemes'),
												'all_items' => __( 'All Resume Specialities', 'colabsthemes'),
												'parent_item' => __( 'Parent Resume Speciality', 'colabsthemes'),
												'parent_item_colon' => __( 'Parent Resume Speciality:', 'colabsthemes'),
												'edit_item' => __( 'Edit Resume Speciality', 'colabsthemes'),
												'update_item' => __( 'Update Resume Speciality', 'colabsthemes'),
												'add_new_item' => __( 'Add New Resume Speciality', 'colabsthemes'),
												'new_item_name' => __( 'New Resume Speciality Name', 'colabsthemes')
								),
								'show_ui' => $show_ui,
								'rewrite' => array( 'slug' => 'resume/speciality', 'with_front' => false ),
								'query_var' => true,
								 'update_count_callback' => '_update_post_term_count'
				)
	);
	register_taxonomy( COLABS_TAX_RESUME_GROUPS,
				array( COLABS_POST_TYPE_RESUME ),
				array('hierarchical' => false,                    
								'labels' => array(
												'name' => __( 'Groups/Associations', 'colabsthemes'),
												'singular_name' => __( 'Resume Group/Association', 'colabsthemes'),
												'search_items' =>  __( 'Search Groups/Associations', 'colabsthemes'),
												'all_items' => __( 'All Groups/Associations', 'colabsthemes'),
												'parent_item' => __( 'Parent Group/Association', 'colabsthemes'),
												'parent_item_colon' => __( 'Parent Group/Association:', 'colabsthemes'),
												'edit_item' => __( 'Edit Group/Association', 'colabsthemes'),
												'update_item' => __( 'Update Group/Association', 'colabsthemes'),
												'add_new_item' => __( 'Add New Group/Association', 'colabsthemes'),
												'new_item_name' => __( 'New Group/Association Name', 'colabsthemes')
								),
								'show_ui' => $show_ui,
								'query_var' => true,
								'rewrite' => array( 'slug' => 'resume/group', 'with_front' => false ),
								 'update_count_callback' => '_update_post_term_count'
				)
	);
	register_taxonomy( COLABS_TAX_RESUME_LANGUAGES,
				array( COLABS_POST_TYPE_RESUME ),
				array('hierarchical' => false,                    
								'labels' => array(
												'name' => __( 'Spoken Languages', 'colabsthemes'),
												'singular_name' => __( 'Spoken Langauge', 'colabsthemes'),
												'search_items' =>  __( 'Search Spoken Languages', 'colabsthemes'),
												'all_items' => __( 'All Spoken Languages', 'colabsthemes'),
												'parent_item' => __( 'Parent Spoken Language', 'colabsthemes'),
												'parent_item_colon' => __( 'Parent Spoken Language:', 'colabsthemes'),
												'edit_item' => __( 'Edit Spoken Language', 'colabsthemes'),
												'update_item' => __( 'Update Spoken Language', 'colabsthemes'),
												'add_new_item' => __( 'Add New Spoken Language', 'colabsthemes'),
												'new_item_name' => __( 'New Spoken Language Name', 'colabsthemes')
								),
								'show_ui' => $show_ui,
								'query_var' => true,
								'rewrite' => array( 'slug' => 'resume/language', 'with_front' => false ),
								 'update_count_callback' => '_update_post_term_count'
				)
	);
	register_taxonomy( COLABS_TAX_RESUME_CATEGORY,
				array( COLABS_POST_TYPE_RESUME ),
				array('hierarchical' => true,                    
								'labels' => array(
												'name' => __( 'Resume Categories', 'colabsthemes'),
												'singular_name' => __( 'Resume Category', 'colabsthemes'),
												'search_items' =>  __( 'Search Resume Categories', 'colabsthemes'),
												'all_items' => __( 'All Resume Categories', 'colabsthemes'),
												'parent_item' => __( 'Parent Resume Category', 'colabsthemes'),
												'parent_item_colon' => __( 'Parent Resume Category:', 'colabsthemes'),
												'edit_item' => __( 'Edit Resume Category', 'colabsthemes'),
												'update_item' => __( 'Update Resume Category', 'colabsthemes'),
												'add_new_item' => __( 'Add New Resume Category', 'colabsthemes'),
												'new_item_name' => __( 'New Resume Category Name', 'colabsthemes')
								),
								'show_ui' => $show_ui,
								'query_var' => true,
								'rewrite' => array( 'slug' => 'resume/category', 'with_front' => false ), 
								'update_count_callback' => '_update_post_term_count'
				)
	);
	register_taxonomy( COLABS_TAX_RESUME_JOB_TYPE,
				array( COLABS_POST_TYPE_RESUME ),
				array('hierarchical' => false,                    
								'labels' => array(
												'name' => __( 'Resume Job Types', 'colabsthemes'),
												'singular_name' => __( 'Resume Job Type', 'colabsthemes'),
												'search_items' =>  __( 'Search Resume Job Types', 'colabsthemes'),
												'all_items' => __( 'All Resume Job Types', 'colabsthemes'),
												'parent_item' => __( 'Parent Resume Job Type', 'colabsthemes'),
												'parent_item_colon' => __( 'Parent Resume Job Type:', 'colabsthemes'),
												'edit_item' => __( 'Edit Resume Job Type', 'colabsthemes'),
												'update_item' => __( 'Update Resume Job Type', 'colabsthemes'),
												'add_new_item' => __( 'Add New Resume Job Type', 'colabsthemes'),
												'new_item_name' => __( 'New Resume Job Type Name', 'colabsthemes')
								),
								'show_ui' => $show_ui,
								'rewrite' => array( 'slug' => 'resume/job-type', 'with_front' => false ),
								'query_var' => true,
								 'update_count_callback' => '_update_post_term_count'
				)
	);

}

add_action( 'init', 'colabs_post_type', 0 );


function colabs_edit_columns($columns){
	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => __('Job Name', 'colabsthemes'),
		'author' => __('Job Author', 'colabsthemes'),
		'job_cat' => __('Job Category', 'colabsthemes'),
		'job_type' => __('Job Type', 'colabsthemes'),
		'job_salary' => __('Salary', 'colabsthemes'),
		'company' => __('Company', 'colabsthemes'),
		'location' => __('Location', 'colabsthemes'),
		'date' => __('Date', 'colabsthemes'),
	);
	return $columns;
}
add_filter('manage_edit-job_listing_columns', 'colabs_edit_columns');

function colabs_custom_columns($column){
	global $post;
	$custom = get_post_custom();
	switch ($column) {
		case 'company':
			if ( isset($custom['_Company'][0]) && !empty($custom['_Company'][0]) ) :
				if ( isset($custom['_CompanyURL'][0]) && !empty($custom['_CompanyURL'][0]) ) echo '<a href="'.$custom['_CompanyURL'][0].'">'.$custom['_Company'][0].'</a>';
				else echo $custom['_Company'][0];
			endif;
		break;
		case 'location':
			if ( isset($custom['geo_address'][0]) && !empty($custom['geo_address'][0]) ) :
				echo $custom['geo_address'][0];
			else :
				_e('Anywhere', 'colabsthemes');
			endif;
		break;
		case COLABS_TAX_TYPE :
			echo get_the_term_list($post->ID, COLABS_TAX_TYPE, '', ', ','');
		break;
		case COLABS_TAX_SALARY :
			echo get_the_term_list($post->ID, COLABS_TAX_SALARY, '', ', ','');
		break;
		case COLABS_TAX_CAT :
			echo get_the_term_list($post->ID, COLABS_TAX_CAT, '', ', ','');
		break;
	}
}
add_action('manage_posts_custom_column',  'colabs_custom_columns');

// add a logo column to the edit jobs screen
function colabs_job_logo_column($cols) {
		$cols['logo'] = __('Logo', 'colabsthemes');
		return $cols;
}
add_filter('manage_edit-'.COLABS_POST_TYPE.'_columns', 'colabs_job_logo_column');


// add a thumbnail column to the edit posts screen
function colabs_post_thumbnail_column($cols) {
		$cols['thumbnail'] = __('Thumbnail', 'colabsthemes');
		return $cols;
}
add_filter('manage_posts_columns', 'colabs_post_thumbnail_column');


// go get the attached images for the logo and thumbnail columns
function colabs_thumbnail_value($column_name, $post_id) {

		if (('thumbnail' == $column_name) || ('logo' == $column_name)) {
		
		$thumbnail = colabs_image('id='.$post_id.'&return=true&height=50&size=sidebar-thumbnail');
		
				if ( $thumbnail ) echo $thumbnail;

		}
}
add_action('manage_posts_custom_column', 'colabs_thumbnail_value', 10, 2);





// add a drop-down post type selector to the edit post/ads admin pages
function colabs_post_type_changer() {
		global $post;

		// disallow things like attachments, revisions, etc
		$safe_filter = array('public' => true, 'show_ui' => true);

		// allow this to be filtered
		$args = apply_filters('colabs_post_type_changer', $safe_filter);

		// get the post types
		$post_types = get_post_types((array)$args);

		// get the post_type values
		$cur_post_type_object = get_post_type_object($post->post_type);
		
		$cur_post_type = $cur_post_type_object->name;

		// make sure the logged in user has perms
		$can_publish = current_user_can($cur_post_type_object->cap->publish_posts);
?>

<?php if ( $can_publish ) : ?>

<div class="misc-pub-section misc-pub-section-last post-type-switcher">

	<label for="pts_post_type"><?php _e('Post Type:', 'colabsthemes'); ?></label>

	<span id="post-type-display"><?php echo $cur_post_type_object->label; ?></span>

	<a href="#pts_post_type" class="edit-post-type hide-if-no-js"><?php _e('Edit', 'colabsthemes'); ?></a>
	<div id="post-type-select" class="hide-if-js">

		<select name="pts_post_type" id="pts_post_type">
						<?php foreach ( $post_types as $post_type ) {
			$pt = get_post_type_object( $post_type );

			if ( current_user_can( $pt->cap->publish_posts ) ) : ?>

				<option value="<?php echo $pt->name; ?>"<?php if ( $cur_post_type == $post_type ) : ?>selected="selected"<?php endif; ?>><?php echo $pt->label; ?></option>

			<?php
			endif;
		}
						?>
		</select>

		<input type="hidden" name="hidden_post_type" id="hidden_post_type" value="<?php echo $cur_post_type; ?>" />

		<a href="#pts_post_type" class="save-post-type hide-if-no-js button"><?php _e('OK', 'colabsthemes'); ?></a>
		<a href="#pts_post_type" class="cancel-post-type hide-if-no-js"><?php _e('Cancel', 'colabsthemes'); ?></a>
	</div>	
	
</div>

<?php
	endif;
}

// add this option to the edit post submit box
add_action('post_submitbox_misc_actions', 'colabs_post_type_changer');



// jquery and css for the post type changer
function colabs_post_type_changer_head() {
?>

<script type='text/javascript'>
		jQuery(document).ready(function(){
				jQuery('#post-type-select').siblings('a.edit-post-type').click(function() {
						if (jQuery('#post-type-select').is(":hidden")) {
								jQuery('#post-type-select').slideDown("normal");
								jQuery(this).hide();
						}
						return false;
				});

				jQuery('.save-post-type', '#post-type-select').click(function() {
						jQuery('#post-type-select').slideUp("normal");
						jQuery('#post-type-select').siblings('a.edit-post-type').show();
						pts_updateText();
						return false;
				});

				jQuery('.cancel-post-type', '#post-type-select').click(function() {
						jQuery('#post-type-select').slideUp("normal");
						jQuery('#pts_post_type').val(jQuery('#hidden_post_type').val());
						jQuery('#post-type-select').siblings('a.edit-post-type').show();
						pts_updateText();
						return false;
				});

				function pts_updateText() {
						jQuery('#post-type-display').html( jQuery('#pts_post_type :selected').text() );
						jQuery('#hidden_post_type').val(jQuery('#pts_post_type').val());
						jQuery('#post_type').val(jQuery('#pts_post_type').val());
						return true;
				}
		});
</script>

<style type="text/css">
		#post-type-select { line-height: 2.5em; margin-top: 3px; }
		#post-type-display { font-weight: bold; }
		div.post-type-switcher { border-top: 1px solid #eee; }
</style>

<?php
}

// activate this function to load in the admin head
add_action('admin_head', 'colabs_post_type_changer_head');


// custom user page columns
function colabs_manage_users_columns( $columns ) {
		$columns['colabs_jobs_count'] = __('Jobs', 'colabsthemes');
	$columns['colabs_resumes_count'] = __('Resumes', 'colabsthemes');
	$columns['last_login'] = __('Last Login', 'colabsthemes');
	$columns['registered'] = __('Registered', 'colabsthemes');
		return $columns;
}
add_action('manage_users_columns', 'colabs_manage_users_columns');


// display the coumn values for each user
function colabs_manage_users_custom_column( $r, $column_name, $user_id ) {

	// count the total jobs for the user
	if ( 'colabs_jobs_count' == $column_name ) {
		global $jobs_counts;

		if ( !isset( $jobs_counts ) )
			$jobs_counts = colabs_count_custom_post_types( COLABS_POST_TYPE );

		if ( !array_key_exists( $user_id, $jobs_counts ) )
			$jobs_counts = colabs_count_custom_post_types( COLABS_POST_TYPE );

		if ( $jobs_counts[$user_id] > 0 ) {
			$r .= "<a href='edit.php?post_type=" . COLABS_POST_TYPE . "&author=$user_id' title='" . esc_attr__( 'View jobs by this author', 'colabsthemes' ) . "' class='edit'>";
			$r .= $jobs_counts[$user_id];
			$r .= '</a>';
		} else {
			$r .= 0;
		}
	}
	
	// count the total resumes for the user
	if ( 'colabs_resumes_count' == $column_name ) {
		global $resumes_counts;

		if ( !isset( $resumes_counts ) )
			$resumes_counts = colabs_count_custom_post_types( COLABS_POST_TYPE_RESUME );

		if ( !array_key_exists( $user_id, $resumes_counts ) )
			$resumes_counts = colabs_count_custom_post_types( COLABS_POST_TYPE_RESUME );

		if ( $resumes_counts[$user_id] > 0 ) {
			$r .= "<a href='edit.php?post_type=" . COLABS_POST_TYPE_RESUME . "&author=$user_id' title='" . esc_attr__( 'View resumes by this author', 'colabsthemes' ) . "' class='edit'>";
			$r .= $resumes_counts[$user_id];
			$r .= '</a>';
		} else {
			$r .= 0;
		}
	}
	
	// get the user last login date
	if ('last_login' == $column_name)
		$r = get_user_meta($user_id, 'last_login', true);
	
	// get the user registration date	
	if ('registered' == $column_name) {
		$user_info = get_userdata($user_id);
		$r = $user_info->user_registered;
		//$r = colabsthemes_get_reg_date($reg_date);
	}

	return $r;
}
//Display the custom column data for each user
add_action( 'manage_users_custom_column', 'colabs_manage_users_custom_column', 10, 3 );


// count the number of job listings & resumes for the user
function colabs_count_custom_post_types( $post_type ) {
	global $wpdb, $wp_list_table;

	$users = array_keys( $wp_list_table->items );
	$userlist = implode( ',', $users );
	$result = $wpdb->get_results( "SELECT post_author, COUNT(*) FROM $wpdb->posts WHERE post_type = '$post_type' AND post_author IN ($userlist) GROUP BY post_author", ARRAY_N );
	foreach ( $result as $row ) {
		$count[ $row[0] ] = $row[1];
	}

	foreach ( $users as $id ) {
		if ( ! isset( $count[ $id ] ) )
			$count[ $id ] = 0;
	}

	return $count;
}

/**
 * Functions used for taxonomies in admin 
 *
 * These functions control admin interface bits like category ordering.
 *
 */

/**
 * Taxonomy Colorpicker
 */
add_action('job_type_add_form_fields', 'colabs_add_colorpicker', 10, 1);
add_action('job_type_edit_form_fields', 'colabs_edit_colorpicker', 10, 1);

function job_type_scripts() {
		global $wp_version;
		if (version_compare($wp_version, '3.4.0', '<')) {
				wp_enqueue_style( 'colabs-admin-colorpicker', get_template_directory_uri() . '/functions/css/colorpicker.css' );
				wp_enqueue_script( 'colabs-admin-colorpicker-js', get_template_directory_uri() . '/functions/js/colorpicker.js' );
		}else{
				wp_enqueue_script('wp-color-picker');
				wp_enqueue_style('wp-color-picker');
		}
}
add_action( 'admin_print_scripts-edit-tags.php', 'job_type_scripts' );

function colabs_add_colorpicker($tag){
		global $wp_version;

		$t_id = $tag->term_id;
		$term_meta = get_option( "job_type_$t_id");
?>
		<div class="form-field">
		<script type="text/javascript">
		jQuery(document).ready(function(){
			//Color Picker for older WordPress
			if( typeof jQuery.fn.ColorPicker !== 'undefined' ) {
				jQuery( '#job_type_col_picker').children( 'div').css( 'backgroundColor', '<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>' );    
				jQuery( '#job_type_col_picker').ColorPicker({
					color: '<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>',
					onShow: function (colpkr) {
						jQuery(colpkr).fadeIn(500);
						return false;
					},
					onHide: function (colpkr) {
						jQuery(colpkr).fadeOut(500);
						return false;
					},
					onChange: function (hsb, hex, rgb) {
						jQuery( '#job_type_col_picker').children( 'div').css( 'backgroundColor', '#' + hex);
						jQuery( '#job_type_col_picker').next( 'input').attr( 'value','#' + hex);
					}
				});
			}

			// ColorPicker for latest WordPress version
			else {
				jQuery( '[name="term_meta[color]"]').wpColorPicker({
				});
			}
		});
		</script>
				<label for="term_meta[color]"><?php _e('Color','colabsthemes'); ?></label>
				<div id="job_type_col_picker" class="colorSelector"><div></div></div>
		<input class="colabs-color" name="term_meta[color]" id="term_meta[color]" type="text" value="<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>" style="margin-left: 5px; width: 100px;" maxlength="7"/>
		</div>
<?php
}


function colabs_edit_colorpicker( $tag ) {
		//check for existing taxonomy meta for term ID
		$t_id = $tag->term_id;
		$term_meta = get_option( "job_type_$t_id");
		var_dump($term_meta);
?>
		<script type="text/javascript" language="javascript">
		jQuery(document).ready(function(){
			//Color Picker for older WordPress
			if( typeof jQuery.fn.ColorPicker !== 'undefined' ) {
				jQuery( '#job_type_col_picker').children( 'div').css( 'backgroundColor', '<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>' );    
				jQuery( '#job_type_col_picker').ColorPicker({
					color: '<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>',
					onShow: function (colpkr) {
						jQuery(colpkr).fadeIn(500);
						return false;
					},
					onHide: function (colpkr) {
						jQuery(colpkr).fadeOut(500);
						return false;
					},
					onChange: function (hsb, hex, rgb) {
						jQuery( '#job_type_col_picker').children( 'div').css( 'backgroundColor', '#' + hex);
						jQuery( '#job_type_col_picker').next( 'input').attr( 'value','#' + hex);
					}
				});
			}

			// ColorPicker for latest WordPress version
			else {
				jQuery( '[name="term_meta[color]"]').wpColorPicker({
				});
			}
		});
		</script>
	<tr class="form-field">
		<th scope="row" valign="top"><label><?php _e('Color', 'colabsthemes'); ?></label></th>
		<td>
						<div id="job_type_col_picker" class="colorSelector"><div></div></div>
						<input class="colabs-color" name="term_meta[color]" id="term_meta[color]" type="text" value="<?php echo $term_meta['color'] ? $term_meta['color'] : ''; ?>" maxlength="7" style="max-width: 100px;" />
						<br />
				</td>
		</tr><!--/.form-field-->
<?php
}

add_action('created_job_type', 'colabs_add_colorpicker_save', 10,1);
add_action('edited_job_type', 'colabs_add_colorpicker_save', 10,1);

function colabs_add_colorpicker_save( $term_id ) {
		if ( isset( $_POST['term_meta'] ) ) {
				$t_id = $term_id;
				$term_meta = get_option( "job_type_$t_id");
				$cat_keys = array_keys($_POST['term_meta']);
						foreach ($cat_keys as $key){
						if (isset($_POST['term_meta'][$key])){
								$term_meta[$key] = $_POST['term_meta'][$key];
						}
				}
				//save the option array
				update_option( "job_type_$t_id", $term_meta );
		}
}

function colabs_test(){

$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'job_type' ) );  


//so term ID
$t_ID = $term->term_id;

$term_data = get_option("job_type_$t_ID");
		
		$return = '';
		$return .= '<p>Test colabs_test()</p>';
		
if (isset($term_data['color'])){
		$return .= '<div class="term_image"><img src="'.$term_data['color'].'"></div>';
}
		return $return;
		
}
?>