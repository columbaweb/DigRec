<?php
/**
 * JobJockey Registration Form
 * Function outputs the registration form
 *
 */

function colabs_register_form( $action = '', $role = '' ) {
	
    global $posted;

    if ( get_option('users_can_register') ) :

        if (!$action) $action = site_url('wp-login.php?action=register');
    ?>

            <h5><?php _e('Create a free account', 'colabsthemes'); ?></h5>

            <form action="<?php echo $action; ?>" method="post" class="account_form">
				
				<?php 
					if ( get_option('colabs_allow_job_seekers') == 'true' ) :
						if (!$role) :
							?>
							<p class="role">
								<label><input type="radio" name="role" value="job_lister" <?php if (isset($posted['role']) && $posted['role']=='job_lister') echo 'checked="checked"'; elseif (!isset($posted['role'])) echo 'checked="checked"'; ?> /> <?php _e('I am an <strong>Employer</strong>', 'colabsthemes'); ?></label>
								<label class="alt"><input type="radio" name="role" value="job_seeker" <?php if (isset($posted['role']) && $posted['role']=='job_seeker') echo 'checked="checked"'; ?> /> <?php _e('I am a <strong>Job Seeker</strong>', 'colabsthemes'); ?></label>
							</p>
							<?php
						elseif ($role=='job_lister') :
							echo '<div><input type="hidden" name="role" value="job_lister" /></div>';
						elseif ($role=='job_seeker') :
							echo '<div><input type="hidden" name="role" value="job_seeker" /></div>';
						endif;
					endif;
				?>
				
                <p>
                    <input type="text" class="text placeholder" tabindex="1" name="your_username" id="your_username" placeholder="<?php _e('Username', 'colabsthemes'); ?>" rel="<?php _e('Username', 'colabsthemes'); ?>" value="<?php if (isset($posted['your_username'])) echo $posted['your_username']; ?>" />
                </p>

                <p>
                    <input type="text" class="text placeholder" tabindex="2" name="your_email" id="your_email" placeholder="<?php _e('Email', 'colabsthemes'); ?>" rel="<?php _e('Email', 'colabsthemes'); ?>" value="<?php if (isset($posted['your_email'])) echo $posted['your_email']; ?>" />
                </p>
				
				<?php if (get_option('colabs_allow_registration_password')=='true') : ?>
                <p>
                    <input type="password" class="text placeholder" tabindex="3" name="your_password" id="your_password" placeholder="<?php _e('Enter a password', 'colabsthemes'); ?>" rel="<?php _e('Enter a password', 'colabsthemes'); ?>" value="" />
                </p>

                <p>
                    <input type="password" class="text placeholder" tabindex="4" name="your_password_2" id="your_password_2" placeholder="<?php _e('Enter password again', 'colabsthemes'); ?>" rel="<?php _e('Enter password again', 'colabsthemes'); ?>" value="" />
                </p>
                <?php endif; ?>       
                
                <?php
                // include the spam checker if enabled
                colabsthemes_recaptcha();
                ?>
                
				<?php if (get_option('colabs_terms_page_id')>0) : ?><p>
					<input type="checkbox" name="terms" tabindex="6" value="yes" id="terms" <?php if (isset($_POST['terms'])) echo 'checked="checked"'; ?> /> <label for="terms"><?php _e('I accept the ', 'colabsthemes'); ?><a href="<?php echo get_permalink(get_option('colabs_terms_page_id')); ?>" target="_blank"><?php _e('terms &amp; conditions', 'colabsthemes'); ?></a>.</label>
				</p><?php endif; ?>
				
                <p>
                    <input type="submit" class="submit" tabindex="7" name="register" value="<?php _e('Register', 'colabsthemes'); ?>" />
                </p>

                <!-- autofocus the field -->
                <script type="text/javascript">try{document.getElementById('your_username').focus();}catch(e){}</script>

            </form>
<?php else : ?>
    <p><?php _e('Registration is disabled on this site','colabsthemes'); ?></p>
<?php endif; ?>

<?php } ?>