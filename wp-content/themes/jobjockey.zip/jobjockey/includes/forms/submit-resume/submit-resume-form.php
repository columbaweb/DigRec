<?php
/**
 * JobJockey Resume form
 * Function outputs the resume submit form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_submit_resume_form( $resume_id = 0 ) {
	
	global $post, $posted;
	
	colabs_geolocation_scripts();

	?>
	<form action="<?php 
		if ($resume_id>0) echo add_query_arg('edit', $resume_id, get_permalink( $post->ID )); 
		else echo get_permalink( $post->ID ); 
	?>" method="post" enctype="multipart/form-data" id="submit_form" class="submit_form main_form">
		
		<p><?php _e('Enter your resume details below. Once saved you will be able to view your resume and optionally add links to your websites/social networks if you wish.', 'colabsthemes'); ?></p>
		
		<fieldset>
			<legend><?php _e('Your Resume', 'colabsthemes'); ?></legend>
			
			<p><label for="resume_name"><?php _e('Resume Title', 'colabsthemes'); ?> <span title="required">*</span></label> <input type="text" class="text placeholder" name="resume_name" id="resume_name" placeholder="<?php _e('e.g. Lead Developer', 'colabsthemes'); ?>" rel="<?php _e('e.g. Lead Developer', 'colabsthemes'); ?>" value="<?php if (isset($posted['resume_name'])) echo $posted['resume_name']; ?>" /></p>
			
			<p><label for="summary"><?php _e('Resume Summary', 'colabsthemes'); ?> <span title="required">*</span></label> <textarea rows="5" cols="30" name="summary" id="summary" placeholder="<?php _e('Briefly describe yourself.', 'colabsthemes'); ?>" rel="<?php _e('Briefly describe yourself.', 'colabsthemes'); ?>" class="short placeholder" style="height:100px;"><?php if (isset($posted['summary'])) echo $posted['summary']; ?></textarea></p>
			
			<p class="optional"><label for="resume_cat"><?php _e('Resume Category', 'colabsthemes'); ?></label> <?php
				$sel = 0;
				if (isset($posted['resume_cat']) && $posted['resume_cat']>0) $sel = $posted['resume_cat']; 
				global $featured_job_cat_id;
				$args = array(
				    'orderby'            => 'name', 
				    'order'              => 'ASC',
				    'name'               => 'resume_cat',
				    'hierarchical'       => 1, 
				    'echo'				 => 0,
				    'class'              => 'resume_cat',
				    'selected'			 => $sel,
				    'taxonomy'			 => 'resume_category',
				    'hide_empty'		 => false
				);
				$dropdown = wp_dropdown_categories( $args );
				$dropdown = str_replace('class=\'resume_cat\' >','class=\'resume_cat\' ><option value="">'.__('Select a category&hellip;', 'colabsthemes').'</option>',$dropdown);
				echo $dropdown;
			?></p>	
			
			<p class="optional"><label for="your-photo"><?php _e('Resume Photo (.jpg, .gif or .png)', 'colabsthemes'); ?></label> <input type="file" class="text" name="your-photo" id="your-photo" /></p>
			
			<?php if(get_option('colabs_form_audio')=='true'){ ?>
			<p class="optional"><label for="your-audio"><?php _e('Resume Audio (.mp3, .m4a, .ogg or .wav)', 'colabsthemes'); ?></label> <input type="file" class="text" name="your-audio" id="your-audio" /></p>
			<?php } ?>			

			<?php if(get_option('colabs_form_video')=='true'){ ?>
			<p class="optional"><label for="your-video"><?php _e('Resume Video (.mp4, .m4v, .mov, .wmv, .avi, .mpg, .ogv, .3gp or .3g2)', 'colabsthemes'); ?></label> <input type="file" class="text" name="your-video" id="your-video" /></p>
			<?php } ?>
			
			<p class="optional"><label for="desired_salary"><?php _e('Desired Salary', 'colabsthemes'); ?></label> <input type="text" class="tags text placeholder" name="desired_salary" id="desired_salary" placeholder="<?php _e('e.g. $25,000', 'colabsthemes'); ?>" rel="<?php _e('e.g. $25,000', 'colabsthemes'); ?>" value="<?php if (isset($posted['desired_salary'])) echo $posted['desired_salary']; ?>" /></p>
			
			<p class="optional"><label for="desired_position"><?php _e('Desired Type of Position', 'colabsthemes'); ?></label> <select name="desired_position" id="desired_position">
				<option value=""><?php _e('Any', 'colabsthemes'); ?></option>
				<?php
				$job_types = get_terms( 'resume_job_type', array( 'hide_empty' => '0' ) );
				if ($job_types && sizeof($job_types) > 0) {
					foreach ($job_types as $type) {
						?>
						<option <?php if (isset($posted['desired_position']) && $posted['desired_position']==$type->slug) echo 'selected="selected"'; ?> value="<?php echo $type->slug; ?>"><?php echo $type->name; ?></option>
						<?php
					}
				}
				?>
			</select></p>
			
			<p class="optional"><label for="post_status"><?php _e('Resume Status', 'colabsthemes'); ?></label> 
			<select name="post_status" id="post_status">
				<option value="publish"><?php _e('Public', 'colabsthemes'); ?></option>
				<option value="private"><?php _e('Private', 'colabsthemes'); ?></option>
			</select>
			</p>
			
		</fieldset>	

		<fieldset>
			<legend><?php _e('Your Contact Details', 'colabsthemes'); ?></legend>
			
			<p><?php _e('Optionally fill in your contact details below to have them appear on your resume. This is important if you want employers to be able to contact you!', 'colabsthemes'); ?></p>
			
			<p class="optional"><label for="email_address"><?php _e('Email Address', 'colabsthemes'); ?></label> <input type="text" class="text placeholder" name="email_address" value="<?php if (isset($posted['email_address'])) echo $posted['email_address']; ?>" id="email_address" placeholder="<?php _e('you@yourdomain.com', 'colabsthemes'); ?>" rel="<?php _e('you@yourdomain.com', 'colabsthemes'); ?>" /></p>
			<p class="optional"><label for="tel"><?php _e('Telephone', 'colabsthemes'); ?></label> <input type="text" class="text placeholder" name="tel" value="<?php if (isset($posted['tel'])) echo $posted['tel']; ?>" id="tel" placeholder="<?php _e('Telephone including area code', 'colabsthemes'); ?>" rel="<?php _e('Telephone including area code', 'colabsthemes'); ?>" /></p>
			<p class="optional"><label for="mobile"><?php _e('Mobile', 'colabsthemes'); ?></label> <input type="text" class="text placeholder" name="mobile" value="<?php if (isset($posted['mobile'])) echo $posted['mobile']; ?>" id="mobile" placeholder="<?php _e('Mobile number', 'colabsthemes'); ?>" rel="<?php _e('Mobile number', 'colabsthemes'); ?>" /></p>
			
		</fieldset>	
		
		<fieldset>
			<legend><?php _e('Resume Location', 'colabsthemes'); ?></legend>								
			<p><?php _e('Entering your location will help employers find you.', 'colabsthemes'); ?></p>	
			<div id="geolocation_box">
			
				<p><label><input id="geolocation-load" type="button" class="button geolocationadd" value="<?php _e('Find Address/Location', 'colabsthemes'); ?>" /></label> <input type="text" class="text" name="colabs_address" id="geolocation-address" value="<?php if (isset($posted['colabs_address'])) echo $posted['colabs_address']; ?>" /><input type="hidden" class="text" name="colabs_geo_latitude" id="geolocation-latitude" value="<?php if (isset($posted['colabs_geo_latitude'])) echo $posted['colabs_geo_latitude']; ?>" /><input type="hidden" class="text" name="colabs_geo_longitude" id="geolocation-longitude" value="<?php if (isset($posted['colabs_geo_longitude'])) echo $posted['colabs_geo_longitude']; ?>" /></p>
	
				<div id="map_wrap" style="border:solid 2px #ddd;"><div id="geolocation-map" style="width:100%;height:300px;"></div></div>
			
			</div>
			
		</fieldset>	

		<fieldset>
			<legend><?php _e('Education', 'colabsthemes'); ?></legend>
			<p><?php _e('Detail your education, including details on your qualifications and schools/universities attended.', 'colabsthemes'); ?></p>
			<p><textarea rows="5" cols="30" name="education" id="education" class="mceEditor"><?php if (isset($posted['education'])) echo $posted['education']; ?></textarea></p>
		</fieldset>
		<fieldset>
			<legend><?php _e('Experience', 'colabsthemes'); ?></legend>
			<p><?php _e('Detail your work experience, including details on your employers and job roles and responsibilities.', 'colabsthemes'); ?></p>
			<p><textarea rows="5" cols="30" name="experience" id="experience" class="mceEditor"><?php if (isset($posted['experience'])) echo $posted['experience']; ?></textarea></p>
		</fieldset>	
		
		<fieldset>
			<legend><?php _e('Skills &amp; Specialities', 'colabsthemes'); ?></legend>

			<p class="optional"><label for="skills"><?php _e('Skills <small>(one per line)</small>', 'colabsthemes'); ?></label> <textarea rows="7" cols="30" name="skills" id="skills" class="short grow placeholder" placeholder="<?php _e('e.g. XHTML (5 years experience)', 'colabsthemes'); ?>" rel="<?php _e('e.g. XHTML (5 years experience)', 'colabsthemes'); ?>"><?php if (isset($posted['skills'])) echo $posted['skills']; ?></textarea></p>
			
			<p class="optional"><label for="specialities"><?php _e('Specialities <small>e.g. Public speaking, Team management</small>', 'colabsthemes'); ?></label> <input type="text" class="tags text tag-input-commas placeholder" data-separator="," name="specialities" id="specialities" placeholder="<?php _e('e.g. Public Speaking, Team Management', 'colabsthemes'); ?>" rel="<?php _e('e.g. Public Speaking, Team Management', 'colabsthemes'); ?>" value="<?php if (isset($posted['specialities'])) echo $posted['specialities']; ?>" /></p>
			
			<p class="optional"><label for="groups"><?php _e('Groups/Associations <small>e.g. IEEE, W3C</small>', 'colabsthemes'); ?></label> <input type="text" class="text text tag-input-commas placeholder" data-separator="," name="groups" value="<?php if (isset($posted['groups'])) echo $posted['groups']; ?>" id="groups" placeholder="<?php _e('e.g. IEEE, W3C', 'colabsthemes'); ?>" rel="<?php _e('e.g. IEEE, W3C', 'colabsthemes'); ?>" /></p>
			
			<p class="optional" id="languages_wrap"><label for="languages"><?php _e('Spoken Languages <small>e.g. English, French</small>', 'colabsthemes'); ?></label> <input type="text" class="text text tag-input-commas placeholder" data-separator="," name="languages" value="<?php if (isset($posted['languages'])) echo $posted['languages']; ?>" id="languages" placeholder="<?php _e('e.g. English, French', 'colabsthemes'); ?>" rel="<?php _e('e.g. English, French', 'colabsthemes'); ?>" /></p>
			
		</fieldset>
		
		<p><input type="submit" class="submit" name="save_resume" value="<?php _e('Save &rarr;', 'colabsthemes'); ?>" /></p>
			
		<div class="clear"></div>
			
	</form>
	<script type="text/javascript">
		
		jQuery(function(){
		
			/* Auto Complete */
			var availableTags = [
				<?php
					$terms_array = array();
					$terms = get_terms( 'resume_languages', 'hide_empty=0' );
					if ($terms) foreach ($terms as $term) {
						$terms_array[] = '"'.$term->name.'"';
					}
					echo implode(',', $terms_array);
				?>
			];
			function split( val ) {
				return val.split( /,\s*/ );
			}
			function extractLast( term ) {
				return split( term ).pop();
			}
			if( typeof jQuery.fn.autocomplete !== 'undefined' ) {
				jQuery("#languages_wrap input").live( "keydown", function( event ) {
					if ( (event.keyCode === jQuery.ui.keyCode.TAB || event.keyCode === jQuery.ui.keyCode.COMMA) &&
							jQuery( this ).data( "autocomplete" ).menu.active ) {
						event.preventDefault();
					}
				}).autocomplete({
				    minLength: 0,
					source: function( request, response ) {
						// delegate back to autocomplete, but extract the last term
						response( jQuery.ui.autocomplete.filter(
							availableTags, extractLast( request.term ) ) );
					},
				    focus: function() {
				    	jQuery('input.ui-autocomplete-input').val('');
						// prevent value inserted on focus
						return false;
					},
					select: function( event, ui ) {

						var terms = split( this.value );
						// remove the current input
						terms.pop();
						// add the selected item
						terms.push( ui.item.value );
						// add placeholder to get the comma-and-space at the end
						terms.push( "" );
						//this.value = terms.join( ", " );
						this.value = terms.join( "" );
						
						jQuery(this).blur();
						jQuery(this).focus();
						
						return false;
					}
				});
			};
		
		});
	</script>
	<?php
	if (get_option('colabs_html_allowed') == 'true')
	    colabs_tinymce();
	?>
	<?php
}