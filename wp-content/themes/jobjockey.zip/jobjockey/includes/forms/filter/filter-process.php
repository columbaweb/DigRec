<?php
/**
 * JobJockey Application Process
 * Processes a job application sent via the form in a post.
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_process_filter_form() {
	
	global $wp_query, $featured_job_cat_id, $find_posts_in, $search_result_ids; 
	
	if ( get_query_var('paged') ) {
		$paged = get_query_var('paged');
	} elseif ( get_query_var('page') ) {
		$paged = get_query_var('page');
	} else {
		$paged = 1;
	}
	
	$args = array(
		'post_type'	=> 'job_listing',
		'post_status' => 'publish',
		'paged' => $paged
	);
	
	$jobs_type = array();
	$filter_args = array();
	
	if (isset($_GET['action']) && $_GET['action']=='Filter' && (  (isset($_GET['s']) && $_GET['s']!='') || (isset($_GET['location']) && $_GET['location']!='') || (isset($_GET['jobs-filter']) && $_GET['jobs-filter']!='')  )) {

		$job_types = get_terms( 'job_type', array( 'hide_empty' => '0' ) );
		if ( $job_types && 
				 sizeof( $job_types ) > 0 && 
				 isset( $_GET['jobs-filter'] ) &&
				 is_array( $_GET['jobs-filter'] ) 
			 ) {
			foreach ($job_types as $type) {
				if( in_array( $type->slug, $_GET['jobs-filter'] ) ) {
					$jobs_type[] = $type->slug;
				}
			}
		} else {
			$jobs_type = array(0);
		}
	
		// If we are doing location search, find common ids
		// if (isset($find_posts_in) && is_array($find_posts_in)) $post_ids = array_intersect($post_ids, $find_posts_in);
		// if (isset($search_result_ids) && is_array($search_result_ids)) $post_ids = array_intersect($post_ids, $search_result_ids);
		
		$terms_filter = array(
			'tax_query' => array (
				array(
					'taxonomy' => 'job_type',
					'field' => 'slug',
					'terms' => $jobs_type
				)
			)
		);
		$args = array_merge($terms_filter, $args);

		
	} elseif (isset($find_posts_in) && is_array($find_posts_in)) {
		if (isset($search_result_ids) && is_array($search_result_ids)) $find_posts_in = array_intersect($find_posts_in, $search_result_ids);
		
		$find_posts_in[] = 0;
		
		$filter_args = array(
			'post__in'	=> $find_posts_in
		);		
		$args = array_merge($filter_args, $args);
	} elseif (isset($search_result_ids) && is_array($search_result_ids)) {
		$filter_args = array(
			'post__in'	=> $search_result_ids
		);		
		$args = array_merge($filter_args, $args);
	}
	
	
	return $args;

}