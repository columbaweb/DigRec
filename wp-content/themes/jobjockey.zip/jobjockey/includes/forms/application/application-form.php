<?php
/**
 * JobJockey Application form
 * Function outputs the job application form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_application_form() {
	
	global $post, $colabs_form_results;
	
	$errors = $colabs_form_results['errors'];
	$posted = $colabs_form_results['posted'];
	if ( is_user_logged_in() ){
	
		global $user_ID;
		$user_info = get_userdata($user_ID);
		$user_name = $user_info->display_name;
		$user_email = $user_info->user_email;
		
		// Only show this form when user is a job seeker
		if( $user_info->roles[0] !== 'job_seeker' ) {
			return;
		}

	}else{
	
		if (isset($posted['your_name'])) $user_name= $posted['your_name'];
		if (isset($posted['your_email'])) $user_email= $posted['your_email'];
		
	}
	?>
	<hr />
	<div id="apply_form" class="job-apply-form section_content <?php echo $colabs_form_results['class']; ?>">
		<h2><?php _e('Apply for this Job', 'colabsthemes'); ?></h2>
		<?php colabs_show_errors( $errors, 'apply_form_result' ); ?>

		<form action="<?php echo get_permalink($post->ID); ?>#apply_form_result" method="post" class="main_form" enctype="multipart/form-data">
			
			<p><input type="text" class="text placeholder" name="your_name" id="your_name" placeholder="<?php _e('Name', 'colabsthemes'); ?>" rel="<?php _e('Name', 'colabsthemes'); ?>" value="<?php echo $user_name ?>" title="<?php _e('required', 'colabsthemes'); ?>" /> </p>
			<p><input type="text" class="text placeholder" name="your_email" id="your_email" placeholder="<?php _e('Email', 'colabsthemes'); ?>" rel="<?php _e('Email', 'colabsthemes'); ?>" value="<?php echo $user_email; ?>" title="<?php _e('required', 'colabsthemes'); ?>" /></p>
			<p><textarea class="placeholder" rows="5" cols="30" name="your_message" id="your_message" placeholder="<?php _e('Message', 'colabsthemes'); ?>" rel="<?php _e('Message', 'colabsthemes'); ?>" title="<?php _e('required', 'colabsthemes'); ?>" ><?php if (isset($posted['your_message'])) echo $posted['your_message']; ?></textarea></p>
			<p class="optional"><input type="file" class="text" name="your_cv" id="your_cv" /><label for="your_cv"><?php _e('Upload resum&eacute; (zip, pdf, doc, txt, rtf)', 'colabsthemes'); ?></label></p>
			<p class="optional"><input type="file" class="text" name="your_coverletter" id="your_coverletter" /><label for="your_coverletter"><?php _e('Upload cover letter (zip, pdf, doc, txt, rtf)', 'colabsthemes'); ?></label></p>
			
            <?php if ( is_user_logged_in() ){ ?>
            <p>
			<select id="your_resume" name="your_resume">
			<?php 
            global $user_ID;
			$wp_query = new WP_Query( array(
				'author' => $user_ID,
				'post_type' => 'resume'
			));

			while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
				<option value="<?php echo get_permalink($post->ID); ?>"><?php the_title(); ?></option>
			<?php endwhile; wp_reset_postdata(); ?>

			</select>
			<label for="your_coverletter"><?php _e('Select your resume', 'colabsthemes'); ?></label>
			</p>
            <?php } ?>
            
			<p><label for="antispam_answer" title="<?php _e('This is to prevent spam', 'colabsthemes'); ?>" ><?php echo get_option('colabs_antispam_question'); ?> <span title="required">*</span></label> <input type="text" class="text small placeholder" name="antispam_answer" id="antispam_answer" value="<?php if (isset($posted['antispam_answer'])) echo $posted['antispam_answer']; ?>" placeholder="<?php _e('This is to prevent spam', 'colabsthemes'); ?>" rel="<?php _e('This is to prevent spam', 'colabsthemes'); ?>" /></p>
			
			<p><input type="submit" class="submit" name="apply_to_job" value="<?php _e('Apply for Job', 'colabsthemes'); ?>" /></p>
			
		</form>
	</div>
	
	<?php

}