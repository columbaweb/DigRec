<?php
/**
 * JobJockey Forgot Password Form
 * Function outputs the forgotten password form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_forgot_password_form() {
	?>
    <p><?php _e('Please enter your username or email address. A new password will be emailed to you.', 'colabsthemes') ?></p>
    <form action="<?php echo site_url('wp-login.php?action=lostpassword', 'login_post') ?>" method="post" class="login-form main_form">

        <p><input type="text" class="text placeholder" name="user_login" id="login_username" rel="<?php _e('Username/Email', 'colabsthemes'); ?>" placeholder="<?php _e('Username/Email', 'colabsthemes'); ?>" /></p>

        <p><?php do_action('lostpassword_form'); ?><input type="submit" class="submit" name="login" value="<?php _e('Get New Password','colabsthemes'); ?>" /></p>

    </form>
	<?php
}