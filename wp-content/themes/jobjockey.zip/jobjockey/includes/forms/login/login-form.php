<?php
/**
 * JobJockey Login Form
 * Function outputs the login form
 *
 */

function colabs_login_form( $action = '', $redirect = '' ) {

	global $posted;
	
	if (!$action) $action = site_url('wp-login.php');
	if (!$redirect) $redirect = get_permalink(get_option('colabs_dashboard_page_id'));
	?>

	<h5><?php _e('Login', 'colabsthemes'); ?></h5>

	<form action="<?php echo $action; ?>" method="post" class="account_form">
		
            <p>
                <input type="text" class="text placeholder" name="log" id="login_username" placeholder="<?php _e('Username', 'colabsthemes'); ?>" rel="<?php _e('Username', 'colabsthemes'); ?>" value="<?php if (isset($posted['login_username'])) echo $posted['login_username']; ?>" />
            </p>

            <p>
                <input type="password" class="text placeholder" name="pwd" id="login_password" placeholder="<?php _e('Password', 'colabsthemes'); ?>" rel="<?php _e('Password', 'colabsthemes'); ?>" value="" />
            </p>

            <p>
                <input type="hidden" name="redirect_to" value="<?php echo $redirect; ?>" />
                <input type="hidden" name="rememberme" value="forever" />
                <input type="submit" class="submit" name="login" value="<?php _e('Login', 'colabsthemes'); ?>" />
                <a class="lostpass" href="<?php echo site_url('wp-login.php?action=lostpassword', 'login') ?>" title="<?php _e('Forgot Password?', 'colabsthemes'); ?>"><?php _e('Forgot Password?', 'colabsthemes'); ?></a>
            </p>

	</form>

<?php
}
?>