<?php
add_action('colabs_lister_dashboard_process', 'colabs_process_lister_packs_form');

function colabs_process_lister_packs_form() {
	global $user_ID;

	if  ( !empty($_POST['buy_job_pack']) && !empty($_POST['job_pack']) ) :
	 	
		$job_pack_id = stripslashes(trim($_POST['job_pack']));
		
		$job_pack = new colabs_pack( $job_pack_id );
		$cost = $job_pack->pack_cost;
		
		if ($cost > 0):
			
			$colabs_order = new colabs_order( 0, $user_ID, $cost, 0, $job_pack_id );
			
			$colabs_order = apply_filters('colabs_order', $colabs_order);


			$colabs_order->insert_order();


			$order_description .= __('Job Pack ', 'colabsthemes'). $job_pack->pack_name;

			// Apply filter to the Order description
			$order_description = apply_filters('colabs_order_description', $order_description);

			### Redirect to payment page
			if('banktransfer' != $_POST['job_pack']):
				// Redirect user to a payment gateway
				colabs_order_gateway_redirect( $order_description, $colabs_order );
				exit;
			endif;

		else:

			### FREE LISTING / LISTING PAID WITH USER PACK (no additional cost)
			if (!empty($job_pack)):
				// Add free pack to user's account
				$result = $job_pack->give_to_user( $user_ID, $jobs_count=0 );
			endif;

			$args = array( 'give_pack_success' => $result );
			redirect_myjobs($args);

		endif;

	endif;
}
?>