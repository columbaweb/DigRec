<?php
/**
 * JobJockey Share form
 * Function outputs the share form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2010 all rights reserved
 *
 */

function colabs_share_form() {
	
	global $post;
	
	if(function_exists('selfserv_shareaholic')) : ?>
		<div id="share_form" class="section_content">
			<?php selfserv_shareaholic(); ?>
			<div class="clear"></div>
		</div>
	<?php endif;

}