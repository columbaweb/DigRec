<?php
/**
 * JobJockey Confirm Job form
 * Function outputs the job confirmation form
 *
 *
 * @version 1.0.0
 * @author ColorLabs
 * @package JobJockey
 * @copyright 2011 all rights reserved
 *
 */

function colabs_confirm_job_form() {
	
	global $post, $posted, $wpdb;
	
	$cost = 0;
	$payment_required = false;
	
	// Get Pack from previous step
	if (isset($_POST['job_pack']) && !empty($_POST['job_pack'])) : 
		$posted['job_pack'] = stripslashes(trim($_POST['job_pack']));
		if (strstr($posted['job_pack'], 'user_')) :
			// This is a user's pack and has already been purchased
		else :
			// Get pack price
			$cost += $wpdb->get_var("SELECT pack_cost FROM ".$wpdb->prefix."colabs_job_packs WHERE id = ".$wpdb->escape($posted['job_pack'])." LIMIT 1;");
		endif;
	else :
		// No Packs
		$posted['job_pack'] = '';
		$listing_cost = get_option('colabs_jobs_listing_cost');
		$cost += $listing_cost;
	endif;
	
	// Get Featured from previous step
	if (isset($_POST['featureit']) && $_POST['featureit']) :
		$posted['featureit'] = 'true';
		$featured_cost = get_option('colabs_cost_to_feature');
		$cost += $featured_cost;
	else :
		$posted['featureit'] = '';
	endif;
	
	if ($cost > 0) :
		$payment_required = true;
	endif;
	?>
	<form action="<?php echo get_permalink( $post->ID ); ?>" method="post" enctype="multipart/form-data" id="submit_form" class="submit_form main_form">			
		<p><?php _e('Your job is ready to be submitted, check the details are correct and then click &ldquo;confirm&rdquo; to submit your listing', 'colabsthemes'); ?><?php 
			if (get_option('colabs_jobs_require_moderation')=='true') _e(' for approval', 'colabsthemes');
		?>.</p>
		
		<blockquote>
			<h2><?php 
				echo wptexturize($posted['job_term_type']).' &ndash; '; 
				echo wptexturize($posted['job_title']); 
			?></h2>
			<?php if ($posted['your_name']) : ?>
			<h3><?php _e('Company/Poster','colabsthemes'); ?></h3>
			<p><?php
				if ($posted['website'])
					echo '<a href="'.$posted['website'].'">';
				echo $posted['your_name'];
				if ($posted['website'])
					echo '</a>';
			?></p>
			<?php endif; ?>
			<h3><?php _e('Job description','colabsthemes'); ?></h3>
			<?php echo wpautop(wptexturize($posted['details'])); ?>
			<?php if (get_option('colabs_submit_how_to_apply_display')=='true') : ?>
				<h3><?php _e('How to apply','colabsthemes'); ?></h3>
				<?php echo wpautop(wptexturize($posted['apply'])); ?>
			<?php endif; ?>
		</blockquote>
		
		<?php
		if ($payment_required) :
			?>
			<p><?php 
				_e('After confirming your submission you will be taken to the payment page and charged ', 'colabsthemes');
				echo '<strong>'.colabs_get_currency($cost).'</strong>';
				_e(' &mdash; as soon as your payment clears your listing will become active.','colabsthemes'); ?></p>
			<?php
		endif;	
		?>
        
        <?php 
        //Check if user choose to buy a new job pack
        if( strpos($posted['job_pack'],'user') !== false && $posted['featureit'] == '' ): else:
        //Check if there is listing cost or there is pack
        $packs = colabs_get_job_packs();
        if ( get_option('colabs_jobs_listing_cost') > 0 || sizeof($packs)>0 ) : ?>
        <blockquote class="payment_methods">
        <h3><?php _e('Payment Method','colabsthemes'); ?></h3>
		<div class="payment-method-wrap">
            
            <p>
            <select name="payment_type" class="colabs_payment_method dropdownlist required">
                <option value="paypal"><?php echo _e('PayPal', 'colabsthemes') ?></option>
                <?php if( get_option('colabs_bank_transfer') == 'true' ){ ?><option value="banktransfer"><?php echo _e('Bank Transfer', 'colabsthemes') ?></option><?php } ?>
            </select>
            </p>
            
            <?php if( get_option('colabs_bank_transfer_desc') != '' ){ ?>
			<div class="formbank">
                <p><span style="font-size: 13px; line-height: 19px;">
                <?php echo get_option('colabs_bank_transfer_desc'); ?>
                </span></p>
			</div>
			
			<script type="text/javascript">
				jQuery(document).ready(function($){

					if( $('.colabs_payment_method option[value="banktransfer"]:selected').length > 0 ) {
						$('.formbank').show();
					} else {
						$('.formbank').hide();
					}
					
					$('.colabs_payment_method').change(function(){
						var $el = $(this);
							value = $el.val();
						if( value == "banktransfer" ) {
							$('.formbank').show();
						} else {
							$('.formbank').hide();
						}
					});
				});
			</script>
            <?php } ?>
		</div>
        </blockquote>
		<?php endif; endif;?>
        
		<p>
            <input type="submit" name="goback" class="goback" value="<?php _e('Go Back','colabsthemes') ?>"  />
            <input type="submit" class="submit" name="confirm" value="<?php _e('Confirm &amp; Submit', 'colabsthemes'); ?>" />
            <input type="hidden" value="<?php echo base64_encode(serialize($posted)); ?>" name="posted" />
        </p>
		
		<div class="clear"></div>
	</form>	
	<?php

}