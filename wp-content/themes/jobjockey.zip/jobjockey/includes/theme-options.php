<?php

//Enable CoLabsSEO on these custom Post types
//$seo_post_types = array('post','page');
//define("SEOPOSTTYPES", serialize($seo_post_types));

//Global options setup
add_action('init','colabs_global_options');
function colabs_global_options(){
	// Populate CoLabsThemes option in array for use in theme
	global $colabs_options;
	$colabs_options = get_option('colabs_options');
}

add_action('admin_head','colabs_options');  
if (!function_exists('colabs_options')) {
function colabs_options(){
	
// VARIABLES
$themename = "JobJockey";
$manualurl = 'http://colorlabsproject.com';
$shortname = "colabs";

$theme_data = get_theme_data( get_template_directory() . '/style.css' );
$version = $theme_data['Version'];  

global $colabs_version; $colabs_version = $version;

//Access the WordPress Categories via an Array
$colabs_categories = array();  
$colabs_categories_obj = get_categories('hide_empty=0');
foreach ($colabs_categories_obj as $colabs_cat) {
    $colabs_categories[$colabs_cat->cat_ID] = $colabs_cat->cat_name;}
//$categories_tmp = array_unshift($colabs_categories, "Select a category:");

//Access the WordPress Pages via an Array
$colabs_pages = array();
$colabs_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($colabs_pages_obj as $colabs_page) {
    $colabs_pages[$colabs_page->ID] = $colabs_page->post_title; }
//$colabs_pages_tmp = array_unshift($colabs_pages, "Select a page:");       

//Access the WordPress Categories via an Array
$colabs_taxonomy='job_cat';
    
$colabs_job_cats = array();  
$colabs_job_cats_obj = get_categories('taxonomy='.$colabs_taxonomy.'&hide_empty=0');
foreach ($colabs_job_cats_obj as $colabs_job_cat) {
    $colabs_job_cats[$colabs_job_cat->cat_ID] = $colabs_job_cat->cat_name;}

//Stylesheets Reader
$alt_stylesheet_path = TEMPLATEPATH . '/styles/';
$alt_stylesheets = array();
if ( is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) {
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, ".css") !== false) {
                $alt_stylesheets[] = $alt_stylesheet_file;
            }
        }
    }
}

$images_dir =  get_template_directory_uri() . '/functions/images/';
	
//More Options
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");

$other_entries_10 = array("Select a number:","1","2","3","4","5","6","7","8","9","10");

$other_entries_4 = array("Select a number:","1","2","3","4");

// THIS IS THE DIFFERENT FIELDS
$options = array();

// General Settings
$options[] = array( "name" => __("General Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "general");					

$options[] = array( "name" => "Theme Stylesheet",
					"desc" => "Select your themes alternative color scheme.",
					"id" => $shortname."_alt_stylesheet",
					"std" => "default.css",
					"type" => "select",
					"options" => $alt_stylesheets);
					
$options[] = array( "name" => __("Custom Logo","colabsthemes"),
					"desc" => __("Upload a logo for your theme, or specify an image URL directly. Best image size in 260x60 px","colabsthemes"),
					"id" => $shortname."_logo",
					"std" => trailingslashit( get_bloginfo('template_url') ) . "images/logo.png",
					"type" => "upload");

$options[] = array( "name" => __("Custom Favicon","colabsthemes"),
					"desc" => __("Upload a 16x16px ico image that will represent your website's favicon. Favicon/bookmark icon will be shown at the left of your blog's address in visitor's internet browsers.","colabsthemes"),
					"id" => $shortname."_custom_favicon",
					"std" => trailingslashit( get_bloginfo('template_url') ) . "images/favicon.png",
					"type" => "upload");
					
$options[] = array( "name" => __( 'Main Layout', 'colabsthemes' ),
                    "desc" => __( 'Select main content and sidebar alignment. Choose between left or right sidebar layout.', 'colabsthemes' ),
                    "id" => $shortname . "_layout_settings", //colabs_layout
                    "std" => "two-col-right",
                    "type" => "images",
                    "options" => array(                                                        
                                'two-col-right' => $images_dir . '2cr.png',
								'two-col-left' => $images_dir . '2cl.png')
                    );
                    
$options[] = array( "name" => __("Enable PressTrends Tracking","colabsthemes"),
					"desc" => __("PressTrends is a simple usage tracker that allows us to see how our customers are using our themes, so that we can help improve them for you. <strong>None</strong> of your personal data is sent to PressTrends.","colabsthemes"),
					"id" => $shortname."_pt_enable",
					"std" => "true",
					"type" => "checkbox");

$options[] = array( "name" => "Disable Responsive",
					"desc" => "You can disable responsive module for your site.",
					"id" => $shortname."_disable_mobile",
					"std" => "false",
					"type" => "checkbox");					
// Google Maps Options
$options[] = array( "name" => __("Google Maps Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "general");
                    
$options[] = array( "name" => __('Google Maps Language', 'colabsthemes'),
					"desc" => sprintf( __('Find the list of supported language codes <a target="_new" href="%s">here</a>. %s','colabsthemes'), 'http://spreadsheets.google.com/pub?key=p9pdwsai2hDMsLkXsoM05KQ&gid=1', __('The Google Maps API uses the browsers language setting when displaying textual info on the map. In most cases, this is preferable and you should not need to override this setting. However, if you wish to change the Maps API to ignore the browsers language setting and force it to display info in a particular language, enter your two character region code here (i.e. Japanese is ja).','colabsthemes') ),
					"id" => $shortname."_gmaps_lang",
					"std" => "en",
					"type" => "text");
                    
$options[] = array( "name" => __('Google Maps Language', 'colabsthemes'),
					"desc" => sprintf( __('Find your two-letter ISO 3166-1 region code <a target="_new" href="%s">here</a>.','colabsthemes'), 'http://www.iso.org/iso/english_country_names_and_code_elements', __("Enter your country's two-letter region code here to properly display map locations. (i.e. Someone enters the location &quot;Toledo&quot;, it's based off the default region (US) and will display &quot;Toledo, Ohio&quot;. With the region code set to &quot;ES&quot; (Spain), the results will show &quot;Toledo, Spain.&quot;)",'colabsthemes') ),
					"id" => $shortname."_gmaps_region",
					"std" => "US",
					"type" => "text");
                    
$options[] = array( "name" => __('Distance Unit', 'colabsthemes'),
					"desc" => __('Defines the radius unit for search.','colabsthemes'),
					"id" => $shortname."_distance_unit",
					"std" => "mi",
					"type" => "radio",
					"options" => array( 'mi' => 'Miles', 'km'  => 'Kilometers' )
                    );
                    
// Jobs Options
$options[] = array( "name" => __("Jobs Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "general");

$options[] = array( "name" => __('Job Requires Approval', 'colabsthemes'),
					"desc" => __('This options allows you to define whether or not you want to moderate submit jobs. The job will be marked as \'draft\' and admin will be notified via email.','colabsthemes'),
					"id" => $shortname."_jobs_require_moderation",
					"std" => "true",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Display "How to Apply" Field?', 'colabsthemes'),
					"desc" => __('When submitting a job should the how to apply field be visible?.','colabsthemes'),
					"id" => $shortname."_submit_how_to_apply_display",
					"std" => "true",
					"type" => "checkbox",
                    );

$options[] = array( "name" => __('Job Apply', 'colabsthemes'),
					"desc" => __('Allow unregistered user to apply job?','colabsthemes'),
					"id" => $shortname."_allow_apply",
					"std" => "true",
					"type" => "checkbox",
                    );

$options[] = array( "name" => __('Allow Job Editing', 'colabsthemes'),
					"desc" => __('This options allows you to control if job listings can be edited by the user.','colabsthemes'),
					"id" => $shortname."_allow_editing",
					"std" => "true",
					"type" => "checkbox",
                    );
                    
$options[] = array( "name" => __('Edited Job Requires Approval', 'colabsthemes'),
					"desc" => __('This options allows you to define whether or not you want to moderate edited jobs. The job will be marked as \'draft\' and admin will be notified via email.','colabsthemes'),
					"id" => $shortname."_editing_needs_approval",
					"std" => "true",
					"type" => "checkbox",
                    );
                    

$options[] = array( "name" => __('Show Page Views Counter', 'colabsthemes'),
					"desc" => __('This will show a "total views" and "today\'s views" at the bottom of each job listing and blog post.','colabsthemes'),
					"id" => $shortname."_ad_stats_all",
					"std" => "true",
					"type" => "checkbox",
                    );
                    
$options[] = array( "name" => __('Job Category Required', 'colabsthemes'),
					"desc" => __('When submitting a job, is job category required? Make sure you have at least one job category before enabling this option. (Recommended)','colabsthemes'),
					"id" => $shortname."_submit_cat_required",
					"std" => "false",
					"type" => "checkbox",
                    );
                    
$options[] = array( "name" => __('Allow HTML in Job Descriptions?', 'colabsthemes'),
					"desc" => __('When submitting a job, is HTML allowed? Uncheck to have it automatically strip html out.','colabsthemes'),
					"id" => $shortname."_html_allowed",
					"std" => "true",
					"type" => "checkbox",
                    );
                    
$options[] = array( "name" => __('Show Search Bar', 'colabsthemes'),
					"desc" => __('Toggle the search bar on/off with this option.','colabsthemes'),
					"id" => $shortname."_show_searchbar",
					"std" => "true",
					"type" => "checkbox",
                    );
                                        
$options[] = array( "name" => __('Show Filter Bar', 'colabsthemes'),
					"desc" => __('Toggle the filter bar on/off with this option (shows checkboxes with Full-Time, Part-Time, etc.','colabsthemes'),
					"id" => $shortname."_show_filterbar",
					"std" => "true",
					"type" => "checkbox",
                    );

$options[] = array( "name" => __('Schedule Hourly Check', 'colabsthemes'),
					"desc" => __('Enable to check schedule every 1 hour the expired job','colabsthemes'),
					"id" => $shortname."_check_jobs_expired",
					"std" => "true",
					"type" => "checkbox",
                    );
                    
$options[] = array( "name" => __('Expired Jobs Action', 'colabsthemes'),
					"desc" => __('Choose what to do with expired jobs. Selecting \'display message\' will keep the job visible and display a \'job expired\' notice on it. Selecting \'hide\' will change the job post to private so only the job poster may view it.','colabsthemes'),
					"id" => $shortname."_expired_action",
					"type" => "radio",
					"options" => array( 'display_message' => __('Display Message', 'colabsthemes'), 'hide'  => __('Hide', 'colabsthemes') )
                    );

$options[] = array( "name" => __('Featured Job Category', 'colabsthemes'),
					"desc" => __('Select the job category to be displayed on featured job section.','colabsthemes'),
					"id" => $shortname."_featured_category_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_job_cats,
                    );

$options[] = array( "name" => __('Job Packs Dashboard', 'colabsthemes'),
					"desc" => __('Enable buy job packs on the dashboard.','colabsthemes'),
					"id" => $shortname."_packs_dashboard_buy",
					"std" => "false",
					"type" => "checkbox");
					
// Resume Options
$options[] = array( "name" => __("Resume Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "general");

$options[] = array( "name" => __('Enable / Disable Job Seeker Registration', 'colabsthemes'),
					"desc" => "Allows Job Seekers to signup. Job Seekers cannot post jobs, they can only find jobs and submit their resume.",
					"id" => $shortname."_allow_job_seekers",
					"std" => "false",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Resume Listings Visibility', 'colabsthemes'),
					"desc" => __('Lets you define who can browse through submitted resumes.','colabsthemes'),
					"id" => $shortname."_resume_listing_visibility",
					"std" => "public",
					"type" => "radio",
					"options" => array( 'public' => __('Public', 'colabsthemes'), 'members'  => __('Members only', 'colabsthemes'), 'listers'  => __('Job listers only', 'colabsthemes') )
                    );
                    
$options[] = array( "name" => __('Resume Visibility', 'colabsthemes'),
					"desc" => __('Lets you define who can view submitted resumes.','colabsthemes'),
					"id" => $shortname."_resume_visibility",
					"std" => "public",
					"type" => "radio",
					"options" => array( 'public' => __('Public', 'colabsthemes'), 'members'  => __('Members only', 'colabsthemes'), 'listers'  => __('Job listers only', 'colabsthemes') )
                    );

$options[] = array( "name" => __('Enable / Disable Audio Field', 'colabsthemes'),
					"desc" => "Enable Audio field, Will Appear on resume page.",
					"id" => $shortname."_form_audio",
					"std" => "false",
					"type" => "checkbox");
					

$options[] = array( "name" => __('Enable / Disable Video Field', 'colabsthemes'),
					"desc" => "Enable Video field, Will Appear on resume page.",
					"id" => $shortname."_form_video",
					"std" => "false",
					"type" => "checkbox");
                    
// Pricing Options
$options[] = array( "name" => __("Pricing Options","colabsthemes"),
					"type" => "heading",
					"icon" => "general");

$options[] = array( "name" => __('Job Listing Fee', 'colabsthemes'),
					"desc" => sprintf( '%2$s. %1$s', __('Enter a numeric value, do not include currency symbols. Leave blank to enable free listings.','colabsthemes'), __('Default job listing fee.','colabsthemes') ),
					"id" => $shortname."_jobs_listing_cost",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => __('Allow Job Relisting', 'colabsthemes'),
					"desc" => __('This enables an option for your customers to relist their job posting when it has expired.','colabsthemes'),
					"id" => $shortname."_allow_relist",
					"std" => "true",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Re-Listing Fee', 'colabsthemes'),
					"desc" => sprintf( '%2$s. %1$s', __('Enter a numeric value, do not include currency symbols. Leave blank to enable free re-listings.','colabsthemes'), __('Default re-listing fee.','colabsthemes') ),
					"id" => $shortname."_jobs_relisting_cost",
					"std" => "",
					"type" => "text");
                    
$options[] = array( "name" => __('Featured Job Price', 'colabsthemes'),
					"desc" => sprintf( '%2$s. %1$s', __('Only enter numeric values or decimal points. Do not include a currency symbol or commas.','colabsthemes'), __('This is the additional amount you will charge visitors to post a featured job on your site. A featured job appears at the top of the category. Leave this blank if you do not want to offer featured ads.','colabsthemes') ),
					"id" => $shortname."_cost_to_feature",
					"std" => "",
					"type" => "text");
                    
$options[] = array( "name" => __('Symbol Position', 'colabsthemes'),
					"desc" => __('Some currencies place the symbol on the right side vs the left. Select how you would like your currency symbol to be displayed.', 'colabsthemes'),
					"id" => $shortname."_curr_symbol_pos",
					"std" => "",
					"type" => "select2",
					"options" => array(
                        'left'         => __('Left of Currency ($100)', 'colabsthemes'),
						'left_space'   => __('Left of Currency with Space ($ 100)', 'colabsthemes'),
						'right'        => __('Right of Currency (100$)', 'colabsthemes'),
						'right_space'  => __('Right of Currency with Space (100 $)', 'colabsthemes')),
                    );

$options[] = array( "name" => __('Collect Payments in', 'colabsthemes'),
					"desc" => sprintf( __('See the list of supported <a target="_new" href="%s">PayPal currencies</a>. %s', 'colabsthemes'), 'https://www.paypal.com/cgi-bin/webscr?cmd=p/sell/mc/mc_intro-outside', __('This is the currency you want to collect payments in. It applies mainly to PayPal payments since other payment gateways accept more currencies. If your currency is not listed then PayPal currently does not support it.','colabsthemes') ),
					"id" => $shortname."_jobs_paypal_currency",
					"std" => "",
					"type" => "select2",
					"options" => array( 
            			'USD' => __('US Dollars (&#36;)', 'colabsthemes'),
            			'EUR' => __('Euros (&euro;)', 'colabsthemes'),
            			'GBP' => __('Pounds Sterling (&pound;)', 'colabsthemes'),
            			'AUD' => __('Australian Dollars (&#36;)', 'colabsthemes'),
            			'BRL' => __('Brazilian Real (&#36;)', 'colabsthemes'),
            			'CAD' => __('Canadian Dollars (&#36;)', 'colabsthemes'),
            			'CZK' => __('Czech Koruna', 'colabsthemes'),
            			'DKK' => __('Danish Krone', 'colabsthemes'),
            			'HKD' => __('Hong Kong Dollar (&#36;)', 'colabsthemes'),
            			'HUF' => __('Hungarian Forint', 'colabsthemes'),
            			'ILS' => __('Israeli Shekel', 'colabsthemes'),
            			'JPY' => __('Japanese Yen (&yen;)', 'colabsthemes'),
            			'MYR' => __('Malaysian Ringgits', 'colabsthemes'),
            			'MXN' => __('Mexican Peso (&#36;)', 'colabsthemes'),
            			'NZD' => __('New Zealand Dollar (&#36;)', 'colabsthemes'),
            			'NOK' => __('Norwegian Krone', 'colabsthemes'),
            			'PHP' => __('Philippine Pesos', 'colabsthemes'),
            			'PLN' => __('Polish Zloty (z&#321;)', 'colabsthemes'),
            			'SGD' => __('Singapore Dollar (&#36;)', 'colabsthemes'),
            			'SEK' => __('Swedish Krona', 'colabsthemes'),
            			'CHF' => __('Swiss Franc', 'colabsthemes'),
            			'TWD' => __('Taiwan New Dollars', 'colabsthemes'),
            			'THB' => __('Thai Baht', 'colabsthemes')
            		),
                    );

// Browse Resume Pricing Options
$options[] = array( "name" => __("Browse Resumes Pricing","colabsthemes"),
					"type" => "heading",
					"icon" => "general");
					
$options[] = array( "name" => __('Active subscription to view resumes', 'colabsthemes'),
					"desc" => __('Enabling this option will block access to the resume section if the user does not have a subscription. Access will still be determined by your visibility settings on the settings page, e.g. if set to recruiters, only recruiters will be able to subscribe. To subscribe the user must be logged in', 'colabsthemes'),
					"id" => $shortname."_resume_require_subscription",
					"std" => "",
					"class" => "collapsed",
					"type" => "checkbox");					

$options[] = array( "name" => __('Subscription notice', 'colabsthemes'),
					"desc" => __('Notice to display above the subscription button.', 'colabsthemes'),
					"id" => $shortname."_resume_subscription_notice",
					"std" => "",
					"class" => "hidden",
					"type" => "textarea",
					);
					
$options[] = array( "name" => __('Recurring Payments', 'colabsthemes'),
					"desc" => __('Please note that the Automatic option will only work if you own a <a href="https://www.paypal.com/pdn-recurring?bn_r=o">Business or Premier PayPal account</a>. <br>Please check your PayPal account type before setting this option.', 'colabsthemes'),
					"id" => $shortname."_resume_subscr_recurr_type",
					"std" => "",
					"class" => "hidden",
					"type" => "select2",
					"options" => array(
										'manual' => 'Manual (Standard Accounts)',
										'auto' => 'Automatic (Business/Premier Accounts)',
										),
          );

$options[] = array( "name" => __('Resume Access Subscription Price', 'colabsthemes'),
					"desc" => __('Only enter numeric values or decimal points. Do not include a currency symbol or commas.', 'colabsthemes'),
					"id" => $shortname."_resume_access_cost",
					"std" => "10",
					"class" => "hidden",
					"type" => "text",
					);

$options[] = array( "name" => __('Subscription Length', 'colabsthemes'),
					"desc" => __('Enter an integer. This length is also affected by the unit below.', 'colabsthemes'),
					"id" => $shortname."_resume_access_length",
					"std" => "",
					"class" => "hidden",
					"type" => "text",
					);			

$options[] = array( "name" => __('Subscription Unit', 'colabsthemes'),
					"desc" => __('Select a unit for the subscription period.', 'colabsthemes'),
					"id" => $shortname."_resume_access_unit",
					"std" => "",
					"class" => "hidden",
					"type" => "select2",
					"options" => array(
										'M' => 'Months',
										'D' => 'Days',
										'W' => 'Weeks',
										'Y' => 'Years',
										),
          );

$options[] = array( "name" => __('Allow trial', 'colabsthemes'),
					"desc" => __('Enabling a trial lets you charge more or less during the first billing period.', 'colabsthemes'),
					"id" => $shortname."_resume_allow_trial",
					"std" => "",
					"class" => "hidden",
					"type" => "checkbox");

$options[] = array( "name" => __('Resume Access Trial Price', 'colabsthemes'),
					"desc" => __('Only enter numeric values or decimal points. Do not include a currency symbol or commas.', 'colabsthemes'),
					"id" => $shortname."_resume_trial_cost",
					"std" => "10",
					"class" => "hidden",
					"type" => "text",
					);

$options[] = array( "name" => __('Trial Length', 'colabsthemes'),
					"desc" => __('Enter an integer. This length is also affected by the unit below.', 'colabsthemes'),
					"id" => $shortname."_resume_trial_length",
					"std" => "",
					"class" => "hidden",
					"type" => "text",
					);

$options[] = array( "name" => __('Trial Unit', 'colabsthemes'),
					"desc" => __('Select a unit for the trial period.', 'colabsthemes'),
					"id" => $shortname."_resume_trial_unit",
					"std" => "",
					"class" => "hidden last",
					"type" => "select2",
					"options" => array(
										'M' => 'Months',
										'D' => 'Days',
										'W' => 'Weeks',
										'Y' => 'Years',
										),
          );
					
// Pages Settings
$options[] = array( "name" => __("Pages","colabsthemes"),
					"type" => "heading",
					"icon" => "home");

$options[] = array( "name" => __('Submit Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the Submit job page. ', 'colabsthemes'),
					"id" => $shortname."_submit_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );
					
$options[] = array( "name" => __('Edit Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the Edit job page. ', 'colabsthemes'),
					"id" => $shortname."_edit_job_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );					
                    
$options[] = array( "name" => __('My Dashboard Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the My Dashboard page. ', 'colabsthemes'),
					"id" => $shortname."_dashboard_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );

$options[] = array( "name" => __('Blog Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the Blog page. ', 'colabsthemes'),
					"id" => $shortname."_blog_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );
                    
$options[] = array( "name" => __('User Profile Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the user profile page. ', 'colabsthemes'),
					"id" => $shortname."_user_profile_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );

$options[] = array( "name" => __('Confirmation Page ID', 'colabsthemes'),
					"desc" => __('This is a page for non-IPN paypal transactions to go through. Select the page for the Confirmation job page. ', 'colabsthemes'),
					"id" => $shortname."_add_new_confirm_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );
                    
$options[] = array( "name" => __('Jobs by date Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the jobs date archive page. ', 'colabsthemes'),
					"id" => $shortname."_date_archive_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );
                    
$options[] = array( "name" => __('Terms Page ID', 'colabsthemes'),
					"desc" => __('Create a terms page and select the page here, this will enable a checkbox on the registration page to confirm that the user accepts your terms and conditions.', 'colabsthemes'),
					"id" => $shortname."_terms_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );
/*
$options[] = array( "name" => __('Job Seeker Register Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the Job Seeker Registration page. ', 'colabsthemes'),
					"id" => $shortname."_job_seeker_register_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );
*/
$options[] = array( "name" => __('Job Seeker Edit Resume Page ID', 'colabsthemes'),
					"desc" => __('Select the page for the Edit Resume page. ', 'colabsthemes'),
					"id" => $shortname."_job_seeker_resume_page_id",
					"std" => "",
					"type" => "select2",
					"options" => $colabs_pages,
                    );

/* //Security Settings	 */				
$options[] = array( "name" => __("Security Setting","colabsthemes"),
                    "icon" => "general",
					"type" => "heading");

$options[] = array( "name" => __('Featured Job Category', 'colabsthemes'),
					"desc" => sprintf( __('%s View the WordPress <a target="_new" href="%s">Roles and Capabilities</a> for more information.','colabsthemes'), __('Allows you to restrict access to the WordPress Back Office (wp-admin) by specific role. Keeping this set to admins only is recommended. Select Disable if you have problems with this feature.','colabsthemes'), 'http://codex.wordpress.org/Roles_and_Capabilities' ),
					"id" => $shortname."_admin_security",
					"std" => "manage_options",
					"type" => "select2",
					"options" => array(
                        'manage_options' => __('Admins Only', 'colabsthemes'),
                        'edit_others_posts' => __('Admins, Editors', 'colabsthemes'),
                        'publish_posts' => __('Admins, Editors, Authors', 'colabsthemes'),
                        'edit_posts' => __('Admins, Editors, Authors, Contributors', 'colabsthemes'),
                        'read' => __('All Access', 'colabsthemes'),
                        'disable' => __('Disable', 'colabsthemes')
                        ),
                    );

$options[] = array( "name" => __('Enable / Disable Password Registration', 'colabsthemes'),
					"desc" => __("Allow new user to register their password on registration form.","colabsthemes"),
					"id" => $shortname."_allow_registration_password",
					"std" => "true",
					"type" => "checkbox");

$options[] = array( "name" => __('Enable / Disable reCaptcha', 'colabsthemes'),
					"desc" => sprintf(__('%2$s. reCaptcha is a free anti-spam service provided by Google. Learn more about <a target="_new" href="%1$s">reCaptcha</a>.', 'colabsthemes'), 'http://code.google.com/apis/recaptcha/', __('Set this option to yes to enable the reCaptcha service that will protect your site against spam registrations. It will show a verification box on your registration page that requires a human to read and enter the words','colabsthemes') ),
					"id" => $shortname."_captcha_enable",
                    'class' => 'collapsed',
					"std" => "false",
					"type" => "checkbox");

$options[] = array( "name" => __('reCaptcha Public Key', 'colabsthemes'),
					"desc" => sprintf( '%3$s. %1$s' . __('Sign up for a free <a target="_new" href="%2$s">Google reCaptcha</a> account.','colabsthemes'), '<div class="captchaico"></div>', 'https://www.google.com/recaptcha/admin/create', __('Enter your public key here to enable an anti-spam service on your new user registration page (requires a free Google reCaptcha account). Leave it blank if you do not wish to use this anti-spam feature','colabsthemes') ),
					"id" => $shortname."_captcha_public_key",
					"std" => "",
                    'class' => 'hidden',
					"type" => "text");

$options[] = array( "name" => __('reCaptcha Private Key', 'colabsthemes'),
					"desc" => sprintf( '%3$s. %1$s' . __('Sign up for a free <a target="_new" href="%2$s">Google reCaptcha</a> account.','colabsthemes'), '<div class="captchaico"></div>', 'https://www.google.com/recaptcha/admin/create', __('Enter your private key here to enable an anti-spam service on your new user registration page (requires a free Google reCaptcha account). Leave it blank if you do not wish to use this anti-spam feature','colabsthemes') ),
					"id" => $shortname."_captcha_private_key",
					"std" => "",
                    'class' => 'hidden',
					"type" => "text");

$options[] = array( "name" => __('Choose Theme', 'colabsthemes'),
					"desc" => __('Select the color scheme you wish to use for reCaptcha.', 'colabsthemes'),
					"id" => $shortname."_captcha_theme",
					"std" => "",
                    'class' => 'hidden last',
					"type" => "select2",
					"options" => array( 'red' => __('Red', 'colabsthemes'), 'white' => __('White', 'colabsthemes'), 'blackglass' => __('Black', 'colabsthemes'), 'clean'  => __('Clean', 'colabsthemes') )
                    );

$options[] = array( "name" => __('Anti-Spam Question', 'colabsthemes'),
					"desc" => __('Question asked before visitor can submit a new job listing.','colabsthemes'),
					"id" => $shortname."_antispam_question",
					"std" => "Is fire &ldquo;<em>hot</em>&rdquo; or &ldquo;<em>cold</em>&rdquo;?",
					"type" => "text");
                    
$options[] = array( "name" => __('Anti-Spam Answer', 'colabsthemes'),
					"desc" => __('Enter the correct answer here.','colabsthemes'),
					"id" => $shortname."_antispam_answer",
					"std" => "hot",
					"type" => "text");

/* //Email Notifications	 */
$options[] = array( "name" => __("Email Notifications","colabsthemes"),
					"icon" => "misc",
					"type" => "heading");
					
$options[] = array( "name" => __('Email Name', 'colabsthemes'),
					"desc" => __('Enter your email name .','colabsthemes'),
					"id" => $shortname."_email_name",
					"std" => get_bloginfo('name'),
					"type" => "text");
                    
$options[] = array( "name" => __('New Job Email', 'colabsthemes'),
					"desc" => sprintf(__('%s Emails will be sent to: %s. (<a target="_new" href="%s">Change email address</a>)', 'colabsthemes'), __('Send me an email once a new job has been submitted.','colabsthemes'), get_option('admin_email'), 'options-general.php'),
					"id" => $shortname."_new_ad_email",
					"std" => "false",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Job Approved Email', 'colabsthemes'),
					"desc" => __('Send the job owner an email once their job has been approved either by you manually or after payment has been made (post status changes from pending to published).', 'colabsthemes'),
					"id" => $shortname."_new_job_email_owner",
					"std" => "false",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Enable Reminder Emails', 'colabsthemes'),
					"desc" => __('Send the job owner an email 5/1 days before their job expires, and another once their job has expired (post status changes from published to draft).', 'colabsthemes'),
					"id" => $shortname."_expired_job_email_owner",
					"std" => "false",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('BCC on all Apply Emails', 'colabsthemes'),
					"desc" => __('Enable this option to receive a copy of application emails.', 'colabsthemes'),
					"id" => $shortname."_bcc_apply_emails",
					"std" => "false",
					"type" => "checkbox");
                    
/* //Payment Gateways	 */
$options[] = array( "name" => __("Payment Gateways","colabsthemes"),
					"icon" => "general",
					"type" => "heading");
                    
$options[] = array( "name" => __('PayPal Email', 'colabsthemes'),
					"desc" => __('Enter your PayPal account email address. This is where your money gets sent.','colabsthemes'),
					"id" => $shortname."_jobs_paypal_email",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => __('Enable PayPal IPN', 'colabsthemes'),
					"desc" => __('Disable IPN if the PayPal IPN does not work for you. Turning off IPN means that you will need to manually update jobs after payment.', 'colabsthemes'),
					"id" => $shortname."_enable_paypal_ipn",
					"std" => "true",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Enable IPN Debug', 'colabsthemes'),
					"desc" => sprintf( __('Debug PayPal IPN emails will be sent to %s. %s','colabsthemes'),  get_option('admin_email'), __('If you would like to receive the raw IPN post responses from PayPal to see if payments are being processed correctly, check this box.','colabsthemes') ),
					"id" => $shortname."_paypal_ipn_debug",
					"std" => "false",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Sandbox Mode', 'colabsthemes'),
					"desc" => sprintf( __('You must have a <a target="_new" href="%s">PayPal Sandbox</a> account setup before using this feature. %s','colabsthemes'), 'http://developer.paypal.com/', __('By default PayPal is set to live mode. If you would like to test and see if payments are being processed correctly, check this box to switch to sandbox mode.','colabsthemes') ),
					"id" => $shortname."_use_paypal_sandbox",
					"std" => "false",
					"type" => "checkbox");
                    
$options[] = array( "name" => __('Enable Bank Transfer', 'colabsthemes'),
					"desc" => __('Set this to yes if you want to offer cash payments via bank transfer as a payment option on your site. Note: the "JOB LISTING FEE" option on the pricing options must not empty/null for this option to work.','colabsthemes'),
					"id" => $shortname."_bank_transfer",
					"std" => "false",
                    "class" => "collapsed",
					"type" => "checkbox");

$options[] = array( "name" => __("Bank Transfer Description","colabsthemes"),
					"desc" => __("You can put bank transfer description here, such as bank account, or any other information regarding the payment.","colabsthemes"),
					"id" => $shortname."_bank_transfer_desc",
					"std" => "",
                    "class" => "hidden last",
					"type" => "textarea");

/* //Indeed Integration     */
$options[] = array( "name" => __("Indeed.com Integration","colabsthemes"),
					"icon" => "general",
					"type" => "heading");

$options[] = array( "name" => __('Enable Indeed.com', 'colabsthemes'),
					"desc" => sprintf( __('%s %s','colabsthemes'), __('Change this option to enable or disable Indeed.com automatic XML feed posting on your website.','colabsthemes'), __('Earn money by including Indeed.com job listings automatically on your website. It will add valuable content to your site while generating revenue from user clicks. This feature requires an Indeed.com publisher account.','colabsthemes') ),
					"id" => $shortname."_enable_indeed_feeds",
					"std" => "false",
					"type" => "checkbox");

$options[] = array( "name" => __('Publisher ID', 'colabsthemes'),
					"desc" => sprintf( __('%s Sign up for a free <a target="_new" href="%s">Indeed.com account</a> to get a publisher ID.','colabsthemes'), __('Enter your Indeed publisher ID (i.e. 4247835648699281).','colabsthemes'), 'https://ads.indeed.com/jobroll/' ),
					"id" => $shortname."_indeed_publisher_id",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => __("Job Listing Queries","colabsthemes"),
                    "desc" => sprintf( __('%s Setup your queries and category mappings to pull in Indeed.com job listings. Each query must be in the following format: <br/><code>keyword|limit|country|job type|post to job category (slug)</code>.<br/>Example (10 Full-Time Web Design Jobs in the UK posted to your existing JobJockey category called design):<br/><code>Web Designer|10|GB|fulltime|design</code><br/>One per line. For available country codes and other parameters, see the <a target="_new" href="%s">Indeed.com XML Feed Guide</a>.','colabsthemes'), __('Each query will run hourly and pull in all matching jobs. Jobs that have expired from Indeed.com, will also be removed from your website.','colabsthemes'), 'https://ads.indeed.com/jobroll/xmlfeed' ),
                    "id" => $shortname."_indeed_queries",
                    "std" => "",
                    "type" => "textarea");
                   
$options[] = array( "name" => __('Post Status', 'colabsthemes'),
					"desc" => sprintf( __('%s %s','colabsthemes'), __('Set to pending if you want to manually publish the jobs.','colabsthemes'), __("Define the status of all jobs pulled in from Indeed.com's XML feed.", 'colabsthemes') ),
					"id" => $shortname."_indeed_status",
					"std" => "publish",
					"type" => "select2",
					"options" => array( 'pending' => __('Pending', 'colabsthemes'), 'publish' => __('Published', 'colabsthemes') )
                    );

$options[] = array( "name" => __('Trash indeed jobs after x days', 'colabsthemes'),
					"desc" => sprintf( __('%s %s','colabsthemes'), __("Enter the number of days you want to keep indeed jobs before trashing them.", 'colabsthemes'), __('Leave blank to never trash jobs.','colabsthemes') ),
					"id" => $shortname."_indeed_auto_trash",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => __('Show search results from Indeed when no local results found?', 'colabsthemes'),
					"desc" => __('This option will dynamically pull in search results from indeed when your job board has no results.','colabsthemes'),
					"id" => $shortname."_dynamic_search_results",
					"std" => "false",
					"type" => "checkbox",
                    );

/* //Social Settings	 */				
$options[] = array( "name" => __("Social Networking","colabsthemes"),
					"icon" => "misc",
					"type" => "heading");

$options[] = array( "name" => __("Twitter","colabsthemes"),
					"desc" => __("Enter your Twitter URL","colabsthemes"),
					"id" => $shortname."_social_twitter",
					"std" => "http://twitter.com/colorlabs",
					"type" => "text");

$options[] = array( "name" => __("Facebook","colabsthemes"),
					"desc" => __("Enter your Facebook profile URL","colabsthemes"),
					"id" => $shortname."_social_facebook",
					"std" => "http://www.facebook.com/colorlabs",
					"type" => "text");	
                    
$options[] = array( "name" => __("LinkedIn","colabsthemes"),
					"desc" => __("Enter your LinkedIn profile URL","colabsthemes"),
					"id" => $shortname."_social_linkedin",
					"std" => "http://www.linkedin.com/",
					"type" => "text");	

$options[] = array( "name" => __("Enable/Disable Social Share Button","colabsthemes"),
					"desc" => __("Select which social share button you would like to enable on single post & pages.","colabsthemes"),
					"id" => $shortname."_single_share",
					"std" => array("fblike","twitter","google_plusone"),
					"type" => "multicheck2",
                    "class" => "",
					"options" => array(
                                    "fblike" => "Facebook Like Button",                                    
                                    "twitter" => "Twitter Share Button",
                                    "google_plusone" => "Google +1 Button",
									"linked" => "LinkedIn",
                                )
                    ); 					

// Open Graph Settings
$options[] = array( "name" => __("Open Graph Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "graph");

$options[] = array( "name" => __("Open Graph","colabsthemes"),
					"desc" => __("Enable or disable Open Graph Meta tags.","colabsthemes"),
					"id" => $shortname."_og_enable",
					"type" => "select2",
                    "std" => "",
                    "class" => "collapsed",
					"options" => array("" => "Enable", "disable" => "Disable") );

$options[] = array( "name" => __("Site Name","colabsthemes"),
					"desc" => __("Open Graph Site Name ( og:site_name ).","colabsthemes"),
					"id" => $shortname."_og_sitename",
					"std" => "",
                    "class" => "hidden",
					"type" => "text");

$options[] = array( "name" => __("Admin","colabsthemes"),
					"desc" => __("Open Graph Admin ( fb:admins ).","colabsthemes"),
					"id" => $shortname."_og_admins",
					"std" => "",
                    "class" => "hidden",
					"type" => "text");

$options[] = array( "name" => __("Image","colabsthemes"),
					"desc" => __("You can put the url for your Open Graph Image ( og:image ).","colabsthemes"),
					"id" => $shortname."_og_img",
					"std" => "",
                    "class" => "hidden last",
					"type" => "text");

//Dynamic Images 					                   
$options[] = array( "name" => __("Thumbnail Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "image");
                    
$options[] = array( "name" => __("WordPress Featured Image","colabsthemes"),
					"desc" => __("Use WordPress Featured Image for post thumbnail.","colabsthemes"),
					"id" => $shortname."_post_image_support",
					"std" => "true",
					"class" => "collapsed",
					"type" => "checkbox");

$options[] = array( "name" => __("WordPress Featured Image - Dynamic Resize","colabsthemes"),
					"desc" => __("Resize post thumbnail dynamically using WordPress native functions (requires PHP 5.2+).","colabsthemes"),
					"id" => $shortname."_pis_resize",
					"std" => "true",
					"class" => "hidden",
					"type" => "checkbox");
                    
$options[] = array( "name" => __("WordPress Featured Image - Hard Crop","colabsthemes"),
					"desc" => __("Original image will be cropped to match the target aspect ratio.","colabsthemes"),
					"id" => $shortname."_pis_hard_crop",
					"std" => "true",
					"class" => "hidden last",
					"type" => "checkbox");
                    
$options[] = array( "name" => __("TimThumb Image Resizer","colabsthemes"),
					"desc" => __("Enable timthumb.php script which dynamically resizes images added thorugh post custom field.","colabsthemes"),
					"id" => $shortname."_resize",
					"std" => "true",
					"type" => "checkbox");
                    
$options[] = array( "name" => __("Automatic Thumbnail","colabsthemes"),
					"desc" => __("Generate post thumbnail from the first image uploaded in post (if there is no image specified through post custom field or WordPress Featured Image feature).","colabsthemes"),
					"id" => $shortname."_auto_img",
					"std" => "true",
					"type" => "checkbox");
                    
$options[] = array( "name" => __("Thumbnail Image in RSS Feed","colabsthemes"),
					"desc" => __("Add post thumbnail to RSS feed article.","colabsthemes"),
					"id" => $shortname."_rss_thumb",
					"std" => "false",
					"type" => "checkbox");

$options[] = array( "name" => __("Thumbnail Image Dimensions","colabsthemes"),
					"desc" => __("Enter an integer value i.e. 250 for the desired size which will be used when dynamically creating the images.","colabsthemes"),
					"id" => $shortname."_image_dimensions",
					"std" => "",
					"type" => array( 
									array(  'id' => $shortname. '_thumb_w',
											'type' => 'text',
											'std' => 100,
											'meta' => 'Width'),
									array(  'id' => $shortname. '_thumb_h',
											'type' => 'text',
											'std' => 100,
											'meta' => 'Height')
								  ));

$options[] = array( "name" => __("Custom Field Image","colabsthemes"),
					"desc" => __("Enter your custom field image name to change the default name (default name: image).","colabsthemes"),
					"id" => $shortname."_custom_field_image",
					"std" => "",
					"type" => "text");
					
// Analytics ID, RSS feed

$options[] = array( "name" => __("Analytics ID & Feedburner","colabsthemes"),
					"type" => "heading",
					"icon" => "statistics");
					
$options[] = array( "name" => __("GoSquared Token","colabsthemes"),
					"desc" => __("You can use GoSquared real-time web analytics. Enter your GoSquared Token here (ex. GSN-893821-D).",	"colabsthemes"),
					"id" => $shortname."_gosquared_id",
					"std" => "",
					"type" => "text");					
                    
$options[] = array( "name" => __("Google Analytics","colabsthemes"),
					"desc" => __("Manage your website statistics with Google Analytics, put your Analytics Code here.","colabsthemes"),
					"id" => $shortname."_google_analytics",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => __("Feedburner URL","colabsthemes"),
					"desc" => __("Feedburner URL. This will replace RSS feed link. Start with http://.","colabsthemes"),
					"id" => $shortname."_feedlinkurl",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => __("Feedburner Comments URL","colabsthemes"),
					"desc" => __("Feedburner URL. This will replace RSS comment feed link. Start with http://.","colabsthemes"),
					"id" => $shortname."_feedlinkcomments",
					"std" => "",
					"type" => "text");
					
		
// Footer Settings
$options[] = array( "name" => __("Footer Settings","colabsthemes"),
					"type" => "heading",
					"icon" => "footer");
                    
$options[] = array( "name" => __("Enable / Disable Custom Footer Logo","colabsthemes"),
					"desc" => __("Activate to add custom logo on footer area.","colabsthemes"),
					"id" => $shortname."_logo_footer",
					"class" => "collapsed",
					"std" => "true",
					"type" => "checkbox");    
                    
$options[] = array( "name" => __("Footer Logo","colabsthemes"),
					"desc" => __("Upload a logo for your theme, or specify an image URL directly. Best image size in 260x60 px","colabsthemes"),
					"id" => $shortname."_logo_footer_img",
					"std" => trailingslashit( get_bloginfo('template_url') ) . "images/footer-logo.png",
					"class" => "hidden last",
					"type" => "upload");
                    
$options[] = array( "name" => __("Enable / Disable Custom Credit (Left)","colabsthemes"),
					"desc" => __("Activate to add custom credit on footer area.","colabsthemes"),
					"id" => $shortname."_footer_credit_left",
					"class" => "collapsed",
					"std" => "true",
					"type" => "checkbox");    

$options[] = array( "name" => __("Footer Credit","colabsthemes"),
                    "desc" => __("You can customize footer credit on footer area here.","colabsthemes"),
                    "id" => $shortname."_footer_credit_left_txt",
                    "std" => "All rights reserved &copy; 2011",
					"class" => "hidden last",                    
                    "type" => "textarea");
                   
$options[] = array( "name" => __("Enable / Disable Custom Credit (Right)","colabsthemes"),
					"desc" => __("Activate to add custom credit on footer area.","colabsthemes"),
					"id" => $shortname."_footer_credit_right",
					"class" => "collapsed",
					"std" => "true",
					"type" => "checkbox");    

$options[] = array( "name" => __("Footer Credit","colabsthemes"),
                    "desc" => __("You can customize footer credit on footer area here.","colabsthemes"),
                    "id" => $shortname."_footer_credit_right_txt",
                    "std" => '<a href="http://colorlabsproject.com/themes/jobjockey">JobJockey</a> by <a href="http://colorlabsproject.com">ColorLabs &amp; Company</a>.',
					"class" => "hidden last",                    
                    "type" => "textarea");


/* //Contact Form */
$options[] = array( "name" => __("Contact Form","colabsthemes"),
					"type" => "heading",
					"icon" => "general");    
$options[] = array( "name" => __("Destination Email Address","colabsthemes"),
					"desc" => __("All inquiries made by your visitors through the Contact Form page will be sent to this email address.","colabsthemes"),
					"id" => $shortname."_contactform_email",
					"std" => "",
					"type" => "text"); 

				
					
// Add extra options through function
if ( function_exists("colabs_options_add") )
	$options = colabs_options_add($options);

if ( get_option('colabs_template') != $options) update_option('colabs_template',$options);      
if ( get_option('colabs_themename') != $themename) update_option('colabs_themename',$themename);   
if ( get_option('colabs_shortname') != $shortname) update_option('colabs_shortname',$shortname);
if ( get_option('colabs_manual') != $manualurl) update_option('colabs_manual',$manualurl);
if ( get_option('colabs_version') != $version) update_option('colabs_version',$version);

update_option( 'colabs_enable_log', 'no' );
/*update_option( 'colabs_allow_job_seekers', false );
update_option( 'colabs_resume_listing_visibility', 'listers' );
update_option( 'colabs_resume_visibility', 'listers' );*/

//PressTrends
$colabs_pt_auth = "89vr2mcs0alva0cx63o08j6ulep8syj2j"; 
update_option('colabs_pt_auth',$colabs_pt_auth);

// CoLabs Metabox Options
// Start name with underscore to hide custom key from the user
$colabs_metaboxes = array();
$colabs_metabox_settings = array();
global $post;

    //Metabox Settings
    $colabs_metabox_settings['post'] = array(
                                'id' => 'colabsthemes-settings',
								'title' => 'ColorLabs' . __( ' Image/Video Settings', 'colabsthemes' ),
								'callback' => 'colabsthemes_metabox_create',
								'page' => 'post',
								'context' => 'normal',
								'priority' => 'high',
                                'callback_args' => ''
								);
                                    
    $colabs_metabox_settings['page'] = array(
                                'id' => 'colabsthemes-settings',
								'title' => 'ColorLabs' . __( ' Image/Video Settings', 'colabsthemes' ),
								'callback' => 'colabsthemes_metabox_create',
								'page' => 'page',
								'context' => 'normal',
								'priority' => 'high',
                                'callback_args' => ''
								);

								
if ( ( get_post_type() == 'post' ) || ( get_post_type() == 'page') || ( !get_post_type() ) ) {
	$colabs_metaboxes[] = array (  "name"  => $shortname."_single_top",
					            "std"  => "Image",
					            "label" => "Item to Show",
					            "type" => "radio",
					            "desc" => "Choose Image/Embed Code to appear at the single top.",
								"options" => array(	"none" => "None",
													"single_image" => "Image",
													"single_video" => "Embed" ));
                                                    
	$colabs_metaboxes[] = array (	"name" => "image",
								"label" => "Post Custom Image",
								"type" => "upload",
                                "class" => "single_image",
								"desc" => "Upload an image or enter an URL.");
	
	$colabs_metaboxes[] = array (  "name"  => $shortname."_embed",
					            "std"  => "",
					            "label" => "Video Embed Code",
					            "type" => "textarea",
                                "class" => "single_video",
					            "desc" => "Enter the video embed code for your video (YouTube, Vimeo or similar)");
								
} // End post


// Add extra metaboxes through function
if ( function_exists("colabs_metaboxes_add") ){
	$colabs_metaboxes = colabs_metaboxes_add($colabs_metaboxes);
    }
if ( get_option('colabs_custom_template') != $colabs_metaboxes){
    update_option('colabs_custom_template',$colabs_metaboxes);
    }
if ( get_option('colabs_metabox_settings') != $colabs_metabox_settings){
    update_option('colabs_metabox_settings',$colabs_metabox_settings);
    }
     
}
}



?>