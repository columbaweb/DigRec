<?php
if (!is_admin()) add_action( 'wp_print_scripts', 'colabsthemes_add_javascript' );

if (!function_exists('colabsthemes_add_javascript')) {

	function colabsthemes_add_javascript () {
	global $colabs_abbr;
	
	$http = (is_ssl()) ? 'https' : 'http';
		
	// load google cdn hosted scripts if enabled
    if (get_option($colabs_abbr.'_google_jquery') == 'yes') :
		
		wp_deregister_script('jquery');
		wp_register_script('jquery', (''.$http.'://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js'), false);
		wp_register_script('jquery-ui-custom', ''.$http.'://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js', false, '1.8');
	else :
    
		// wp_register_script('jquery-ui-custom', trailingslashit( get_template_directory_uri() ) . 'includes/js/jquery-ui-1.8.custom.min.js', false, '1.8');        
    
	endif;

        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-autocomplete');
    	
		wp_enqueue_script( 'sooperfish', trailingslashit( get_template_directory_uri() ) . 'includes/js/jquery.sooperfish.js', array('jquery') );
		wp_enqueue_script( 'flexslider', trailingslashit( get_template_directory_uri() ) . 'includes/js/jquery.flexslider-min.js', array('jquery') );
		wp_enqueue_script( 'gmap', 'http://maps.googleapis.com/maps/api/js?sensor=false' );
        wp_enqueue_script( 'gmap3', get_template_directory_uri().'/includes/js/gmap3.min.js', array('gmap','jquery') );
        wp_enqueue_script( 'general', get_template_directory_uri().'/includes/js/theme-scripts.js', array('jquery') );
		wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/includes/js/fancybox/jquery.fancybox-1.3.4.css');
        wp_enqueue_script( 'fancybox', trailingslashit( get_template_directory_uri() ) . 'includes/js/fancybox/jquery.fancybox-1.3.4.js', array('jquery') );
		
		wp_enqueue_script( 'zero', trailingslashit( get_template_directory_uri() ) . 'includes/js/zero.js', array('jquery') );

		wp_localize_script( 'zero', 'config', array(
			'ajaxurl' => admin_url('admin-ajax.php')
		) );

		/* We add some JavaScript to pages with the comment form to support sites with threaded comments (when in use). */        
        	if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' );
        
	} /* // End colabsthemes_add_javascript() */
	
} /* // End IF Statement */

// this function is called when submitting a new job listing
function colabs_load_form_scripts() {
    // only load the tinymce editor when html is allowed
    if (get_option('colabs_html_allowed') == 'true') {
        wp_enqueue_script('tiny_mce', get_bloginfo('url').'/wp-includes/js/tinymce/tiny_mce.js');
        wp_enqueue_script('tiny_mce-wp-langs-en', get_bloginfo('url').'/wp-includes/js/tinymce/langs/wp-langs-en.js');
    }
}

/*-----------------------------------------------------------------------------------*/
/* Ajax action for retrieving data for autocomplete keyword
/*-----------------------------------------------------------------------------------*/
add_action( 'wp_ajax_nopriv_get-keyword', 'getKeyword' );
add_action( 'wp_ajax_get-keyword', 'getKeyword');

function getKeyword() {
	global $wpdb;
	$term = $_POST['term'];
	$data = $wpdb->get_results("SELECT name FROM $wpdb->terms WHERE name LIKE '$term%'");
	$resp = array();
	foreach( $data as $d ) {
		array_push($resp, $d->name);
	};

	header( "Content-Type: application/json" );
	echo json_encode( $resp );
	exit;
}

// Get Locations
// -------------
add_action( 'wp_ajax_nopriv_get-location', 'getLocations' );
add_action( 'wp_ajax_get-location', 'getLocations' );

function getLocations() {
	global $wpdb;
	$term = $_REQUEST['term'];
	$data = $wpdb->get_results("SELECT DISTINCT meta_value AS location FROM $wpdb->postmeta WHERE meta_key = 'geo_address' AND meta_value LIKE '%$term%'");
	$resp = array();
	foreach( $data as $d ) {
		array_push($resp, $d->location);
	};

	header( "Content-Type: application/json" );
	echo json_encode( $resp );
	exit;
}

?>