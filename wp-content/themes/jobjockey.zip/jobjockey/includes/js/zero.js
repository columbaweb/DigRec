/**
 * jQuery Mobile Menu 
 * Turn unordered list menu into dropdown select menu
 * version 1.0(31-OCT-2011)
 * 
 * Built on top of the jQuery library
 *   http://jquery.com
 * 
 * Documentation
 * 	 http://github.com/mambows/mobilemenu
 */
(function($){$.fn.mobileMenu = function(options) {var defaults = {defaultText: 'Navigate to...', className: 'select-menu', subMenuClass: 'sub-menu', subMenuDash: '&ndash;'}, settings = $.extend( defaults, options ), el = $(this); this.each(function(){el.find('ul').addClass(settings.subMenuClass); $('<select />',{'class' : settings.className }).insertAfter( el ); $('<option />', {"value"		: '#', "text"		: settings.defaultText }).appendTo( '.' + settings.className ); el.find('a').each(function(){var $this 	= $(this), optText	= '&nbsp;' + $this.text(), optSub	= $this.parents( '.' + settings.subMenuClass ), len			= optSub.length, dash; if( $this.parents('ul').hasClass( settings.subMenuClass ) ) {dash = Array( len+1 ).join( settings.subMenuDash ); optText = dash + optText; } $('<option />', {"value"	: this.href, "html"	: optText, "selected" : (this.href == window.location.href) }).appendTo( '.' + settings.className ); }); $('.' + settings.className).change(function(){var locations = $(this).val(); if( locations !== '#' ) {window.location.href = $(this).val(); }; }); }); return this; }; })(jQuery);

(function($){
$(window).load(function(){
	// Calculate footer logo width and 
	// give margin to adjacent elemeny
	function footerLogo() {
		var $logo = $('.footer-logo'),
			logoW = $logo.width(),
			nextEl = $logo.next();
		nextEl.css('margin-left',logoW + 20);
	};
	footerLogo();
});

$(document).ready(function(){

	// Click event on login menu
	$('.login-menu a').live('click', function(e){
		e.preventDefault();
		$(this).next('.login-box').fadeToggle();
	});

	// Joining top menu into single unordered list
	function joinTopMenu() {
		$('<div class="nav-collapse collapse"><ul class="nav-join"></ul></div>').appendTo('.mobile-menu');
		$('.nav-left li, .nav-right li').each(function(){
			$(this).clone().appendTo('.nav-join');
		});
	};
	joinTopMenu();

	/** Mobile Menu */
	// $('.nav-join').mobileMenu();

	/* Autocomplete
	----------------------------------------------------------------- */
	function form_autocomplete( selector, action ) {
		var $selector = $(selector);

		$selector.autocomplete({
			minLength: 2,
			source: function( request, response ) {
				var term = request.term,
						autoInp = $selector;
				$.ajax({
					type: "POST",
					url: config.ajaxurl,
					data: { action: action, term: term },
					beforeSend: function(){
						autoInp.addClass('loading');
					},
					success: function(data){
						autoInp.removeClass('loading');
						response( data );
					}
				});

			}
		});
	}
	form_autocomplete( '.job-searchform input[rel=keyword]', 'get-keyword' );
	form_autocomplete( '.job-searchform input[name=location]', 'get-location' );


	/* Mobile nav collapse
	------------------------------------------------------------------- */
	$('.btn-navbar').click(function(e){
	  e.preventDefault();
	  var $el = $(this),
	      $navCollapse = $el.next('.nav-collapse');

	  // If collapsed
	  if( $el.hasClass('collapsed') ) {
	    $navCollapse.height( $navCollapse.children().outerHeight(true) );
	    $el.removeClass('collapsed');
	  } else {
	    $navCollapse.height(0);
	    $el.addClass('collapsed');
	  }
	});

});
})(jQuery);