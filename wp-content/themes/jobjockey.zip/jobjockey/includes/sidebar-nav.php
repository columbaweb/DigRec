<div class="widget widget_colabs_jobsort" id="widget_jobsort">
	<h3 class="widget-title"><?php _e('Browse Jobs', 'colabsthemes'); ?></h3>

	<form>
		<?php
		// By Cat
		$args = array(
		    'hierarchical'       => false,
		    'parent'               => 0
		);
		$terms = get_terms( 'job_cat', $args );
		if ($terms) :
            echo '<select><option class="top">'.__('Job by Category', 'colabsthemes').'</option>';

            foreach($terms as $term) :
                echo '<option class="page_item ';
                if ( isset($wp_query->queried_object->slug) && $wp_query->queried_object->slug==$term->slug ){ 
	                echo 'current_page_item"'; 
	            }else{ 
		            //echo '" onClick="window.open(\''.get_term_link( $term->slug, 'job_cat' ).'\',\'_self\');"'; 
		            echo '" value="'.get_term_link( $term->slug, 'job_cat' ).'"';
		        }
                echo '>'.$term->name.'</option>';
            endforeach;

            echo '</select>';
		endif;
		
		// By Type
		$args = array(
		    'hierarchical'       => false,
		    'parent'               => 0
		);
		$terms = get_terms( 'job_type', $args );
		if ($terms) :
			echo '<select><option class="top">'.__('Job by Type', 'colabsthemes').'</option>';
		
			foreach($terms as $term) :
				echo '<option class="page_item ';
				if ( isset($wp_query->queried_object->slug) && $wp_query->queried_object->slug==$term->slug ){ 
					echo 'current_page_item"'; 
				}else{ 
					//echo '" onClick="window.open(\''.get_term_link( $term->slug, 'job_type' ).'\',\'_self\');"'; 
					echo '" value="'.get_term_link( $term->slug, 'job_type' ).'"';
				}
				echo '>'.$term->name.'</option>';
			endforeach;
			
			echo '</select>';
		endif;
		
		// By Salary
		$args = array(
		    'hierarchical'       => false,
		    'parent'               => 0
		);
		$terms = get_terms( 'job_salary', $args );
		if ($terms) :
			echo '<select><option class="top">'.__('Job Salary', 'colabsthemes').'</option>';
		
			foreach($terms as $term) :
				echo '<option class="page_item ';
				if ( isset($wp_query->queried_object->slug) && $wp_query->queried_object->slug==$term->slug ){ 
					echo 'current_page_item"'; 
				}else{ 
					//echo '" onClick="window.open(\''.get_term_link( $term->slug, 'job_salary' ).'\',\'_self\');"';
					echo '" value="'.get_term_link( $term->slug, 'job_salary' ).'"';
				}
				echo '>'.$term->name.'</option>';
			endforeach;
			
			echo '</select>';
		endif;

		// By Date
		if ($datepage = get_option('colabs_date_archive_page_id')) :
                    $datepagelink = get_permalink($datepage);
                    echo '<select><option class="top">'.__('Date posted', 'colabsthemes').'</option>';
                    /*echo '<option class="page_item" onClick="window.open(\''.add_query_arg('show', 'today', $datepagelink).'\',\'_self\');">'.__('Today','colabsthemes').'</option>';
                    echo '<option class="page_item" onClick="window.open(\''.add_query_arg('show', 'week', $datepagelink).'\',\'_self\');">'.__('This Week','colabsthemes').'</option>';
                    echo '<option class="page_item" onClick="window.open(\''.add_query_arg('show', 'lastweek', $datepagelink).'\',\'_self\');">'.__('Last Week','colabsthemes').'</option>';
                    echo '<option class="page_item" onClick="window.open(\''.add_query_arg('show', 'month', $datepagelink).'\',\'_self\');">'.__('This Month','colabsthemes').'</option>';*/
                    echo '<option class="page_item" value="'.add_query_arg('show', 'today', $datepagelink).'">'.__('Today','colabsthemes').'</option>';
                    echo '<option class="page_item" value="'.add_query_arg('show', 'week', $datepagelink).'">'.__('This Week','colabsthemes').'</option>';
                    echo '<option class="page_item" value="'.add_query_arg('show', 'lastweek', $datepagelink).'">'.__('Last Week','colabsthemes').'</option>';
                    echo '<option class="page_item" value="'.add_query_arg('show', 'month', $datepagelink).'">'.__('This Month','colabsthemes').'</option>';
                    echo '</select>';
		endif;
		?>
        <input type="submit" value="Go" style="visibility: hidden;"/>
	</form>

	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery('.widget_colabs_jobsort select').change(function(e){
				var locations = jQuery(this).val();
				window.location.href = locations;
			});
		});
	</script>

</div> 