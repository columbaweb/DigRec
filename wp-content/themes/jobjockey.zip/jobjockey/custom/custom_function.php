<?php
/* By taking advantage of hooks, filters, and the Custom Loop API, you can make Backbone
 * do ANYTHING you want. For more information, please see the following articles from
 * the Backbone Manual or visit ColorLabs Support Center:
 * 
 * http://colorlabsproject.com/resolve/

---:[ place your custom code below this line ]:---*/