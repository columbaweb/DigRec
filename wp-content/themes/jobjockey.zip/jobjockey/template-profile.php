<?php
/*
Template Name: User Profile
*/

nocache_headers();

colabsthemes_auth_redirect_login();

global $userdata;
get_currentuserinfo(); // grabs the user info and puts into vars

// check to see if the form has been posted. If so, validate the fields
if(!empty($_POST['submit'])) {

    require_once(ABSPATH . 'wp-admin/includes/user.php');
    require_once(ABSPATH . WPINC . '/registration.php');

    check_admin_referer('update-profile_' . $user_ID);

    $errors = edit_user($user_ID);

    if ( is_wp_error( $errors ) ) foreach( $errors->get_error_messages() as $message ) $errmsg = $message;

    // if there are no errors, then process the ad updates
    if($errmsg == '') {
        // update the user fields
        do_action('personal_options_update', $user_ID);

        // update the custom user fields
        update_user_meta($user_ID, 'twitter_id', $_POST['twitter_id']);
        update_user_meta($user_ID, 'facebook_id', $_POST['facebook_id']);
        update_user_meta($user_ID, 'linkedin_profile', $_POST['linkedin_profile']);
        update_user_meta($user_ID, 'company_name', $_POST['company_name']);
        update_user_meta($user_ID, 'mobile_number', $_POST['mobile_number']);
        update_user_meta($user_ID, 'colabs_address', $_POST['colabs_address']);
        update_user_meta($user_ID, 'colabs_geo_latitude', $_POST['colabs_geo_latitude']);
        update_user_meta($user_ID, 'colabs_geo_longitude', $_POST['colabs_geo_longitude']);
        
        $d_url = $_POST['dashboard_url'];
        $edit_profile_url = get_permalink( get_option('colabs_user_profile_page_id') );
        wp_redirect( add_query_arg( array('updated' => 'true', 'd' => $d_url), $edit_profile_url ) );

    } else {
        $errmsg = '<ul class="errors"><li>' . $errmsg . '</li></ul>';
    }
}	

get_header(); 

?>
	<div class="row">

    <?php get_sidebar('user'); ?>

    <div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
    
        <div class="employer-dashboard section">
            <h3 class="section-title"><?php printf( __('%s\'s Profile', 'colabsthemes'), ucwords( $userdata->user_login )); ?></h3>
            <div class="section-content">

			<?php 
			if ( isset($_GET['updated']) ) :
				$d_url = $_GET['d'];
				echo '<p class="success">'.__('Your profile has been updated.','colabsthemes').'</p>';
			endif;
			
			if (isset($errmsg)) echo $errmsg;
			?>

				<form name="profile" id="your-profile" action="" method="post" class="main_form" autocomplete="off">
					
					<div>
						<?php wp_nonce_field('update-profile_' . $user_ID) ?>
						<input type="hidden" name="from" value="profile" />
						<input type="hidden" name="checkuser_id" value="<?php echo $user_ID ?>" />
					</div>
					
					<fieldset>
						<legend><?php _e('Your Details', 'colabsthemes'); ?></legend>

                        <p><label for="user_login"><?php //_e('Username','colabsthemes') ?><em class="description"><?php _e("Usernames cannot be changed","colabsthemes"); ?>.</em></label> <input type="text" name="user_login" class="text regular-text" id="user_login" value="<?php echo $userdata->user_login ?>" maxlength="100" disabled="disabled" /></p>
                        
						<p><label for="first_name"><?php _e('First Name','colabsthemes') ?></label> <input type="text" name="first_name" class="text regular-text" id="first_name" value="<?php echo $userdata->first_name ?>" maxlength="100" /></p>
						
						<p><label for="last_name"><?php _e('Last Name','colabsthemes') ?></label> <input type="text" name="last_name" class="text regular-text" id="last_name" value="<?php echo $userdata->last_name ?>" maxlength="100" /></p>
                                                
						<p><label for="nickname"><?php _e('Nickname/Company Name','colabsthemes') ?></label> <input type="text" name="nickname" class="text regular-text" id="nickname" value="<?php echo $userdata->nickname ?>" maxlength="100" /></p>
						
						<p><label for="display_name"><?php _e('Display Name','colabsthemes') ?></label> <select name="display_name" class="select" id="display_name">
						<?php
								$public_display = array();
								$public_display['display_displayname'] = $userdata->display_name;
								$public_display['display_nickname'] = $userdata->nickname;
								$public_display['display_username'] = $userdata->user_login;
								$public_display['display_firstname'] = $userdata->first_name;
								$public_display['display_firstlast'] = $userdata->first_name.' '.$userdata->last_name;
								$public_display['display_lastfirst'] = $userdata->last_name.' '.$userdata->first_name;
								$public_display = array_unique(array_filter(array_map('trim', $public_display)));
								foreach($public_display as $id => $item) {
						?>
								<option id="<?php echo $id; ?>" value="<?php echo $item; ?>"><?php echo $item; ?></option>
						<?php
								}
						?>
						</select></p>
						
						<p><label for="email"><?php _e('Email','colabsthemes') ?></label> <input type="text" name="email" class="text regular-text" id="email" value="<?php echo $userdata->user_email ?>" maxlength="100" /></p>

						<p><label for="mobile_number"><?php _e('Contact Number','colabsthemes') ?></label> <input type="text" name="mobile_number" class="text regular-text" id="mobile_number" value="<?php echo get_user_meta($user_ID, 'mobile_number', true); ?>" maxlength="100" /></p>

					</fieldset>
					
					<fieldset>
						<legend><?php _e('Company Info &amp; Social media', 'colabsthemes'); ?></legend>
                        
						<p><label for="company_name"><?php _e('Company Name','colabsthemes') ?></label> <input type="text" name="company_name" class="text regular-text" id="company_name" value="<?php echo get_user_meta($user_ID, 'company_name', true); ?>" maxlength="100" /></p>

						<p><label for="url"><?php _e('Website','colabsthemes') ?></label> <input type="text" name="url" class="text regular-text" id="url" value="<?php echo $userdata->user_url ?>" maxlength="100" /></p>

						<p><label for="twitter_id"><?php _e('Twitter ID','colabsthemes') ?></label> <input type="text" name="twitter_id" class="text regular-text" id="twitter_id" value="<?php echo get_user_meta($user_ID, 'twitter_id', true); ?>" maxlength="100" /></p>
						
						<p><label for="facebook_id"><?php _e('Facebook ID','colabsthemes') ?></label> <input type="text" name="facebook_id" class="text regular-text" id="facebook_id" value="<?php echo get_user_meta($user_ID, 'facebook_id', true); ?>" maxlength="100" /></p>
						
						<p><label for="linkedin_profile"><?php _e('LinkedIn profile URL','colabsthemes') ?></label> <input type="text" name="linkedin_profile" class="text regular-text" id="linkedin_profile" value="<?php echo get_user_meta($user_ID, 'linkedin_profile', true); ?>" maxlength="100" /></p>

					</fieldset>
                    
            		<fieldset>
            			<legend><?php _e('Company Location', 'colabsthemes'); ?></legend>								
            			<p><?php _e('Leave blank if the location of the company does not matter.', 'colabsthemes'); ?></p>	
            			<div id="geolocation_box">
                        <?php
                        $colabs_address = get_user_meta($user_ID, 'colabs_address', true);
                        $colabs_geo_latitude = get_user_meta($user_ID, 'colabs_geo_latitude', true);
                        $colabs_geo_longitude = get_user_meta($user_ID, 'colabs_geo_longitude', true);
                        
                        colabs_geolocation_scripts($colabs_geo_latitude,$colabs_geo_longitude);
                        ?>
            				<p><input type="text" class="text" name="colabs_address" id="geolocation-address" value="<?php if (isset( $colabs_address )) echo $colabs_address; ?>" autocomplete="off" />
                            <label><input id="geolocation-load" type="button" class="button geolocationadd" value="<?php _e('Find Address/Location', 'colabsthemes'); ?>" /></label>
                            <input type="hidden" class="text" name="colabs_geo_latitude" id="geolocation-latitude" value="<?php if (isset( $colabs_geo_latitude )) echo $colabs_geo_latitude; ?>" />
                            <input type="hidden" class="text" name="colabs_geo_longitude" id="geolocation-longitude" value="<?php if (isset( $colabs_geo_longitude )) echo $colabs_geo_longitude; ?>" /></p>
            				<div id="map_wrap" style="border:solid 2px #ddd;"><div id="geolocation-map" style="width:100%;height:350px;"></div></div>
            			</div>
            		</fieldset>	
                    
					<fieldset>
						<legend><?php _e('Profile', 'colabsthemes'); ?></legend>
						
						<p><?php _e('Enter a description below; this information will appear on your profile.', 'colabsthemes'); ?></p>
					
						<p><label for="description"><?php _e('Profile content','colabsthemes'); ?></label> <textarea name="description" class="text regular-text" id="description" rows="10" cols="50"><?php echo $userdata->description ?></textarea></p>
						
					</fieldset>
					
					<?php
					$show_password_fields = apply_filters('show_password_fields', true);
					if ( $show_password_fields ) :
					?>
					<fieldset>
						<legend><?php _e('Change password', 'colabsthemes'); ?></legend>
						<p><?php _e('Leave this field blank unless you would like to change your password.','colabsthemes'); ?> <?php _e('Your password should be at least seven characters long.','colabsthemes'); ?></p>
					
						<p><label for="pass1"><?php _e('New Password','colabsthemes'); ?></label> <input type="password" name="pass1" class="text regular-text" id="pass1" maxlength="50" value="" /></p>
						
						<p><label for="pass1"><?php _e('Password Again','colabsthemes'); ?></label> <input type="password" name="pass2" class="text regular-text" id="pass2" maxlength="50" value="" /></p>
						
						<div id="pass-strength-result"><?php _e('Strength indicator','colabsthemes'); ?></div>
						
					</fieldset>
					<?php endif; ?>
					
					<?php
						do_action('profile_personal_options', $userdata);
						do_action('show_user_profile', $userdata);
					?>
					<p>
						<input type="hidden" name="action" value="update" />
						<input type="hidden" name="user_id" id="user_id" value="<?php echo $user_id; ?>" />
						<input type="submit" class="submit" name="submit" value="<?php _e('Update Profile &raquo;', 'colabsthemes')?>" />
					</p>
				</form>

		</div><!-- end section-content -->
    
        </div><!-- end employer-dashboard section -->
        
    </div><!-- end content -->
    
	</div><!-- end row -->
	
	<script type='text/javascript' src='<?php echo get_bloginfo('wpurl'); ?>/wp-admin/js/password-strength-meter.js?ver=20081210'></script>
	<script type="text/javascript">
	// <![CDATA[
		(function($){

			 $(document).ready( function() {
                
				function check_pass_strength () {
		
					var pass = $('#pass1').val();
					var pass2 = $('#pass2').val();
					var user = $('#user_login').val();
		
					$('#pass-strength-result').removeClass('short bad good strong mismatch');
					if ( ! pass ) {
						$('#pass-strength-result').html( pwsL10n.empty );
						return;
					}

					var strength = passwordStrength(pass, user, pass2);
		
					if ( 2 == strength )
						$('#pass-strength-result').addClass('bad').html( pwsL10n.bad );
					else if ( 3 == strength )
						$('#pass-strength-result').addClass('good').html( pwsL10n.good );
					else if ( 4 == strength )
						$('#pass-strength-result').addClass('strong').html( pwsL10n.strong );
					else if ( 5 == strength )
						 $('#pass-strength-result').addClass('mismatch').html( pwsL10n.mismatch );
					else
						$('#pass-strength-result').addClass('short').html( pwsL10n.shrt );
		
				}
	
				$('#pass1, #pass2').val('').keyup( check_pass_strength );
			});
		})(jQuery);

		pwsL10n = {
			empty: "<?php _e('Strength indicator','colabsthemes') ?>",
			shrt: "<?php _e('Very weak','colabsthemes') ?>",
			bad: "<?php _e('Weak','colabsthemes') ?>",
			good: "<?php _e('Medium','colabsthemes') ?>",
			strong: "<?php _e('Strong','colabsthemes') ?>",
			mismatch: "<?php _e('Mismatch','colabsthemes') ?>"
		}
		try{convertEntities(pwsL10n);}catch(e){};
	// ]]>
	</script>

	<div class="clear"></div>

<?php get_footer(); ?>