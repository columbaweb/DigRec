<?php global $colabs_options, $featured_job_cat_id; ?>

<?php if (isset($_GET['resume_search']) && $_GET['resume_search']) : get_template_part('search-resume'); exit; endif; ?>

<?php if (isset($_GET['location'])) $_GET['location'] = urldecode(utf8_uri_encode($_GET['location'])); ?>

<?php get_header('search'); ?>
	
<?php do_action('jobs_will_display'); ?>

<div class="row">
	<?php get_sidebar('blog'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
		<div class="section search-jobs jj-search">
			
			<?php 
				// Global so we can pass it on to the filter-process.php file
				global $find_posts_in, $search_result_ids, $wp_query, $query_string;

				// Override Search Query
				$args = $query_string;
				// $search_query = wp_parse_args( $query_string, colabs_process_filter_form() );

				$term_heading = __('Search Results', 'colabsthemes');
				$location_heading = '';

				if (isset($_GET['s']) && $_GET['s']) $search = get_search_query(); else $search = '';
				if (isset($_GET['location'])) $location = trim($_GET['location']); else $location = '';
				if (isset($_GET['radius']) && $_GET['radius']>0) $radius = trim($_GET['radius']); else $radius = 50;

				// If search query is exists
				if ($search) {
					$search_result_ids[] = 0;
					if ($wp_query->posts) {
						foreach ($wp_query->posts as $p) { 
							$search_result_ids[] = $p->ID.'';
						}
					}
					$term_heading = __('Searching for ','colabsthemes').'&ldquo;'.$search.'&rdquo; ';
				}

				// If location query is exists
				if ( $location ) {
					$location_query = array(
						'meta_query' => array(
							array(
								'key' => 'geo_address',
								'value' => $location,
								'compare' => 'LIKE'
							)
						)
					);
					$args = wp_parse_args( $args, $location_query );
					$location_heading .= '&nbsp;';
					$location_heading .= __('in','colabsthemes').' '.ucwords($location);
				}

			?>

			<h1 class="pagetitle">
				<?php echo $term_heading.$location_heading; ?> 
				<?php if ($paged>1) : ?>
					(<?php _e('page','colabsthemes'); ?> <?php echo $paged; ?>)
				<?php endif; ?>
			</h1>

			<h3 class="section-title">
				<?php _e('Search Results','colabsthemes'); ?>
				<?php if (isset($_GET['action']) && $_GET['action'] == 'Filter') { ?>
					<small> &mdash; <a href="<?php echo colabs_get_current_url(); ?>"><?php _e('Remove Filters','colabsthemes'); ?></a></small>
				<?php } ?>
			</h3>

			<?php 
				if( isset( $_GET['jobs-filter'] ) ) {
					$filter_query = colabs_filter_form();
					$args = wp_parse_args( $args, $filter_query );
				} else {
					colabs_filter_form();
				}

				// If Filter query is exists, only search post_type job
				if( $_REQUEST['action'] == 'Filter' || $_REQUEST['index-filter'] == 'true' ) {
					$args_job = array('post_type' => 'job_listing');
					$args = wp_parse_args( $args, $args_job );
					query_posts( $args );
					get_template_part( 'loop', 'job' );
				} else {
					$args_post = array('post_type' => array('post', 'page'));
					$args = wp_parse_args( $args, $args_post );
					query_posts( $args );
					get_template_part( 'loop' );
				}
				
			?>

			<?php colabs_pagination( array(
				'base' => user_trailingslashit( trailingslashit( get_pagenum_link() ) . 'page/%#%' )
			) ); ?>

			<div class="clear"></div>

		</div><!-- End section -->
	</div>
</div>

<div class="clear"></div>

<?php get_footer(); ?>