<?php get_header('search'); global $wp_query,$user_ID;?>
<div class="row">
	<?php get_sidebar('user'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
    <div class="section" id="profile">    

		<div class="section-content">
			
			<?php if( get_avatar( $wp_query->get_queried_object()->ID ) ) : ?>
				<div class="profile-avatar">
					<?php echo get_avatar( $wp_query->get_queried_object()->ID ); ?>
				</div>
			<?php endif; ?>

			<div class="profile-content">
				<h1><?php echo wptexturize( $wp_query->get_queried_object()->display_name ); ?> <?php if ($url = $wp_query->get_queried_object()->user_url) echo ' &ndash; <a href="'.$url.'">'.$url.'</a>'; ?></a></h1> 
				<?php 
				if (isset($wp_query->get_queried_object()->description) && !empty($wp_query->get_queried_object()->description)) 
					echo wpautop( wptexturize( $wp_query->get_queried_object()->description )); 
				?>
			
				<?php
					$social = array();
					if ($twitter = get_user_meta( $wp_query->get_queried_object()->ID, 'twitter_id', true)) :
						$social[] = '<li class="twitter"><a href="http://twitter.com/'.$twitter.'">'.sprintf( __('Follow %s on Twitter', 'colabsthemes'), $wp_query->get_queried_object()->display_name ).'</a></li>';
					endif;
					
					if ($facebook = get_user_meta( $wp_query->get_queried_object()->ID, 'facebook_id', true)) :
						$social[] = '<li class="facebook"><a href="http://facebook.com/'.$facebook.'">'.sprintf( __('View %s on Facebook', 'colabsthemes'), $wp_query->get_queried_object()->display_name ).'</a></li>';
					endif;
					
					if ($linkedin = get_user_meta( $wp_query->get_queried_object()->ID, 'linkedin_profile', true)) :
						$social[] = '<li class="linkedin"><a href="'.$linkedin.'">'.sprintf( __('View %s on LinkedIn', 'colabsthemes'), $wp_query->get_queried_object()->display_name ).'</a></li>';
					endif;
					
					if (sizeof($social)>0) :
						echo '<ul class="social">'.implode('', $social).'</ul>';
					endif;
				?>
			</div>
			<!-- .profile-content -->
			
			<div class="clear"></div>
			
		</div>
		<!-- .section-content -->
		
		<?php if (user_can($wp_query->get_queried_object()->ID, 'can_submit_job')) : ?>
			<h3 class="section-title"><?php echo sprintf( __('%s\'s Job Listings', 'colabsthemes'), $wp_query->get_queried_object()->display_name); ?></h2>
	        <?php
	        global $paged;
       		$args = array(
						'author' => $wp_query->get_queried_object()->ID,
						'post_type' => 'job_listing',
						'post_status' => 'publish',
						'paged' => $paged,
					);
					$wp_query = new WP_Query($args);
	
					// call the main loop-job.php file
					get_template_part( 'loop', 'job' );
			?>
	
			
		<?php else : ?>
			
			<h2><?php echo sprintf( __('%s\'s resumes', 'colabsthemes'), $wp_query->get_queried_object()->display_name); ?></h2>
			
			<?php
							$args = array(
									'ignore_sticky_posts'	=> 1,
									'posts_per_page' => -1,
									'author' => $wp_query->get_queried_object()->ID,
									'post_type' => 'resume'
									
							);
				$wp_query = new WP_Query($args);
					
				get_template_part( 'loop', 'resume' ); 
			?>
		<?php endif; ?>
		
        	<?php colabs_pagination(); ?>

			<div class="clear"></div>

		</div><!-- End section -->
	</div>
</div>
<div class="clear"></div>

<?php get_footer(); ?>