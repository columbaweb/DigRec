<?php
/**
 * The loop that displays the blog posts.
 *
 * @package ColorLabs
 * @subpackage JobJockey
 *
 */
?>

<?php colabsthemes_before_blog_loop(); ?>

<?php if (have_posts()) : $alt = 1;?>

    <?php while (have_posts()) : the_post(); ?>
	
		<?php colabsthemes_before_blog_post(); ?>

		<?php
			$post_class = array('post');
			$alt=$alt*-1;
			if ($alt==1) $post_class[] = 'post-alt';
		?>

        <div class="section post <?php echo implode(' ', $post_class); ?>">

			<div class="section_header">		
				
				<?php colabsthemes_before_blog_post_title(); ?>

				<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
				
				<?php colabsthemes_after_blog_post_title(); ?>  

				<div class="clear"></div>

			</div><!-- end section_header -->
			
			
			<div class="section_content">
			
				<?php colabsthemes_before_blog_post_content(); ?>

				
				<?php
				if(!is_single()){
					colabs_image('width=500&force=true');
					colabs_custom_excerpt();
					echo '<p class="more"><a href="'.get_permalink().'">'.__('Continue Reading &raquo','colabsthemes').'</a></p>';
				}else{
				?>
				<?php   
				$single_top = get_post_custom_values("colabs_single_top");
				if (($single_top[0]!='')||($single_top[0]=='none')){
				?>
					<div class="singleimage">
						<?php 
								
						if ($single_top[0]=='single_video'){
							$embed = colabs_get_embed('colabs_embed',667,364,'single_video',$post->ID);
							if ($embed!=''){
								echo $embed; 
							}
						}elseif($single_top[0]=='single_image'){
							colabs_image('width=657');				
						}
									
						?>
					</div>
				<?php }?>
				<?php
					the_content(); 
				}
				?>
				
				<?php colabsthemes_after_blog_post_content(); ?>
				
				<div class="clear"></div>
			
			</div><!-- end section_content -->

        </div><!-- end section single -->

<?php endwhile; ?>

	<?php colabsthemes_after_blog_endwhile(); ?>

<?php else: ?>

	<?php colabsthemes_blog_loop_else(); ?>

<?php endif; ?>

<?php colabsthemes_after_blog_loop(); ?>

