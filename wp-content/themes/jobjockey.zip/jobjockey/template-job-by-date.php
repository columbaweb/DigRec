<?php
/*
Template Name: Jobs by date
*/
?>

<?php
if (isset($_GET['show'])) $show = $_GET['show'];
if (!$show) wp_redirect(get_bloginfo('url'));
?>

<?php get_header('search'); ?>

<?php do_action('jobs_will_display'); ?>

	<div class="row">
		
    <?php get_sidebar('job'); ?>

		<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
            
            <?php
            $dateargs = array();
			$title = '';
			$today = getdate();
			
			switch ($show) :
				case "week" :
					$title = __('This weeks Jobs','colabsthemes');
					$dateargs = array( 'year' => $today["year"], 'w' => date('W') );
				break;
				case "lastweek" :
					$title = __('Last weeks Jobs','colabsthemes');
					$week = date('W');
					$year = $today["year"];
					if ($week==0) :
						$week = 53;
						$year = $year-1;
					else :
						$week = $week-1;
					endif;
					$dateargs = array( 'year' => $year, 'w' => $week );
				break;
				case "today" :
					$title = __('Todays Jobs','colabsthemes');
					$dateargs = array( 'year' => $today["year"], 'monthnum' => $today["mon"], 'day' => $today["mday"] );
				break;
				case "month" :
					$title = __('This Months Jobs','colabsthemes');
					$dateargs = array( 'year' => $today["year"], 'monthnum' => $today["mon"] );
				break;
			endswitch;
			
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			$args = array(
				'post_type'	=> 'job_listing',
				'post_status' => 'publish',
				'ignore_sticky_posts'	=> 1,
				'paged'=>$paged
			);
			$args = array_merge($dateargs, $args);
			$wp_query = new WP_Query($args);
            ?>

            <div class="section latest-jobs">
        
        		<h3 class="section-title">
        
        			<?php echo $title; ?>
        
        		</h3>
                
        		<?php
                    
        			// call the main loop-job.php file
        			get_template_part( 'loop', 'job' );
        		?>
                
            </div><!-- end section -->
            
    		<?php colabs_custom_pagination(); ?>
    		
    		<?php wp_reset_postdata(); ?>
    
    		<div class="clear"></div>

		</div><!-- .content -->

	</div>
    
<?php get_footer();?>	666