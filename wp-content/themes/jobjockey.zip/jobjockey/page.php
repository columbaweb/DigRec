<?php get_header(); ?>
<div class="row">
	<?php get_sidebar('page'); ?>
	<div class="content column col8 <?php if(get_option('colabs_layout_settings')=='two-col-left'){echo 'alpha';}?>">
<?php if (get_option('colabs_show_sidebar')!=='no') get_sidebar('page'); ?>
	
	<div class="section">
		
		<?php colabsthemes_before_page_title(); ?>
		<h3 class="section-title"><?php the_title(); ?></h3>
		<?php colabsthemes_after_page_title(); ?>
		
		<div class="section-content">
		
			<?php colabsthemes_before_page_loop(); ?>

			<?php if (have_posts()) : ?>

				<?php while (have_posts()) : the_post(); ?>
				
					<?php colabsthemes_before_page(); ?>
					
					<?php colabsthemes_before_page_content(); ?>

					<?php the_content(); ?>
					
					<?php edit_post_link('Edit', '<p>', '</p>'); ?>
					
					<?php colabsthemes_after_page_content(); ?>
					
					<?php colabsthemes_after_page(); ?>

				<?php endwhile; ?>
				
				<?php colabsthemes_after_page_endwhile(); ?>
				
			<?php else: ?>
				
				<?php colabsthemes_page_loop_else(); ?>				

			<?php endif; ?>
			
			<?php colabsthemes_after_page_loop(); ?>

			<div class="clear"></div>

		</div>

	</div>
	
	<?php comments_template( '', true ); ?><!-- #comments -->
	</div>
</div>

<div class="clear"></div>


<?php get_footer(); ?>