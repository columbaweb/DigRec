<?php global $header_search; $header_search = true; ?>
<?php get_header(); ?>

<?php if ( true && ( !isset($_GET['submit']) || ( isset($_GET['submit']) && $_GET['submit']!=='true' ) ) && ( !isset($_GET['myjobs']) || ( isset($_GET['myjobs']) && $_GET['myjobs']!=='true' ) ) ) : ?>

	<div class="row job-search">
        
        <?php
        $items = '';
    	if (get_option('colabs_submit_page_id') && (!is_user_logged_in() || (is_user_logged_in() && current_user_can('can_submit_job')))) :
            $items .= '<div class="submit-job column ';
    		if (is_page(get_option('colabs_submit_page_id'))) $items .= 'current_page_item';	
    		$items .= '"><a href="'.get_permalink(get_option('colabs_submit_page_id')).'">'.__('Submit A Job', 'colabsthemes').'</a></div>';
        else :
        	if (get_option('colabs_job_seeker_resume_page_id') && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('can_submit_job')))) :
                $items .= '<div class="submit-job column ';
        		if (is_page(get_option('colabs_job_seeker_resume_page_id'))) $items .= 'current_page_item';	
        		$items .= '"><a href="'.get_permalink(get_option('colabs_job_seeker_resume_page_id')).'">'.__('Add A Resume', 'colabsthemes').'</a></div>';
            endif;
    	endif;
        echo $items;
        ?>

		<div class="job-searchform column">
			<form action="<?php bloginfo('url'); ?>/" method="get" id="searchform">
				<input type="text" id="search" title="" name="s" class="text placeholder" placeholder="<?php _e('Keyword','colabsthemes'); ?>" rel="<?php _e('Keyword','colabsthemes'); ?>" value="<?php if (isset($_GET['s'])) echo get_search_query(); ?>" />
				<input type="text" id="near" title="<?php _e('Location','colabsthemes'); ?>" placeholder="<?php _e('Location','colabsthemes'); ?>" name="location" class="text placeholder" rel="<?php _e('Location','colabsthemes'); ?>" value="<?php if (isset($_GET['location'])) echo $_GET['location']; ?>" />

                <?php
                // Check if jobs-filter query is exists
                if( get_query_var( 'jobs-filter' ) ) : ?>
                    <?php foreach( get_query_var( 'jobs-filter' ) as $filter ) : ?>
                        <input type="hidden" name="jobs-filter[]" value="<?php echo $filter; ?>">
                    <?php endforeach; ?>
                <?php endif; ?>

                <input type="hidden" name="action" value="Filter">
				<input type="submit" alt="<?php _e('Search','colabsthemes'); ?>" title="<?php _e('Search','colabsthemes'); ?>" class="submit" />
			</form>
		</div><!-- .job-searchform -->
        
	</div><!-- .job-search -->

<?php endif; ?>